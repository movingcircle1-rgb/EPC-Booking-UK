// src/components/Footer.tsx
import {
  Phone,
  Mail,
  MapPin,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  ArrowRight,
  Youtube
} from 'lucide-react'
import { brandConfig } from '../config/branding'
import { parseAreaLinks } from '../hooks/useLocation'

interface Location {
  city: string
  area_links: string | null
  nearest_1: string | null
  nearest_2: string | null
  nearest_3: string | null
}

interface FooterProps {
  onNavigate?: (page: string) => void
  locationData?: Location
}

export default function Footer({ locationData }: FooterProps) {
  const contextualLinks = locationData ? parseAreaLinks(locationData.area_links) : []

  const toSeoPath = (path: string) => {
    if (!path) return '/'
    if (path === '/') return '/'

    // Ensure leading slash
    const withLeading = path.startsWith('/') ? path : `/${path}`

    // Don't add trailing slash to SPA routes
    const noSlash = new Set([
      '/admin',
      '/admin2',
      '/temp-admin',
      '/client-portal',
      '/staff-portal',
      '/partner-portal',
      '/trade-portal',
      '/login',
      '/signup'
    ])

    if (noSlash.has(withLeading)) return withLeading

    // Add trailing slash for normal pages
    return withLeading.endsWith('/') ? withLeading : `${withLeading}/`
  }

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <img src={brandConfig.logo.footer} alt={brandConfig.logo.alt} className="h-36 w-auto mb-4" />
            <p className="text-gray-400 text-sm mb-4">{brandConfig.description}</p>

            <div className="flex flex-wrap gap-3">
              <a
                href={brandConfig.social.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#e71c5e] flex items-center justify-center hover:bg-[#c91852] transition-colors"
                aria-label="Follow us on Facebook"
              >
                <Facebook size={18} />
              </a>

              <a
                href={brandConfig.social.twitter}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#e71c5e] flex items-center justify-center hover:bg-[#c91852] transition-colors"
                aria-label="Follow us on Twitter/X"
              >
                <Twitter size={18} />
              </a>

              <a
                href={brandConfig.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#e71c5e] flex items-center justify-center hover:bg-[#c91852] transition-colors"
                aria-label="Follow us on Instagram"
              >
                <Instagram size={18} />
              </a>

              <a
                href={brandConfig.social.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#e71c5e] flex items-center justify-center hover:bg-[#c91852] transition-colors"
                aria-label="Follow us on LinkedIn"
              >
                <Linkedin size={18} />
              </a>

              <a
                href={brandConfig.social.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#e71c5e] flex items-center justify-center hover:bg-[#c91852] transition-colors"
                aria-label="Subscribe on YouTube"
              >
                <Youtube size={18} />
              </a>

              <a
                href={brandConfig.social.tiktok}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#e71c5e] flex items-center justify-center hover:bg-[#c91852] transition-colors"
                aria-label="Follow us on TikTok"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
                </svg>
              </a>

              <a
                href={brandConfig.social.pinterest}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#e71c5e] flex items-center justify-center hover:bg-[#c91852] transition-colors"
                aria-label="Follow us on Pinterest"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 0C5.373 0 0 5.372 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.631-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z" />
                </svg>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Our Services</h3>
            <ul className="space-y-2">
              <li>
                <a
                  href={toSeoPath('/removals')}
                  className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm flex items-center gap-2 group"
                >
                  <ArrowRight size={14} className="text-[#e71c5e] group-hover:translate-x-1 transition-transform" />
                  All Removals
                </a>
              </li>

              <li>
                <a
                  href={toSeoPath('/house-removals')}
                  className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm flex items-center gap-2 group"
                >
                  <ArrowRight size={14} className="text-[#e71c5e] group-hover:translate-x-1 transition-transform" />
                  House Removals
                </a>
              </li>

              <li>
                <a
                  href={toSeoPath('/office-removals')}
                  className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm flex items-center gap-2 group"
                >
                  <ArrowRight size={14} className="text-[#e71c5e] group-hover:translate-x-1 transition-transform" />
                  Office Removals
                </a>
              </li>

              <li>
                <a
                  href={toSeoPath('/packing-services')}
                  className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm flex items-center gap-2 group"
                >
                  <ArrowRight size={14} className="text-[#e71c5e] group-hover:translate-x-1 transition-transform" />
                  Packing Services
                </a>
              </li>

              <li>
                <a
                  href={toSeoPath('/european-moves')}
                  className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm flex items-center gap-2 group"
                >
                  <ArrowRight size={14} className="text-[#e71c5e] group-hover:translate-x-1 transition-transform" />
                  European Moves
                </a>
              </li>

              <li>
                <a
                  href={toSeoPath('/international-moves')}
                  className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm flex items-center gap-2 group"
                >
                  <ArrowRight size={14} className="text-[#e71c5e] group-hover:translate-x-1 transition-transform" />
                  International Moves
                </a>
              </li>

              <li>
                <a
                  href={toSeoPath('/storage')}
                  className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm flex items-center gap-2 group"
                >
                  <ArrowRight size={14} className="text-[#e71c5e] group-hover:translate-x-1 transition-transform" />
                  Storage Solutions
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">
              {locationData && contextualLinks.length > 0 ? `Removals Near ${locationData.city}` : 'Quick Links'}
            </h3>

            <ul className="space-y-2">
              {locationData && contextualLinks.length > 0 ? (
                <>
                  {contextualLinks.map((link, index) => (
                    <li key={index}>
                      <a
                        href={link.slug}
                        className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm flex items-center gap-2 group"
                      >
                        <ArrowRight
                          size={14}
                          className="text-[#e71c5e] group-hover:translate-x-1 transition-transform"
                        />
                        Removals {link.name}
                      </a>
                    </li>
                  ))}

                  {locationData.nearest_1 && (
                    <li>
                      <span className="text-gray-500 text-xs">
                        Also serving: {locationData.nearest_1}, {locationData.nearest_2}, {locationData.nearest_3}
                      </span>
                    </li>
                  )}
                </>
              ) : (
                <>
                  <li>
                    <a
                      href={toSeoPath('/')}
                      className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm flex items-center gap-2 group"
                    >
                      <ArrowRight size={14} className="text-[#e71c5e] group-hover:translate-x-1 transition-transform" />
                      Home
                    </a>
                  </li>

                  <li>
                    <a
                      href={toSeoPath('/about')}
                      className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm flex items-center gap-2 group"
                    >
                      <ArrowRight size={14} className="text-[#e71c5e] group-hover:translate-x-1 transition-transform" />
                      About Us
                    </a>
                  </li>

                  <li>
                    <a
                      href={toSeoPath('/how-it-works')}
                      className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm flex items-center gap-2 group"
                    >
                      <ArrowRight size={14} className="text-[#e71c5e] group-hover:translate-x-1 transition-transform" />
                      How It Works
                    </a>
                  </li>

                  <li>
                    <a
                      href={toSeoPath('/contact')}
                      className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm flex items-center gap-2 group"
                    >
                      <ArrowRight size={14} className="text-[#e71c5e] group-hover:translate-x-1 transition-transform" />
                      Contact
                    </a>
                  </li>

                  <li>
                    <a
                      href={toSeoPath('/locations')}
                      className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm flex items-center gap-2 group"
                    >
                      <ArrowRight size={14} className="text-[#e71c5e] group-hover:translate-x-1 transition-transform" />
                      All Locations
                    </a>
                  </li>
                </>
              )}
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Get in Touch</h3>

            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Phone size={18} className="text-[#e71c5e] mt-1 flex-shrink-0" />
                <div>
                  <a
                    href={brandConfig.contact.phoneHref}
                    className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm"
                  >
                    {brandConfig.contact.phone}
                  </a>
                  <br />
                  <a
                    href={brandConfig.contact.phoneSecondaryHref}
                    className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm"
                  >
                    {brandConfig.contact.phoneSecondary}
                  </a>
                </div>
              </li>

              <li className="flex items-start gap-3">
                <Mail size={18} className="text-[#e71c5e] mt-1 flex-shrink-0" />
                <div>
                  <a
                    href={brandConfig.contact.emailHref}
                    className="text-gray-400 hover:text-[#e71c5e] transition-colors text-sm"
                  >
                    {brandConfig.contact.email}
                  </a>
                </div>
              </li>

              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-[#e71c5e] mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-400 text-sm">
                    {brandConfig.contact.address.street}
                    <br />
                    {brandConfig.contact.address.city}, {brandConfig.contact.address.country}
                    <br />
                    {brandConfig.contact.address.postcode}
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="text-center">
            <p className="text-gray-400 text-sm">
              &copy; {new Date().getFullYear()} {brandConfig.footer.copyrightText}
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
