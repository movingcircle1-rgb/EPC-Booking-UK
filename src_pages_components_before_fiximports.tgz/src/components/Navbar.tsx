// src/components/Navbar.tsx
import { useState, useEffect, useRef } from 'react'
import { Menu, X, Phone, Mail, ChevronDown } from 'lucide-react'
import { brandConfig } from '../config/branding'
import { useAuth } from '../contexts/AuthContext'
import { useQuote } from '../contexts/QuoteContext'
import UserMenu from './UserMenu'

export default function Navbar() {
  const { user } = useAuth()
  const { openQuote } = useQuote()

  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null)
  const [showPortalsDropdown, setShowPortalsDropdown] = useState(false)
  const [showPhoneDropdown, setShowPhoneDropdown] = useState(false)

  const portalsDropdownRef = useRef<HTMLDivElement>(null)
  const phoneDropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (portalsDropdownRef.current && !portalsDropdownRef.current.contains(event.target as Node)) {
        setShowPortalsDropdown(false)
      }
      if (phoneDropdownRef.current && !phoneDropdownRef.current.contains(event.target as Node)) {
        setShowPhoneDropdown(false)
      }
    }

    if (showPortalsDropdown || showPhoneDropdown) {
      document.addEventListener('mousedown', handleClickOutside)
    }

    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [showPortalsDropdown, showPhoneDropdown])

  const megaMenu = [
    {
      id: 'removals-storage',
      label: 'Removals & Storage',
      items: [
        { id: 'removals', label: 'All Removals' },
        { id: 'house-removals', label: 'House Removals' },
        { id: 'office-removals', label: 'Office Removals' },
        { id: 'packing-services', label: 'Packing Services' },
        { id: 'european-moves', label: 'European Moves' },
        { id: 'international-moves', label: 'International Moves' },
        { id: 'storage', label: 'Storage' }
      ]
    },
    {
      id: 'discounts',
      label: 'Discounts',
      items: [
        { id: 'blue-light-card', label: 'Blue Light Card' },
        { id: 'mid-week-move', label: 'Mid Week move' }
      ]
    },
    {
      id: 'client-benefits',
      label: 'Client Benefits',
      items: [
        { id: 'we-recommend', label: 'We Recommend' },
        { id: 'free-storage', label: 'Free Storage' }
      ]
    },
    {
      id: 'charitable',
      label: 'Charitable',
      items: [
        { id: 'furniture-removal', label: 'Furniture Removal' },
        { id: 'we-donate', label: 'We Donate' }
      ]
    },
    {
      id: 'green-movers',
      label: 'Green Movers',
      items: [
        { id: 'we-recycle', label: 'We recycle' },
        { id: 'low-emission-promise', label: 'Low Emission Promise' }
      ]
    }
  ] as const

  const portalItems = [
    { id: 'login', label: 'Login', isSpecial: true },
    { id: 'client-portal', label: 'Client Portal' },
    { id: 'partner-portal', label: 'Partner Portal' },
    { id: 'staff-portal', label: 'Staff Portal' },
    { id: 'trade-portal', label: 'Trade Portal' }
  ] as const

  const phoneNumbers = [
    { number: brandConfig.contact.phone, href: brandConfig.contact.phoneHref, label: 'Main Line' },
    { number: brandConfig.contact.phoneSecondary, href: brandConfig.contact.phoneSecondaryHref, label: 'Mobile' }
  ] as const

  // SEO-friendly trailing slash for content pages
  const toSeoPath = (id: string) => {
    const noSlash = new Set([
      'admin',
      'admin2',
      'temp-admin',
      'client-portal',
      'staff-portal',
      'partner-portal',
      'trade-portal',
      'login',
      'signup'
    ])
    if (noSlash.has(id)) return `/${id}`
    return `/${id}/`
  }

  const handleMouseEnter = (menuId: string) => setActiveDropdown(menuId)
  const handleMouseLeave = () => setActiveDropdown(null)

  const closeMobile = () => setIsMobileMenuOpen(false)

  const go = (href: string) => {
    // full reload navigation (works with Vike SSG/SSR and avoids react-router context issues)
    window.location.assign(href)
  }

  return (
    <>
      <div className="bg-[#e71c5e]/90 backdrop-blur-md text-white py-2 sm:py-2 px-2 sm:px-4 relative z-50">
        <div className="container mx-auto flex justify-between items-center text-xs sm:text-sm">
          <div className="flex items-center gap-2 sm:gap-4 md:gap-6">
            <div ref={phoneDropdownRef} className="relative">
              <button
                onClick={() => setShowPhoneDropdown(!showPhoneDropdown)}
                className="flex items-center gap-1 sm:gap-2 hover:opacity-80 transition-opacity min-w-[44px] min-h-[44px] justify-center sm:justify-start"
                aria-label="Phone numbers"
                aria-expanded={showPhoneDropdown}
                type="button"
              >
                <Phone size={16} className="flex-shrink-0" />
                <span className="hidden lg:inline">{brandConfig.contact.phone}</span>
                <ChevronDown
                  size={12}
                  className={`hidden sm:inline transition-transform ${showPhoneDropdown ? 'rotate-180' : ''}`}
                />
              </button>

              {showPhoneDropdown && (
                <div className="absolute top-full left-0 mt-1 bg-white shadow-xl border border-gray-200 rounded-lg py-2 min-w-[200px] z-[60]">
                  {phoneNumbers.map((phone, index) => (
                    <a
                      key={index}
                      href={phone.href}
                      onClick={() => setShowPhoneDropdown(false)}
                      className="block w-full text-left px-4 py-2 text-sm text-[#293132] hover:text-[#e71c5e] hover:bg-gray-50 transition-colors"
                    >
                      <div className="font-semibold">{phone.label}</div>
                      <div className="text-xs text-gray-600">{phone.number}</div>
                    </a>
                  ))}
                </div>
              )}
            </div>

            <a
              href={brandConfig.contact.emailHref}
              className="flex items-center gap-1 sm:gap-2 hover:opacity-80 transition-opacity min-w-[44px] min-h-[44px] justify-center sm:justify-start"
              aria-label="Email us"
            >
              <Mail size={16} className="flex-shrink-0" />
              <span className="hidden md:inline truncate">{brandConfig.contact.email}</span>
            </a>
          </div>

          <div className="flex gap-2 sm:gap-3 items-center">
            <button
              onClick={openQuote}
              className="bg-white text-[#949494] px-2 sm:px-4 py-1 sm:py-1.5 rounded font-semibold text-xs sm:text-sm hover:bg-gray-100 transition-colors whitespace-nowrap min-h-[36px] sm:min-h-auto"
              aria-label="Get a quote"
              type="button"
            >
              <span className="hidden sm:inline">Get a Quote</span>
              <span className="sm:hidden">Quote</span>
            </button>

            {user ? (
              <UserMenu />
            ) : (
              <div ref={portalsDropdownRef} className="relative">
                <button
                  onClick={() => setShowPortalsDropdown(!showPortalsDropdown)}
                  className="bg-white text-[#949494] px-2 sm:px-4 py-1 sm:py-1.5 rounded font-semibold text-xs sm:text-sm hover:bg-gray-100 transition-colors flex items-center gap-1 whitespace-nowrap min-h-[36px] sm:min-h-auto"
                  aria-label="Access portals"
                  aria-expanded={showPortalsDropdown}
                  type="button"
                >
                  Portals
                  <ChevronDown
                    size={14}
                    className={`transition-transform ${showPortalsDropdown ? 'rotate-180' : ''}`}
                  />
                </button>

                {showPortalsDropdown && (
                  <div className="absolute top-full right-0 mt-1 bg-white shadow-xl border border-gray-200 rounded-lg py-2 min-w-[180px] z-[60]">
                    {portalItems.map((item) => (
                      <a
                        key={item.id}
                        href={toSeoPath(item.id)}
                        onClick={(e) => {
                          e.preventDefault()
                          setShowPortalsDropdown(false)
                          window.scrollTo({ top: 0, behavior: 'smooth' })
                          go(toSeoPath(item.id))
                        }}
                        className={`block w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${
                          item.isSpecial
                            ? 'text-[#e71c5e] font-semibold border-b border-gray-200 hover:text-[#c91852]'
                            : 'text-[#293132] hover:text-[#e71c5e]'
                        }`}
                      >
                        {item.label}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      <nav
        className="sticky top-0 z-40 transition-all duration-300 bg-white/95 backdrop-blur-md"
        style={{
          boxShadow: isScrolled
            ? '0 8px 32px 0 rgba(0, 0, 0, 0.2), 0 2px 8px 0 rgba(0, 0, 0, 0.1)'
            : '0 4px 24px 0 rgba(0, 0, 0, 0.15)'
        }}
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-24 sm:h-28 md:h-32">
            {/* Home */}
            <a href="/" className="flex items-center hover:opacity-90 transition-opacity" aria-label="Go to homepage">
              <img src={brandConfig.logo.primary} alt={brandConfig.logo.alt} className="h-20 sm:h-24 md:h-28 w-auto" />
            </a>

            {/* Desktop */}
            <div className="hidden lg:flex items-center space-x-1">
              {megaMenu.map((menu) => (
                <div
                  key={menu.id}
                  className="relative"
                  onMouseEnter={() => handleMouseEnter(menu.id)}
                  onMouseLeave={handleMouseLeave}
                >
                  <button
                    className="flex items-center gap-1 px-4 py-2 text-sm font-semibold text-[#293132] hover:text-[#e71c5e] transition-colors"
                    aria-label={`${menu.label} menu`}
                    aria-expanded={activeDropdown === menu.id}
                    type="button"
                  >
                    {menu.label}
                    <ChevronDown
                      size={16}
                      className={`transition-transform ${activeDropdown === menu.id ? 'rotate-180' : ''}`}
                    />
                  </button>

                  {activeDropdown === menu.id && (
                    <div className="absolute top-full left-0 mt-0 bg-white shadow-xl border border-gray-200 rounded-lg py-2 min-w-[200px] z-50">
                      {menu.items.map((item) => (
                        <a
                          key={item.id}
                          href={toSeoPath(item.id)}
                          onClick={(e) => {
                            e.preventDefault()
                            setActiveDropdown(null)
                            window.scrollTo({ top: 0, behavior: 'smooth' })
                            go(toSeoPath(item.id))
                          }}
                          className="block w-full text-left px-4 py-2 text-sm text-[#293132] hover:text-[#e71c5e] hover:bg-gray-50 transition-colors"
                        >
                          {item.label}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              <a
                href="/articles/"
                className="px-4 py-2 text-sm font-semibold text-[#293132] hover:text-[#e71c5e] transition-colors"
                onClick={(e) => {
                  e.preventDefault()
                  window.scrollTo({ top: 0, behavior: 'smooth' })
                  go('/articles/')
                }}
              >
                Articles
              </a>
            </div>

            {/* Mobile button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-[#293132] hover:text-[#e71c5e] transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center"
              aria-label="Toggle mobile menu"
              aria-expanded={isMobileMenuOpen}
              type="button"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-white border-t border-gray-200 max-h-[calc(100vh-140px)] overflow-y-auto">
            <div className="container mx-auto px-4 py-4 space-y-2">
              <a
                href="/articles/"
                onClick={(e) => {
                  e.preventDefault()
                  closeMobile()
                  window.scrollTo({ top: 0, behavior: 'smooth' })
                  go('/articles/')
                }}
                className="block w-full text-left px-4 py-3 text-sm font-semibold text-[#293132] hover:bg-gray-100 rounded-lg transition-colors"
              >
                Articles
              </a>

              {megaMenu.map((menu) => (
                <div key={menu.id} className="border-t border-gray-200 pt-2 mt-2">
                  <div className="px-4 py-2 text-sm font-bold text-gray-900">{menu.label}</div>
                  {menu.items.map((item) => (
                    <a
                      key={item.id}
                      href={toSeoPath(item.id)}
                      onClick={(e) => {
                        e.preventDefault()
                        closeMobile()
                        window.scrollTo({ top: 0, behavior: 'smooth' })
                        go(toSeoPath(item.id))
                      }}
                      className="block w-full text-left px-6 py-2 text-sm text-[#293132] hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      {item.label}
                    </a>
                  ))}
                </div>
              ))}

              <div className="border-t border-gray-200 pt-2 mt-2">
                <div className="px-4 py-2 text-sm font-bold text-gray-900">Portals</div>
                {portalItems.map((item) => (
                  <a
                    key={item.id}
                    href={toSeoPath(item.id)}
                    onClick={(e) => {
                      e.preventDefault()
                      closeMobile()
                      window.scrollTo({ top: 0, behavior: 'smooth' })
                      go(toSeoPath(item.id))
                    }}
                    className={`block w-full text-left px-6 py-2 text-sm hover:bg-gray-100 rounded-lg transition-colors min-h-[44px] flex items-center ${
                      item.isSpecial ? 'text-[#e71c5e] font-semibold' : 'text-[#293132]'
                    }`}
                  >
                    {item.label}
                  </a>
                ))}
              </div>
            </div>
          </div>
        )}
      </nav>
    </>
  )
}
