// src/components/ProtectedRoute.tsx
import { ReactNode, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { authService } from '../lib/auth-service'

interface ProtectedRouteProps {
  children: ReactNode
  allowedRoles?: ('admin' | 'staff' | 'partner' | 'client' | 'trade' | 'temp_admin')[]
  requireAuth?: boolean
}

export default function ProtectedRoute({
  children,
  allowedRoles,
  requireAuth = true
}: ProtectedRouteProps) {
  const { user, userRole, loading } = useAuth()

  const isBrowser = typeof window !== 'undefined'

  // CLIENT-ONLY redirect logic
  useEffect(() => {
    if (!isBrowser) return
    if (loading) return

    // Not logged in
    if (requireAuth && !user) {
      window.location.replace('/login/')
      return
    }

    // Logged in but wrong role
    if (user && userRole && allowedRoles) {
      if (!allowedRoles.includes(userRole.role)) {
        const correctPath = authService.getRedirectPathForRole(userRole.role)
        window.location.replace(correctPath)
      }
    }
  }, [loading, user, userRole, allowedRoles, requireAuth, isBrowser])

  // SSR SAFE RENDERING

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-[#e71c5e] mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">Loading...</p>
        </div>
      </div>
    )
  }

  // During SSR we just render nothing instead of crashing
  if (!isBrowser) {
    return null
  }

  if (requireAuth && !user) {
    return null
  }

  if (allowedRoles && userRole && !allowedRoles.includes(userRole.role)) {
    return null
  }

  return <>{children}</>
}
