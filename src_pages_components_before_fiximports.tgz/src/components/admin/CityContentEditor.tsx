import { useState, useEffect } from 'react';
import { X, Save, Image as ImageIcon, AlertCircle, CheckCircle, Upload } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface ContentBlock {
  id?: string;
  block_position: number;
  heading: string;
  content: string;
  image_url: string;
  image_alt: string;
  service_type?: string;
}

interface CityContentEditorProps {
  cityId: string;
  cityName: string;
  onClose: () => void;
  onSuccess: () => void;
}

const serviceTypes = [
  { value: 'house-removals', label: 'House Removals' },
  { value: 'office-removals', label: 'Office Removals' },
  { value: 'packing-services', label: 'Packing Services' },
  { value: 'storage-solutions', label: 'Storage Solutions' }
];

export default function CityContentEditor({ cityId, cityName, onClose, onSuccess }: CityContentEditorProps) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [selectedService, setSelectedService] = useState('house-removals');

  // Service-specific placeholder text
  const getPlaceholders = (service: string) => {
    switch (service) {
      case 'house-removals':
        return {
          heading: `Professional House Removals in ${cityName}`,
          content: `Write about house removal services in ${cityName}. Include local landmarks, residential areas served, and what makes your house moving service unique in this location...`
        };
      case 'office-removals':
        return {
          heading: `Expert Office Removals in ${cityName}`,
          content: `Write about office relocation services in ${cityName}. Include business districts, commercial areas, and how you minimize downtime for businesses in this location...`
        };
      case 'packing-services':
        return {
          heading: `Professional Packing Services in ${cityName}`,
          content: `Write about packing services in ${cityName}. Include information about packing materials, fragile item handling, and how you protect belongings during moves in this location...`
        };
      case 'storage-solutions':
        return {
          heading: `Secure Storage Solutions in ${cityName}`,
          content: `Write about storage facilities in ${cityName}. Include information about storage units, security features, accessibility, and flexible storage options available in this location...`
        };
      default:
        return {
          heading: `Professional Services in ${cityName}`,
          content: `Write about services in ${cityName}. Include local information and unique selling points...`
        };
    }
  };

  const [blocks, setBlocks] = useState<ContentBlock[]>([
    {
      block_position: 1,
      heading: '',
      content: '',
      image_url: '',
      image_alt: ''
    },
    {
      block_position: 2,
      heading: '',
      content: '',
      image_url: '',
      image_alt: ''
    },
    {
      block_position: 3,
      heading: '',
      content: '',
      image_url: '',
      image_alt: ''
    }
  ]);

  useEffect(() => {
    loadContentBlocks();
  }, [cityId, selectedService]);

  const loadContentBlocks = async () => {
    setLoading(true);
    setError(null);

    console.log('[CityContentEditor] Loading blocks for:', {
      cityId,
      cityName,
      selectedService
    });

    try {
      const { data, error: fetchError } = await supabase
        .from('city_content_blocks')
        .select('*')
        .eq('city_id', cityId)
        .eq('service_type', selectedService)
        .order('block_position');

      if (fetchError) {
        console.error('[CityContentEditor] Fetch error:', fetchError);
        throw fetchError;
      }

      console.log('[CityContentEditor] Fetched data:', data);
      console.log('[CityContentEditor] Found', data?.length || 0, 'blocks');

      // Always create blocks array, whether data exists or not
      const loadedBlocks = [1, 2, 3].map(position => {
        const existingBlock = data?.find(b => b.block_position === position);
        if (existingBlock) {
          console.log(`[CityContentEditor] Block ${position}: FOUND (id: ${existingBlock.id})`, {
            heading: existingBlock.heading || '(empty)',
            content_length: existingBlock.content?.length || 0,
            has_heading: !!existingBlock.heading,
            has_content: !!existingBlock.content
          });
        } else {
          console.log(`[CityContentEditor] Block ${position}: EMPTY (not in database)`);
        }
        return existingBlock || {
          block_position: position,
          heading: '',
          content: '',
          image_url: '',
          image_alt: ''
        };
      });

      setBlocks(loadedBlocks);
      console.log('[CityContentEditor] Set blocks:', loadedBlocks);
    } catch (err) {
      console.error('[CityContentEditor] Error loading content blocks:', err);
      setError(err instanceof Error ? err.message : 'Failed to load content');
    } finally {
      setLoading(false);
    }
  };

  const updateBlock = (position: number, field: keyof ContentBlock, value: string) => {
    console.log(`[CityContentEditor] updateBlock called:`, {
      position,
      field,
      value_length: value.length,
      value_preview: value.substring(0, 50)
    });

    setBlocks(prevBlocks => {
      const updated = prevBlocks.map(block =>
        block.block_position === position
          ? { ...block, [field]: value }
          : block
      );
      console.log(`[CityContentEditor] Blocks after update:`, updated.map(b => ({
        position: b.block_position,
        has_heading: !!b.heading,
        has_content: !!b.content,
        heading_length: b.heading?.length || 0,
        content_length: b.content?.length || 0
      })));
      return updated;
    });
  };

  const handleImageUpload = async (position: number, file: File) => {
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file (JPG, PNG, WebP, etc.)');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError('Image size must be less than 5MB');
      return;
    }

    setUploading(position);
    setError(null);

    try {
      // Create a unique filename
      const fileExt = file.name.split('.').pop();
      const fileName = `${cityName.toLowerCase().replace(/\s+/g, '-')}-${selectedService}-block${position}-${Date.now()}.${fileExt}`;
      const filePath = `city-content/${fileName}`;

      // Upload to Supabase Storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('seo-images')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        throw uploadError;
      }

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('seo-images')
        .getPublicUrl(filePath);

      // Update the block with the new image URL
      updateBlock(position, 'image_url', publicUrl);

      // Auto-generate alt text if empty
      const block = blocks.find(b => b.block_position === position);
      if (block && !block.image_alt) {
        updateBlock(position, 'image_alt', `${cityName} - ${block.heading || 'content image'}`);
      }

    } catch (err) {
      console.error('Error uploading image:', err);
      setError(err instanceof Error ? err.message : 'Failed to upload image');
    } finally {
      setUploading(null);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    setSuccess(false);

    console.log('[CityContentEditor] Starting save for:', {
      cityId,
      cityName,
      selectedService,
      blocksCount: blocks.length
    });

    // Check authentication
    const { data: { user } } = await supabase.auth.getUser();
    console.log('[CityContentEditor] Current user:', {
      id: user?.id,
      email: user?.email,
      isAuthenticated: !!user
    });

    if (!user) {
      setError('You must be logged in to save content');
      setSaving(false);
      return;
    }

    try {
      // STEP 1: Delete all existing blocks for this city + service
      console.log('[CityContentEditor] Deleting existing blocks for:', {
        city_id: cityId,
        service_type: selectedService
      });

      const { error: deleteError } = await supabase
        .from('city_content_blocks')
        .delete()
        .eq('city_id', cityId)
        .eq('service_type', selectedService);

      if (deleteError) {
        console.error('[CityContentEditor] Delete error:', deleteError);
        throw deleteError;
      }

      console.log('[CityContentEditor] Existing blocks deleted successfully');

      // STEP 2: Insert only non-empty blocks
      const blocksToSave = blocks.filter(block => block.heading && block.content);

      console.log('[CityContentEditor] Blocks to save:', blocksToSave.length, 'out of', blocks.length);

      if (blocksToSave.length === 0) {
        console.log('[CityContentEditor] No blocks to save (all empty). Database cleared.');
        setSuccess(true);
        await loadContentBlocks();

        setTimeout(() => {
          onSuccess();
          onClose();
        }, 1500);
        return;
      }

      const blockDataArray = blocksToSave.map(block => ({
        city_id: cityId,
        service_type: selectedService,
        block_position: block.block_position,
        heading: block.heading,
        content: block.content,
        image_url: block.image_url || null,
        image_alt: block.image_alt || `${cityName} - ${block.heading}`
      }));

      console.log('[CityContentEditor] Inserting blocks:', blockDataArray.map(b => ({
        position: b.block_position,
        heading: b.heading.substring(0, 30),
        content_length: b.content.length
      })));

      const { data, error: insertError } = await supabase
        .from('city_content_blocks')
        .insert(blockDataArray)
        .select();

      if (insertError) {
        console.error('[CityContentEditor] Insert error:', insertError);
        throw insertError;
      }

      console.log(`[CityContentEditor] Successfully saved ${data?.length || 0} blocks`);
      setSuccess(true);

      // Reload the blocks to show the saved data
      await loadContentBlocks();

      setTimeout(() => {
        onSuccess();
        onClose();
      }, 1500);
    } catch (err) {
      console.error('[CityContentEditor] Error saving content blocks:', err);
      setError(err instanceof Error ? err.message : 'Failed to save content');
    } finally {
      setSaving(false);
    }
  };

  const getCharCount = (text: string) => text.length;
  const getWordCount = (text: string) => text.trim().split(/\s+/).filter(Boolean).length;

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl max-w-4xl w-full p-8">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#e71c5e]"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-white rounded-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto p-6 my-8">
        <div className="flex justify-between items-center mb-6 sticky top-0 bg-white pb-4 border-b">
          <div>
            <h3 className="text-2xl font-bold text-gray-900">
              SEO Content for {cityName}
            </h3>
            <p className="text-sm text-gray-600 mt-1">
              Add three unique content blocks with headings, text, and images to optimize this city page for search engines
            </p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X size={24} />
          </button>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-red-900">Error</p>
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        )}

        {success && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-green-900">Success</p>
              <p className="text-sm text-green-700">Content blocks saved successfully!</p>
            </div>
          </div>
        )}

        <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <label className="block text-sm font-medium text-gray-900 mb-3">
            Select Service Type
          </label>
          <select
            value={selectedService}
            onChange={(e) => {
              console.log('[CityContentEditor] Service changed from', selectedService, 'to', e.target.value);
              console.log('[CityContentEditor] Current blocks before change:', blocks.map(b => ({
                position: b.block_position,
                has_heading: !!b.heading,
                has_content: !!b.content
              })));
              setSelectedService(e.target.value);
            }}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent bg-white text-base"
          >
            {serviceTypes.map((service) => (
              <option key={service.value} value={service.value}>
                {service.label}
              </option>
            ))}
          </select>
          <p className="text-sm text-gray-600 mt-2">
            Create unique content for each service. Each service can have its own 3 content blocks with different headings, text, and images.
          </p>
        </div>

        <div className="space-y-8">
          {blocks.map((block, index) => (
            <div key={block.block_position} className="bg-gray-50 rounded-lg p-6 border border-gray-200">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                  {block.block_position}
                </div>
                <h4 className="text-lg font-bold text-gray-900">Content Block {block.block_position}</h4>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    H2 Heading *
                    <span className="text-gray-500 font-normal ml-2">
                      ({getCharCount(block.heading)} characters)
                    </span>
                  </label>
                  <input
                    type="text"
                    value={block.heading}
                    onChange={(e) => updateBlock(block.block_position, 'heading', e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                    placeholder={`e.g., ${getPlaceholders(selectedService).heading}`}
                    maxLength={100}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Keep it under 60-70 characters for optimal SEO. Make it unique and location-specific.
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Content Text *
                    <span className="text-gray-500 font-normal ml-2">
                      ({getWordCount(block.content)} words, {getCharCount(block.content)} characters)
                    </span>
                  </label>
                  <textarea
                    value={block.content}
                    onChange={(e) => updateBlock(block.block_position, 'content', e.target.value)}
                    rows={6}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                    placeholder={getPlaceholders(selectedService).content}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Aim for 150-300 words. Include location-specific information and relevant keywords naturally.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Image
                      <span className="text-gray-500 font-normal ml-2">(Optional)</span>
                    </label>
                    <div className="space-y-2">
                      {/* Upload Button */}
                      <label className="flex items-center justify-center gap-2 w-full px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg hover:border-[#e71c5e] hover:bg-gray-50 cursor-pointer transition-colors">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              handleImageUpload(block.block_position, file);
                            }
                          }}
                          className="hidden"
                          disabled={uploading === block.block_position}
                        />
                        {uploading === block.block_position ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-2 border-[#e71c5e] border-t-transparent"></div>
                            <span className="text-sm text-gray-600">Uploading...</span>
                          </>
                        ) : (
                          <>
                            <Upload size={18} className="text-gray-400" />
                            <span className="text-sm text-gray-600">Upload Image</span>
                          </>
                        )}
                      </label>

                      {/* OR Divider */}
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-px bg-gray-300"></div>
                        <span className="text-xs text-gray-500">OR</span>
                        <div className="flex-1 h-px bg-gray-300"></div>
                      </div>

                      {/* URL Input */}
                      <div className="relative">
                        <ImageIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                        <input
                          type="url"
                          value={block.image_url}
                          onChange={(e) => updateBlock(block.block_position, 'image_url', e.target.value)}
                          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                          placeholder="Enter image URL"
                        />
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      Upload an image (max 5MB) or paste a URL. High-quality images work best (min 800x600px).
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Image Alt Text
                      <span className="text-gray-500 font-normal ml-2">(Auto-generated if empty)</span>
                    </label>
                    <input
                      type="text"
                      value={block.image_alt}
                      onChange={(e) => updateBlock(block.block_position, 'image_alt', e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                      placeholder={`${cityName} - ${block.heading || 'content image'}`}
                      maxLength={125}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Describe the image for accessibility and SEO.
                    </p>
                  </div>
                </div>

                {block.image_url && (
                  <div className="mt-4">
                    <p className="text-sm font-medium text-gray-700 mb-2">Image Preview</p>
                    <div className="relative w-full h-48 bg-gray-100 rounded-lg overflow-hidden">
                      <img
                        src={block.image_url}
                        alt={block.image_alt || 'Preview'}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100" height="100"%3E%3Crect fill="%23ddd" width="100" height="100"/%3E%3Ctext fill="%23999" x="50%25" y="50%25" text-anchor="middle" dy=".3em"%3EInvalid URL%3C/text%3E%3C/svg%3E';
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 pt-6 border-t flex justify-between items-center sticky bottom-0 bg-white">
          <p className="text-sm text-gray-600">
            * Required fields. Fill in at least the heading and content for each block.
          </p>
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              disabled={saving}
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-2 bg-[#e71c5e] text-white px-6 py-2 rounded-lg hover:bg-[#c91852] transition-colors disabled:opacity-50"
            >
              <Save size={20} />
              {saving ? 'Saving...' : 'Save Content'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
