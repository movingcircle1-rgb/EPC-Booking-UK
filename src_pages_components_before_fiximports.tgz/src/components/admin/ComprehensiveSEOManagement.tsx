import { useEffect, useState } from 'react';
import { Search, Save, X, Globe, MapPin, FileText, Plus, Edit2, Trash2, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';

type TabType = 'website' | 'locations' | 'articles';

interface SEOData {
  id: string;
  page_path: string;
  page_title: string;
  meta_title: string;
  meta_description: string;
  meta_keywords?: string;
  og_image?: string;
  canonical_url?: string;
  robots?: string;
  updated_at?: string;
}

interface LocationSEO {
  id: string;
  name: string;
  slug: string;
  meta_title: string;
  meta_description: string;
}

interface CityServiceContent {
  id: string;
  city_id: string;
  service_type: string;
  content: string;
  meta_title: string | null;
  meta_description: string | null;
}

interface ArticleSEO {
  id: string;
  title: string;
  slug: string;
  meta_title: string | null;
  meta_description: string | null;
  status: string;
}

export default function ComprehensiveSEOManagement() {
  const [activeTab, setActiveTab] = useState<TabType>('website');
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Website Pages State
  const [websitePages, setWebsitePages] = useState<SEOData[]>([]);
  const [editingWebsite, setEditingWebsite] = useState<SEOData | null>(null);

  // Location Pages State
  const [locationPages, setLocationPages] = useState<LocationSEO[]>([]);
  const [editingLocation, setEditingLocation] = useState<LocationSEO | null>(null);
  const [selectedCity, setSelectedCity] = useState<string | null>(null);
  const [serviceContents, setServiceContents] = useState<CityServiceContent[]>([]);
  const [editingService, setEditingService] = useState<CityServiceContent | null>(null);
  const [selectedServiceType, setSelectedServiceType] = useState<string>('house-removals');

  // Article Pages State
  const [articlePages, setArticlePages] = useState<ArticleSEO[]>([]);
  const [editingArticle, setEditingArticle] = useState<ArticleSEO | null>(null);

  useEffect(() => {
    loadAllCounts();
  }, []);

  useEffect(() => {
    loadData();
  }, [activeTab]);

  const loadAllCounts = async () => {
    try {
      await Promise.all([
        loadWebsitePages(),
        loadLocationPages(),
        loadArticlePages()
      ]);
    } catch (error) {
      console.error('Error loading counts:', error);
    }
  };

  const loadData = async () => {
    setLoading(true);
    try {
      if (activeTab === 'website') {
        await loadWebsitePages();
      } else if (activeTab === 'locations') {
        await loadLocationPages();
      } else if (activeTab === 'articles') {
        await loadArticlePages();
      }
    } catch (error) {
      console.error('Error loading data:', error);
    }
    setLoading(false);
  };

  const loadWebsitePages = async () => {
    const { data, error } = await supabase
      .from('page_seo_metadata')
      .select('*')
      .order('page_path');

    if (!error && data) {
      setWebsitePages(data);
    }
  };

  const loadLocationPages = async () => {
    const { data, error } = await supabase
      .from('cities')
      .select('id, name, slug, meta_title, meta_description')
      .order('name');

    if (!error && data) {
      setLocationPages(data);
    }
  };

  const loadServiceContents = async (cityId: string) => {
    const { data, error } = await supabase
      .from('city_service_content')
      .select('*')
      .eq('city_id', cityId)
      .order('service_type');

    if (!error && data) {
      setServiceContents(data);
    } else {
      setServiceContents([]);
    }
  };

  const loadArticlePages = async () => {
    const { data, error } = await supabase
      .from('articles')
      .select('id, title, slug, meta_title, meta_description, status')
      .order('title');

    if (!error && data) {
      setArticlePages(data);
    }
  };

  const showMessage = (type: 'success' | 'error', text: string) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 3000);
  };

  // Website Pages Functions
  const handleSaveWebsite = async () => {
    if (!editingWebsite) return;

    setSaving(true);
    const { error } = await supabase
      .from('page_seo_metadata')
      .upsert({
        ...editingWebsite,
        updated_at: new Date().toISOString(),
      });

    setSaving(false);
    if (error) {
      showMessage('error', 'Failed to save website page SEO');
    } else {
      showMessage('success', 'Website page SEO updated successfully');
      setEditingWebsite(null);
      loadWebsitePages();
    }
  };

  const handleDeleteWebsite = async (id: string) => {
    if (!confirm('Delete this SEO entry?')) return;

    const { error } = await supabase
      .from('page_seo_metadata')
      .delete()
      .eq('id', id);

    if (!error) {
      showMessage('success', 'SEO entry deleted');
      loadWebsitePages();
    }
  };

  // Location Pages Functions
  const handleSaveLocation = async () => {
    if (!editingLocation) return;

    setSaving(true);
    const { error } = await supabase
      .from('cities')
      .update({
        meta_title: editingLocation.meta_title || '',
        meta_description: editingLocation.meta_description || '',
      })
      .eq('id', editingLocation.id);

    setSaving(false);
    if (error) {
      showMessage('error', 'Failed to save location SEO');
    } else {
      showMessage('success', 'Location SEO updated successfully');
      setEditingLocation(null);
      loadLocationPages();
    }
  };

  const handleSaveServiceContent = async () => {
    if (!editingService) return;

    // Validate required fields
    if (!editingService.content || !editingService.content.trim()) {
      showMessage('error', 'Content is required');
      return;
    }

    setSaving(true);

    try {
      const dataToSave: any = {
        city_id: editingService.city_id,
        service_type: editingService.service_type,
        content: editingService.content,
        meta_title: editingService.meta_title,
        meta_description: editingService.meta_description,
        updated_at: new Date().toISOString(),
      };

      // Only include id for updates
      if (editingService.id && editingService.id !== '') {
        dataToSave.id = editingService.id;
      }

      console.log('Saving service content:', dataToSave);

      const { data, error } = await supabase
        .from('city_service_content')
        .upsert(dataToSave, {
          onConflict: 'city_id,service_type'
        })
        .select();

      console.log('Save result:', { data, error });

      if (error) {
        console.error('Save error:', error);
        showMessage('error', `Failed to save: ${error.message}`);
      } else {
        showMessage('success', 'Service content saved successfully');
        setEditingService(null);
        if (selectedCity) {
          loadServiceContents(selectedCity);
        }
      }
    } catch (err) {
      console.error('Unexpected error:', err);
      showMessage('error', 'An unexpected error occurred');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteServiceContent = async (id: string) => {
    if (!confirm('Delete this service content?')) return;

    const { error } = await supabase
      .from('city_service_content')
      .delete()
      .eq('id', id);

    if (!error) {
      showMessage('success', 'Service content deleted');
      if (selectedCity) {
        loadServiceContents(selectedCity);
      }
    }
  };

  const handleAddNewServiceContent = (cityId: string, cityName: string) => {
    // Find which service types already have content
    const existingServiceTypes = serviceContents.map(sc => sc.service_type);
    const allServiceTypes = ['house-removals', 'office-removals', 'packing-services', 'storage-solutions'];
    const availableServiceTypes = allServiceTypes.filter(st => !existingServiceTypes.includes(st));

    if (availableServiceTypes.length === 0) {
      alert('All service types already have content for this city.');
      return;
    }

    setEditingService({
      id: '',
      city_id: cityId,
      service_type: availableServiceTypes[0],
      content: '',
      meta_title: null,
      meta_description: null,
    });
  };

  // Article Pages Functions
  const handleSaveArticle = async () => {
    if (!editingArticle) return;

    setSaving(true);
    const { error } = await supabase
      .from('articles')
      .update({
        meta_title: editingArticle.meta_title,
        meta_description: editingArticle.meta_description,
      })
      .eq('id', editingArticle.id);

    setSaving(false);
    if (error) {
      showMessage('error', 'Failed to save article SEO');
    } else {
      showMessage('success', 'Article SEO updated successfully');
      setEditingArticle(null);
      loadArticlePages();
    }
  };

  const filteredWebsitePages = websitePages.filter(page =>
    page.page_path.toLowerCase().includes(searchTerm.toLowerCase()) ||
    page.page_title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredLocationPages = locationPages.filter(loc =>
    loc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    loc.slug.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredArticlePages = articlePages.filter(article =>
    article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    article.slug.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">SEO Management</h2>
          <p className="text-gray-600 mt-1">Centralized SEO control for all pages</p>
        </div>
      </div>

      {message && (
        <div className={`p-4 rounded-lg flex items-center gap-2 ${
          message.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
        }`}>
          {message.type === 'success' ? <CheckCircle size={20} /> : <AlertCircle size={20} />}
          {message.text}
        </div>
      )}

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <div className="flex gap-4">
          <button
            onClick={() => setActiveTab('website')}
            className={`px-6 py-3 font-medium border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'website'
                ? 'border-[#e71c5e] text-[#e71c5e]'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <Globe size={20} />
            Website Pages
            <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-sm">
              {websitePages.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('locations')}
            className={`px-6 py-3 font-medium border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'locations'
                ? 'border-[#e71c5e] text-[#e71c5e]'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <MapPin size={20} />
            Location Pages
            <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-sm">
              {locationPages.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('articles')}
            className={`px-6 py-3 font-medium border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'articles'
                ? 'border-[#e71c5e] text-[#e71c5e]'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <FileText size={20} />
            Article Pages
            <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-sm">
              {articlePages.length}
            </span>
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
        <input
          type="text"
          placeholder={`Search ${activeTab} pages...`}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
        />
      </div>

      {/* Content */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#e71c5e]"></div>
        </div>
      ) : (
        <>
          {/* Website Pages Tab */}
          {activeTab === 'website' && (
            <div className="space-y-4">
              {filteredWebsitePages.map((page) => (
                <div key={page.id} className="bg-white border border-gray-200 rounded-lg p-6">
                  {editingWebsite?.id === page.id ? (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Page Path</label>
                        <input
                          type="text"
                          value={editingWebsite.page_path}
                          onChange={(e) => setEditingWebsite({ ...editingWebsite, page_path: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                          disabled
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Page Title</label>
                        <input
                          type="text"
                          value={editingWebsite.page_title}
                          onChange={(e) => setEditingWebsite({ ...editingWebsite, page_title: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Meta Title</label>
                        <input
                          type="text"
                          value={editingWebsite.meta_title}
                          onChange={(e) => setEditingWebsite({ ...editingWebsite, meta_title: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                          maxLength={60}
                        />
                        <p className="text-sm text-gray-500 mt-1">{editingWebsite.meta_title.length}/60 characters</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Meta Description</label>
                        <textarea
                          value={editingWebsite.meta_description}
                          onChange={(e) => setEditingWebsite({ ...editingWebsite, meta_description: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                          rows={3}
                          maxLength={160}
                        />
                        <p className="text-sm text-gray-500 mt-1">{editingWebsite.meta_description.length}/160 characters</p>
                      </div>
                      <div className="flex gap-3">
                        <button
                          onClick={handleSaveWebsite}
                          disabled={saving}
                          className="px-4 py-2 bg-[#e71c5e] text-white rounded-lg hover:bg-[#c91852] disabled:opacity-50"
                        >
                          {saving ? 'Saving...' : 'Save Changes'}
                        </button>
                        <button
                          onClick={() => setEditingWebsite(null)}
                          className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-gray-900">{page.page_title}</h3>
                          <p className="text-sm text-gray-500">{page.page_path}</p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setEditingWebsite(page)}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                          >
                            <Edit2 size={18} />
                          </button>
                          <button
                            onClick={() => handleDeleteWebsite(page.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div>
                          <span className="font-medium text-gray-700">Meta Title:</span>
                          <p className="text-gray-600">{page.meta_title}</p>
                        </div>
                        <div>
                          <span className="font-medium text-gray-700">Meta Description:</span>
                          <p className="text-gray-600">{page.meta_description}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Location Pages Tab */}
          {activeTab === 'locations' && (
            <div className="space-y-4">
              {filteredLocationPages.map((location) => (
                <div key={location.id} className="bg-white border border-gray-200 rounded-lg p-6">
                  {editingLocation?.id === location.id ? (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Location Name</label>
                        <input
                          type="text"
                          value={location.name}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
                          disabled
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Meta Title</label>
                        <input
                          type="text"
                          value={editingLocation.meta_title || ''}
                          onChange={(e) => setEditingLocation({ ...editingLocation, meta_title: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                          maxLength={60}
                          placeholder={`Removals ${location.name} | National Removals and Storage`}
                        />
                        <p className="text-sm text-gray-500 mt-1">{(editingLocation.meta_title || '').length}/60 characters</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Meta Description</label>
                        <textarea
                          value={editingLocation.meta_description || ''}
                          onChange={(e) => setEditingLocation({ ...editingLocation, meta_description: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                          rows={3}
                          maxLength={160}
                          placeholder={`Expert house and office removals in ${location.name}. Professional moving services with secure storage solutions.`}
                        />
                        <p className="text-sm text-gray-500 mt-1">{(editingLocation.meta_description || '').length}/160 characters</p>
                      </div>
                      <div className="flex gap-3">
                        <button
                          onClick={handleSaveLocation}
                          disabled={saving}
                          className="px-4 py-2 bg-[#e71c5e] text-white rounded-lg hover:bg-[#c91852] disabled:opacity-50"
                        >
                          {saving ? 'Saving...' : 'Save Changes'}
                        </button>
                        <button
                          onClick={() => setEditingLocation(null)}
                          className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : selectedCity === location.id ? (
                    <div>
                      <div className="flex items-start justify-between mb-6">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-gray-900">{location.name}</h3>
                          <p className="text-sm text-gray-500">/removals-{location.slug}</p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleAddNewServiceContent(location.id, location.name)}
                            className="px-4 py-2 bg-[#e71c5e] text-white rounded-lg hover:bg-[#c91852] flex items-center gap-2"
                          >
                            <Plus size={18} />
                            Add Service Content
                          </button>
                          <button
                            onClick={() => setEditingLocation(location)}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                          >
                            <Edit2 size={18} />
                          </button>
                          <button
                            onClick={() => {
                              setSelectedCity(null);
                              setServiceContents([]);
                            }}
                            className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg"
                          >
                            <X size={18} />
                          </button>
                        </div>
                      </div>

                      {/* Service Content List */}
                      <div className="space-y-4">
                        <h4 className="font-medium text-gray-900">Service-Specific Content:</h4>
                        {serviceContents.length === 0 ? (
                          <p className="text-gray-500 italic">No service content added yet. Click "Add Service Content" to get started.</p>
                        ) : (
                          serviceContents.map((serviceContent) => (
                            <div key={serviceContent.id} className="border border-gray-200 rounded-lg p-4">
                              {editingService?.id === serviceContent.id ? (
                                <div className="space-y-4">
                                  <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Select Service Type</label>
                                    <select
                                      value={editingService.service_type}
                                      onChange={(e) => setEditingService({ ...editingService, service_type: e.target.value })}
                                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                                      disabled={!!serviceContent.id}
                                    >
                                      <option value="house-removals">House Removals</option>
                                      <option value="office-removals">Office Removals</option>
                                      <option value="packing-services">Packing Services</option>
                                      <option value="storage-solutions">Storage Solutions</option>
                                    </select>
                                  </div>
                                  <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">Service Content</label>
                                    <textarea
                                      value={editingService.content}
                                      onChange={(e) => setEditingService({ ...editingService, content: e.target.value })}
                                      className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                                      rows={6}
                                      placeholder="Enter unique content for this service type..."
                                    />
                                  </div>
                                  <div className="flex gap-3">
                                    <button
                                      onClick={handleSaveServiceContent}
                                      disabled={saving}
                                      className="px-4 py-2 bg-[#e71c5e] text-white rounded-lg hover:bg-[#c91852] disabled:opacity-50"
                                    >
                                      {saving ? 'Saving...' : 'Save'}
                                    </button>
                                    <button
                                      onClick={() => setEditingService(null)}
                                      className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                                    >
                                      Cancel
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <div>
                                  <div className="flex items-start justify-between mb-2">
                                    <span className="inline-flex items-center px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                                      {serviceContent.service_type === 'house-removals' ? 'House Removals' :
                                       serviceContent.service_type === 'office-removals' ? 'Office Removals' :
                                       serviceContent.service_type === 'packing-services' ? 'Packing Services' :
                                       'Storage Solutions'}
                                    </span>
                                    <div className="flex gap-2">
                                      <button
                                        onClick={() => setEditingService(serviceContent)}
                                        className="p-1 text-blue-600 hover:bg-blue-50 rounded"
                                      >
                                        <Edit2 size={16} />
                                      </button>
                                      <button
                                        onClick={() => handleDeleteServiceContent(serviceContent.id)}
                                        className="p-1 text-red-600 hover:bg-red-50 rounded"
                                      >
                                        <Trash2 size={16} />
                                      </button>
                                    </div>
                                  </div>
                                  <p className="text-sm text-gray-600 line-clamp-3">{serviceContent.content}</p>
                                </div>
                              )}
                            </div>
                          ))
                        )}
                      </div>

                      {/* Add new service content form */}
                      {editingService && !editingService.id && (
                        <div className="border border-blue-200 rounded-lg p-4 bg-blue-50 mt-4">
                          <h5 className="font-medium text-gray-900 mb-4">Add New Service Content</h5>
                          <div className="space-y-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">Select Service Type</label>
                              <select
                                value={editingService.service_type}
                                onChange={(e) => setEditingService({ ...editingService, service_type: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                              >
                                {['house-removals', 'office-removals', 'packing-services', 'storage-solutions']
                                  .filter(st => !serviceContents.find(sc => sc.service_type === st))
                                  .map(st => (
                                    <option key={st} value={st}>
                                      {st === 'house-removals' ? 'House Removals' :
                                       st === 'office-removals' ? 'Office Removals' :
                                       st === 'packing-services' ? 'Packing Services' :
                                       'Storage Solutions'}
                                    </option>
                                  ))}
                              </select>
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">Service Content</label>
                              <textarea
                                value={editingService.content}
                                onChange={(e) => setEditingService({ ...editingService, content: e.target.value })}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                                rows={6}
                                placeholder="Enter unique content for this service type..."
                              />
                            </div>
                            <div className="flex gap-3">
                              <button
                                onClick={handleSaveServiceContent}
                                disabled={saving}
                                className="px-4 py-2 bg-[#e71c5e] text-white rounded-lg hover:bg-[#c91852] disabled:opacity-50"
                              >
                                {saving ? 'Saving...' : 'Save'}
                              </button>
                              <button
                                onClick={() => setEditingService(null)}
                                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                              >
                                Cancel
                              </button>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div>
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-gray-900">{location.name}</h3>
                          <p className="text-sm text-gray-500">/removals-{location.slug}</p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => {
                              setSelectedCity(location.id);
                              loadServiceContents(location.id);
                            }}
                            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                          >
                            Manage Services
                          </button>
                          <button
                            onClick={() => setEditingLocation(location)}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                          >
                            <Edit2 size={18} />
                          </button>
                        </div>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div>
                          <span className="font-medium text-gray-700">Meta Title:</span>
                          <p className="text-gray-600">{location.meta_title || <span className="text-gray-400 italic">Not set</span>}</p>
                        </div>
                        <div>
                          <span className="font-medium text-gray-700">Meta Description:</span>
                          <p className="text-gray-600">{location.meta_description || <span className="text-gray-400 italic">Not set</span>}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Article Pages Tab */}
          {activeTab === 'articles' && (
            <div className="space-y-4">
              {filteredArticlePages.map((article) => (
                <div key={article.id} className="bg-white border border-gray-200 rounded-lg p-6">
                  {editingArticle?.id === article.id ? (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Article Title</label>
                        <input
                          type="text"
                          value={article.title}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
                          disabled
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Meta Title</label>
                        <input
                          type="text"
                          value={editingArticle.meta_title || ''}
                          onChange={(e) => setEditingArticle({ ...editingArticle, meta_title: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                          maxLength={60}
                          placeholder={article.title}
                        />
                        <p className="text-sm text-gray-500 mt-1">{(editingArticle.meta_title || '').length}/60 characters</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Meta Description</label>
                        <textarea
                          value={editingArticle.meta_description || ''}
                          onChange={(e) => setEditingArticle({ ...editingArticle, meta_description: e.target.value })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                          rows={3}
                          maxLength={160}
                        />
                        <p className="text-sm text-gray-500 mt-1">{(editingArticle.meta_description || '').length}/160 characters</p>
                      </div>
                      <div className="flex gap-3">
                        <button
                          onClick={handleSaveArticle}
                          disabled={saving}
                          className="px-4 py-2 bg-[#e71c5e] text-white rounded-lg hover:bg-[#c91852] disabled:opacity-50"
                        >
                          {saving ? 'Saving...' : 'Save Changes'}
                        </button>
                        <button
                          onClick={() => setEditingArticle(null)}
                          className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="text-lg font-semibold text-gray-900">{article.title}</h3>
                            <span className={`text-xs px-2 py-1 rounded-full ${
                              article.status === 'published' ? 'bg-green-100 text-green-800' :
                              article.status === 'draft' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-gray-100 text-gray-800'
                            }`}>
                              {article.status}
                            </span>
                          </div>
                          <p className="text-sm text-gray-500">/articles/{article.slug}</p>
                        </div>
                        <button
                          onClick={() => setEditingArticle(article)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                        >
                          <Edit2 size={18} />
                        </button>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div>
                          <span className="font-medium text-gray-700">Meta Title:</span>
                          <p className="text-gray-600">{article.meta_title || <span className="text-gray-400 italic">Using article title</span>}</p>
                        </div>
                        <div>
                          <span className="font-medium text-gray-700">Meta Description:</span>
                          <p className="text-gray-600">{article.meta_description || <span className="text-gray-400 italic">Not set</span>}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
