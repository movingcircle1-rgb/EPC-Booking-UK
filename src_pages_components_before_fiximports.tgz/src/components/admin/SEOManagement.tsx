import { useEffect, useState } from 'react';
import { Search, Save, X, AlertCircle, CheckCircle, Upload, Download, ExternalLink, RefreshCw, Edit, Trash2, Plus } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { branding } from '../../config/branding';

interface SEOMetadata {
  id: string;
  page_path: string;
  page_title: string;
  meta_title: string;
  meta_description: string;
  meta_keywords: string;
  canonical_url: string | null;
  og_image: string | null;
  og_type: string;
  robots: string;
  priority: number;
  changefreq: string;
  last_crawled: string | null;
  crawl_status: string;
  created_at: string;
  updated_at: string;
}

export default function SEOManagement() {
  const [seoData, setSeoData] = useState<SEOMetadata[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingPage, setEditingPage] = useState<SEOMetadata | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [importData, setImportData] = useState('');
  const [showImport, setShowImport] = useState(false);
  const [discovering, setDiscovering] = useState(false);
  const [discoveredPages, setDiscoveredPages] = useState<any[]>([]);
  const [showDiscovery, setShowDiscovery] = useState(false);
  const [orphanedPages, setOrphanedPages] = useState<string[]>([]);
  const [cleaning, setCleaning] = useState(false);

  const emptyMetadata: Omit<SEOMetadata, 'id' | 'created_at' | 'updated_at' | 'last_crawled' | 'crawl_status'> = {
    page_path: '',
    page_title: '',
    meta_title: '',
    meta_description: '',
    meta_keywords: '',
    canonical_url: null,
    og_image: null,
    og_type: 'website',
    robots: 'index, follow',
    priority: 0.8,
    changefreq: 'weekly',
  };

  const [formData, setFormData] = useState<Omit<SEOMetadata, 'id' | 'created_at' | 'updated_at' | 'last_crawled' | 'crawl_status'>>(emptyMetadata);

  useEffect(() => {
    loadSEOData();
    discoverPages();
  }, []);

  const loadSEOData = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('page_seo_metadata')
      .select('*')
      .order('page_path');

    if (!error && data) {
      setSeoData(data);
    } else if (error) {
      console.error('Error loading SEO data:', error);
    }
    setLoading(false);
  };

  const discoverPages = async () => {
    setDiscovering(true);
    try {
      const pages: any[] = [];

      const staticRoutes = [
        { path: '/', title: 'Home', description: 'Professional removal services across the UK' },
        { path: '/about', title: 'About Us', description: 'Learn about National Removals' },
        { path: '/services', title: 'Our Services', description: 'Comprehensive moving and storage solutions' },
        { path: '/removals', title: 'Removals', description: 'Professional removal services' },
        { path: '/house-removals', title: 'House Removals', description: 'Residential moving solutions' },
        { path: '/office-removals', title: 'Office Removals', description: 'Commercial relocation services' },
        { path: '/packing-services', title: 'Packing Services', description: 'Expert packing solutions' },
        { path: '/storage', title: 'Storage Solutions', description: 'Secure storage facilities' },
        { path: '/european-moves', title: 'European Moves', description: 'Moving across Europe' },
        { path: '/international-moves', title: 'International Moves', description: 'Worldwide relocations' },
        { path: '/contact', title: 'Contact Us', description: 'Get in touch for a quote' },
        { path: '/blue-light-card', title: 'Blue Light Card Discount', description: 'NHS and emergency services discounts' },
        { path: '/mid-week-move', title: 'Mid-Week Move Discount', description: 'Save on mid-week moves' },
        { path: '/free-storage', title: 'Free Storage Offer', description: 'Free storage with moves' },
        { path: '/furniture-removal', title: 'Furniture Removal', description: 'Furniture donation and collection' },
        { path: '/we-recommend', title: 'We Recommend', description: 'Our trusted partners' },
        { path: '/we-donate', title: 'We Donate', description: 'Charity donation program' },
        { path: '/we-recycle', title: 'We Recycle', description: 'Environmental commitment' },
        { path: '/low-emission-promise', title: 'Low Emission Promise', description: 'Carbon neutral removals' },
        { path: '/how-it-works', title: 'How It Works', description: 'Our moving process explained' },
      ];

      pages.push(...staticRoutes.map(r => ({ ...r, type: 'static' })));

      const { data: articles } = await supabase
        .from('articles')
        .select('slug, title, meta_title, meta_description, status')
        .eq('status', 'published');

      if (articles) {
        articles.forEach(article => {
          pages.push({
            path: `/articles/${article.slug}`,
            title: article.title,
            description: article.meta_description || `Read ${article.title}`,
            type: 'article',
            meta_title: article.meta_title || article.title
          });
        });
      }

      const { data: locations } = await supabase
        .from('locations')
        .select('city_slug, city, county');

      if (locations) {
        locations.forEach(location => {
          pages.push({
            path: `/removals/${location.city_slug}`,
            title: `Removals in ${location.city}`,
            description: `Professional removal services in ${location.city}${location.county ? ', ' + location.county : ''}`,
            type: 'location'
          });
        });
      }

      setDiscoveredPages(pages);

      // Detect orphaned SEO entries (pages that no longer exist)
      const activePaths = pages.map(p => p.path);
      const orphaned = seoData
        .filter(seo => !activePaths.includes(seo.page_path))
        .filter(seo => !seo.page_path.startsWith('/admin') && !seo.page_path.startsWith('/client-portal') && !seo.page_path.startsWith('/staff-portal') && !seo.page_path.startsWith('/partner-portal') && !seo.page_path.startsWith('/trade-portal'))
        .map(seo => seo.page_path);

      setOrphanedPages(orphaned);
    } catch (err) {
      console.error('Error discovering pages:', err);
    } finally {
      setDiscovering(false);
    }
  };

  const cleanupOrphanedPages = async () => {
    if (orphanedPages.length === 0) {
      setError('No orphaned pages to clean up');
      return;
    }

    setCleaning(true);
    setError(null);
    setSuccess(null);

    try {
      const { error: deleteError } = await supabase
        .from('page_seo_metadata')
        .delete()
        .in('page_path', orphanedPages);

      if (deleteError) {
        setError(`Failed to clean up orphaned pages: ${deleteError.message}`);
      } else {
        setSuccess(`Successfully removed ${orphanedPages.length} orphaned SEO entries`);
        setOrphanedPages([]);
        await loadSEOData();
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setCleaning(false);
    }
  };

  const syncDiscoveredPages = async () => {
    setSaving(true);
    setError(null);
    setSuccess(null);

    try {
      const existingPaths = seoData.map(p => p.page_path);
      const newPages = discoveredPages.filter(p => !existingPaths.includes(p.path));

      if (newPages.length === 0) {
        setSuccess('All discovered pages already have SEO metadata!');
        return;
      }

      const productionUrl = branding.seo.siteUrl;

      const records = newPages.map(page => ({
        page_path: page.path,
        page_title: page.title,
        meta_title: page.meta_title || page.title,
        meta_description: page.description,
        meta_keywords: `${page.title}, National Removals, UK removals`,
        canonical_url: `${productionUrl}${page.path}`,
        og_image: null,
        og_type: 'website',
        robots: 'index, follow',
        priority: page.type === 'location' ? 0.7 : page.type === 'article' ? 0.6 : 0.8,
        changefreq: page.type === 'article' ? 'monthly' : page.type === 'location' ? 'weekly' : 'weekly',
      }));

      const { error: insertError } = await supabase
        .from('page_seo_metadata')
        .insert(records);

      if (insertError) throw insertError;

      setSuccess(`Successfully added ${records.length} new pages!`);
      await loadSEOData();
      setShowDiscovery(false);
    } catch (err) {
      console.error('Error syncing pages:', err);
      setError(err instanceof Error ? err.message : 'Failed to sync pages');
    } finally {
      setSaving(false);
    }
  };

  const handleSave = async () => {
    setError(null);
    setSuccess(null);

    if (!formData.page_path.trim()) {
      setError('Page path is required');
      return;
    }

    if (!formData.meta_title.trim()) {
      setError('Meta title is required');
      return;
    }

    if (!formData.meta_description.trim()) {
      setError('Meta description is required');
      return;
    }

    setSaving(true);

    try {
      if (editingPage) {
        const { error: updateError } = await supabase
          .from('page_seo_metadata')
          .update(formData)
          .eq('id', editingPage.id);

        if (updateError) throw updateError;
        setSuccess('SEO metadata updated successfully!');
      } else {
        const { error: insertError } = await supabase
          .from('page_seo_metadata')
          .insert([formData]);

        if (insertError) throw insertError;
        setSuccess('SEO metadata created successfully!');
      }

      await loadSEOData();
      setTimeout(() => resetForm(), 1500);
    } catch (err) {
      console.error('Error saving SEO metadata:', err);
      setError(err instanceof Error ? err.message : 'Failed to save SEO metadata');
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (page: SEOMetadata) => {
    setEditingPage(page);
    setFormData({
      page_path: page.page_path,
      page_title: page.page_title,
      meta_title: page.meta_title,
      meta_description: page.meta_description,
      meta_keywords: page.meta_keywords,
      canonical_url: page.canonical_url,
      og_image: page.og_image,
      og_type: page.og_type,
      robots: page.robots,
      priority: page.priority,
      changefreq: page.changefreq,
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setFormData(emptyMetadata);
    setEditingPage(null);
    setShowForm(false);
    setError(null);
    setSuccess(null);
    setSaving(false);
  };

  const handleImportCSV = async () => {
    if (!importData.trim()) {
      setError('Please paste CSV data');
      return;
    }

    setError(null);
    setSuccess(null);
    setSaving(true);

    try {
      const lines = importData.trim().split('\n');
      const headers = lines[0].split(',').map(h => h.trim().toLowerCase());

      const requiredHeaders = ['page_path', 'meta_title', 'meta_description'];
      const missingHeaders = requiredHeaders.filter(h => !headers.includes(h));

      if (missingHeaders.length > 0) {
        throw new Error(`Missing required columns: ${missingHeaders.join(', ')}`);
      }

      const records = [];
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim().replace(/^"|"$/g, ''));
        const record: any = {};

        headers.forEach((header, index) => {
          record[header] = values[index] || '';
        });

        if (record.page_path && record.meta_title && record.meta_description) {
          records.push({
            page_path: record.page_path,
            page_title: record.page_title || record.meta_title,
            meta_title: record.meta_title,
            meta_description: record.meta_description,
            meta_keywords: record.meta_keywords || '',
            canonical_url: record.canonical_url || null,
            og_image: record.og_image || null,
            og_type: record.og_type || 'website',
            robots: record.robots || 'index, follow',
            priority: parseFloat(record.priority) || 0.8,
            changefreq: record.changefreq || 'weekly',
          });
        }
      }

      if (records.length === 0) {
        throw new Error('No valid records found in CSV');
      }

      for (const record of records) {
        await supabase
          .from('page_seo_metadata')
          .upsert(record, { onConflict: 'page_path' });
      }

      setSuccess(`Successfully imported ${records.length} SEO records!`);
      setImportData('');
      setShowImport(false);
      await loadSEOData();
    } catch (err) {
      console.error('Error importing CSV:', err);
      setError(err instanceof Error ? err.message : 'Failed to import CSV data');
    } finally {
      setSaving(false);
    }
  };

  const exportCSV = () => {
    const headers = ['page_path', 'page_title', 'meta_title', 'meta_description', 'meta_keywords', 'canonical_url', 'robots', 'priority', 'changefreq'];
    let csv = headers.join(',') + '\n';

    seoData.forEach(page => {
      const row = [
        page.page_path,
        page.page_title,
        page.meta_title,
        page.meta_description,
        page.meta_keywords,
        page.canonical_url || '',
        page.robots,
        page.priority,
        page.changefreq,
      ].map(val => `"${val}"`).join(',');
      csv += row + '\n';
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `seo-metadata-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const filteredSEO = seoData.filter(page =>
    page.page_path.toLowerCase().includes(searchTerm.toLowerCase()) ||
    page.meta_title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getSEOHealthScore = (page: SEOMetadata) => {
    let score = 0;
    if (page.meta_title.length >= 50 && page.meta_title.length <= 60) score += 25;
    else if (page.meta_title.length > 0) score += 15;

    if (page.meta_description.length >= 150 && page.meta_description.length <= 160) score += 25;
    else if (page.meta_description.length > 0) score += 15;

    if (page.canonical_url) score += 15;
    if (page.og_image) score += 15;
    if (page.meta_keywords) score += 10;
    if (page.robots === 'index, follow') score += 10;

    return score;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#e71c5e]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:justify-between lg:items-start gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">SEO Management</h2>
          <p className="text-sm text-gray-600 mt-1">Manage meta tags, canonicals, and SEO settings for all pages</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => { discoverPages(); setShowDiscovery(true); }}
            disabled={discovering}
            className="flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50"
          >
            <RefreshCw size={20} className={discovering ? 'animate-spin' : ''} />
            Discover Pages
          </button>
          <button
            onClick={() => setShowImport(true)}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Upload size={20} />
            Import CSV
          </button>
          <button
            onClick={exportCSV}
            className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
          >
            <Download size={20} />
            Export CSV
          </button>
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-2 bg-[#e71c5e] text-white px-4 py-2 rounded-lg hover:bg-[#c91852] transition-colors"
          >
            <Plus size={20} />
            Add Page
          </button>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
        <input
          type="text"
          placeholder="Search pages..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
        />
      </div>

      {showDiscovery && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-[80vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Discovered Pages</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Found {discoveredPages.length} pages • {discoveredPages.filter(p => !seoData.find(s => s.page_path === p.path)).length} need SEO setup
                  </p>
                </div>
                <button onClick={() => setShowDiscovery(false)} className="text-gray-400 hover:text-gray-600">
                  <X size={24} />
                </button>
              </div>
            </div>

            {error && (
              <div className="mx-6 mt-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-red-900">Error</p>
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            )}

            {success && (
              <div className="mx-6 mt-4 p-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-green-900">Success</p>
                  <p className="text-sm text-green-700">{success}</p>
                </div>
              </div>
            )}

            <div className="flex-1 overflow-y-auto p-6">
              <div className="space-y-2">
                {discoveredPages.map((page, index) => {
                  const hasMetadata = seoData.find(s => s.page_path === page.path);
                  return (
                    <div
                      key={index}
                      className={`p-4 rounded-lg border ${
                        hasMetadata
                          ? 'bg-green-50 border-green-200'
                          : 'bg-yellow-50 border-yellow-200'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <code className="text-sm font-mono bg-white px-2 py-1 rounded border">
                              {page.path}
                            </code>
                            <span className="text-xs px-2 py-1 rounded bg-gray-100 text-gray-700">
                              {page.type}
                            </span>
                            {hasMetadata && (
                              <span className="text-xs px-2 py-1 rounded bg-green-100 text-green-700 flex items-center gap-1">
                                <CheckCircle size={12} />
                                Configured
                              </span>
                            )}
                          </div>
                          <p className="text-sm font-medium text-gray-900 mt-2">{page.title}</p>
                          <p className="text-xs text-gray-600 mt-1">{page.description}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-6 border-t border-gray-200 bg-gray-50 space-y-4">
              {orphanedPages.length > 0 && (
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-yellow-900">
                        {orphanedPages.length} Orphaned SEO {orphanedPages.length === 1 ? 'Entry' : 'Entries'} Detected
                      </p>
                      <p className="text-xs text-yellow-700 mt-1">
                        These pages have SEO metadata but no longer exist (deleted articles/locations)
                      </p>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {orphanedPages.slice(0, 5).map((path, i) => (
                          <code key={i} className="text-xs bg-yellow-100 px-2 py-1 rounded">{path}</code>
                        ))}
                        {orphanedPages.length > 5 && (
                          <span className="text-xs text-yellow-700 px-2 py-1">+{orphanedPages.length - 5} more</span>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={cleanupOrphanedPages}
                      disabled={cleaning}
                      className="flex items-center gap-2 bg-yellow-600 text-white px-3 py-2 rounded-lg hover:bg-yellow-700 transition-colors disabled:opacity-50 text-sm"
                    >
                      {cleaning ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                          Cleaning...
                        </>
                      ) : (
                        <>
                          <Trash2 size={16} />
                          Clean Up
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              <div className="flex gap-3">
                <button
                  onClick={syncDiscoveredPages}
                  disabled={saving || discoveredPages.filter(p => !seoData.find(s => s.page_path === p.path)).length === 0}
                  className="flex-1 flex items-center justify-center gap-2 bg-[#e71c5e] text-white px-4 py-3 rounded-lg hover:bg-[#c91852] transition-colors disabled:opacity-50"
                >
                  {saving ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                      Syncing...
                    </>
                  ) : (
                    <>
                      <RefreshCw size={20} />
                      Sync New Pages ({discoveredPages.filter(p => !seoData.find(s => s.page_path === p.path)).length})
                    </>
                  )}
                </button>
                <button
                  onClick={() => setShowDiscovery(false)}
                  disabled={saving}
                  className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-white transition-colors disabled:opacity-50"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showImport && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-3xl w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-gray-900">Import SEO Metadata from CSV</h3>
              <button onClick={() => setShowImport(false)} className="text-gray-400 hover:text-gray-600">
                <X size={24} />
              </button>
            </div>

            {error && (
              <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-red-900">Error</p>
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            )}

            {success && (
              <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-green-900">Success</p>
                  <p className="text-sm text-green-700">{success}</p>
                </div>
              </div>
            )}

            <div className="mb-4">
              <p className="text-sm text-gray-600 mb-2">
                Required columns: <code className="bg-gray-100 px-2 py-1 rounded">page_path</code>, <code className="bg-gray-100 px-2 py-1 rounded">meta_title</code>, <code className="bg-gray-100 px-2 py-1 rounded">meta_description</code>
              </p>
              <p className="text-sm text-gray-600">
                Optional: page_title, meta_keywords, canonical_url, og_image, robots, priority, changefreq
              </p>
            </div>

            <textarea
              value={importData}
              onChange={(e) => setImportData(e.target.value)}
              rows={12}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent font-mono text-sm mb-4"
              placeholder="page_path,meta_title,meta_description&#10;/about,About Us - Company,Learn about our company&#10;/services,Our Services,Professional services..."
            />

            <div className="flex gap-3">
              <button
                onClick={handleImportCSV}
                disabled={saving}
                className="flex-1 flex items-center justify-center gap-2 bg-[#e71c5e] text-white px-4 py-2 rounded-lg hover:bg-[#c91852] transition-colors disabled:opacity-50"
              >
                {saving ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                    Importing...
                  </>
                ) : (
                  <>
                    <Upload size={20} />
                    Import Data
                  </>
                )}
              </button>
              <button
                onClick={() => setShowImport(false)}
                disabled={saving}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6 my-8">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-gray-900">
                {editingPage ? 'Edit SEO Metadata' : 'Add New Page SEO'}
              </h3>
              <button onClick={resetForm} className="text-gray-400 hover:text-gray-600">
                <X size={24} />
              </button>
            </div>

            <div className="space-y-6">
              {error && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-red-900">Error</p>
                    <p className="text-sm text-red-700">{error}</p>
                  </div>
                </div>
              )}

              {success && (
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-green-900">Success</p>
                    <p className="text-sm text-green-700">{success}</p>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">
                  Page Path * (e.g., /about, /services)
                </label>
                <input
                  type="text"
                  value={formData.page_path}
                  onChange={(e) => setFormData({ ...formData, page_path: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                  placeholder="/page-path"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">
                  Page Title *
                </label>
                <input
                  type="text"
                  value={formData.page_title}
                  onChange={(e) => setFormData({ ...formData, page_title: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                  placeholder="Page Title"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">
                  Meta Title * ({formData.meta_title.length}/60 characters)
                </label>
                <input
                  type="text"
                  value={formData.meta_title}
                  onChange={(e) => setFormData({ ...formData, meta_title: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                  placeholder="SEO title (50-60 characters optimal)"
                  maxLength={60}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">
                  Meta Description * ({formData.meta_description.length}/160 characters)
                </label>
                <textarea
                  value={formData.meta_description}
                  onChange={(e) => setFormData({ ...formData, meta_description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                  placeholder="SEO description (150-160 characters optimal)"
                  maxLength={160}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">
                  Meta Keywords (comma-separated)
                </label>
                <input
                  type="text"
                  value={formData.meta_keywords}
                  onChange={(e) => setFormData({ ...formData, meta_keywords: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                  placeholder="keyword1, keyword2, keyword3"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-2">
                    Canonical URL
                  </label>
                  <input
                    type="url"
                    value={formData.canonical_url || ''}
                    onChange={(e) => setFormData({ ...formData, canonical_url: e.target.value || null })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                    placeholder="https://example.com/page"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-2">
                    OG Image URL
                  </label>
                  <input
                    type="url"
                    value={formData.og_image || ''}
                    onChange={(e) => setFormData({ ...formData, og_image: e.target.value || null })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                    placeholder="https://example.com/image.jpg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-2">
                    Robots
                  </label>
                  <select
                    value={formData.robots}
                    onChange={(e) => setFormData({ ...formData, robots: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                  >
                    <option value="index, follow">Index, Follow</option>
                    <option value="noindex, follow">NoIndex, Follow</option>
                    <option value="index, nofollow">Index, NoFollow</option>
                    <option value="noindex, nofollow">NoIndex, NoFollow</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-2">
                    Priority (0.0-1.0)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    max="1"
                    value={formData.priority}
                    onChange={(e) => setFormData({ ...formData, priority: parseFloat(e.target.value) })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-2">
                    Change Frequency
                  </label>
                  <select
                    value={formData.changefreq}
                    onChange={(e) => setFormData({ ...formData, changefreq: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
                  >
                    <option value="always">Always</option>
                    <option value="hourly">Hourly</option>
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="yearly">Yearly</option>
                    <option value="never">Never</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t">
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="flex-1 flex items-center justify-center gap-2 bg-[#e71c5e] text-white px-4 py-2 rounded-lg hover:bg-[#c91852] transition-colors disabled:opacity-50"
                >
                  {saving ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save size={20} />
                      {editingPage ? 'Update Metadata' : 'Add Metadata'}
                    </>
                  )}
                </button>
                <button
                  onClick={resetForm}
                  disabled={saving}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Page
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Meta Title
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  SEO Health
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredSEO.map((page) => {
                const healthScore = getSEOHealthScore(page);
                return (
                  <tr key={page.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <code className="text-sm font-mono bg-gray-100 px-2 py-1 rounded">{page.page_path}</code>
                        <a href={page.page_path} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[#e71c5e]">
                          <ExternalLink size={14} />
                        </a>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">{page.page_title}</p>
                    </td>
                    <td className="px-6 py-4">
                      <div className="max-w-md">
                        <p className="text-sm font-medium text-gray-900 truncate">{page.meta_title}</p>
                        <p className="text-xs text-gray-500 truncate mt-1">{page.meta_description}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full transition-all ${
                              healthScore >= 80 ? 'bg-green-500' : healthScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                            }`}
                            style={{ width: `${healthScore}%` }}
                          />
                        </div>
                        <span className="text-sm font-medium text-gray-700 w-12">{healthScore}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <button
                        onClick={() => handleEdit(page)}
                        className="text-[#e71c5e] hover:text-[#c91852]"
                      >
                        <Edit size={18} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {filteredSEO.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          No SEO metadata found. Add pages to get started.
        </div>
      )}
    </div>
  );
}
