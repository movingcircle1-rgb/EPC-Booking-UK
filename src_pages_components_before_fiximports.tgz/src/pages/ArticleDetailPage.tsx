import { useEffect, useState } from 'react';
import {
  Calendar,
  Eye,
  Tag,
  ArrowLeft,
  Share2,
  Facebook,
  Twitter,
  Linkedin,
  Mail,
  Copy,
  MessageCircle,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import SEO from '../components/SEO';
import AutoLinkedContent from '../components/AutoLinkedContent';

interface Article {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  featured_image: string | null;
  category: string;
  tags: string[];
  meta_title: string | null;
  meta_description: string | null;
  published_at: string;
  view_count: number;
}

export default function ArticleDetailPage({ slug }: { slug: string }) {
  const [article, setArticle] = useState<Article | null>(null);
  const [relatedArticles, setRelatedArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [showShareMenu, setShowShareMenu] = useState(false);

  useEffect(() => {
    if (slug) {
      loadArticle();
    } else {
      setLoading(false);
      setArticle(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slug]);

  const loadArticle = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from('articles')
      .select('*')
      .eq('slug', slug)
      .eq('status', 'published')
      .maybeSingle();

    if (error) {
      console.error('Error loading article:', error);
      setLoading(false);
      return;
    }

    if (!data) {
      setArticle(null);
      setLoading(false);
      return;
    }

    setArticle(data);

    // increment views (best-effort)
    try {
      await supabase
        .from('articles')
        .update({ view_count: (data.view_count || 0) + 1 })
        .eq('id', data.id);
    } catch {
      // ignore
    }

    const { data: related } = await supabase
      .from('articles')
      .select('id, title, slug, excerpt, featured_image, category, published_at, view_count, tags, content, meta_title, meta_description')
      .eq('status', 'published')
      .eq('category', data.category)
      .neq('id', data.id)
      .limit(3);

    if (related) {
      // related query returns a subset; we only use what we render
      setRelatedArticles(
        related.map((r: any) => ({
          id: r.id,
          title: r.title,
          slug: r.slug,
          excerpt: r.excerpt,
          featured_image: r.featured_image ?? null,
          category: r.category,
          published_at: r.published_at,
          view_count: r.view_count ?? 0,
          tags: r.tags ?? [],
          content: r.content ?? '',
          meta_title: r.meta_title ?? null,
          meta_description: r.meta_description ?? null,
        }))
      );
    }

    setLoading(false);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  };

  const shareArticle = () => {
    if (typeof window === 'undefined') return;

    if ((navigator as any).share) {
      (navigator as any).share({
        title: article?.title,
        text: article?.excerpt,
        url: window.location.href,
      });
    } else {
      setShowShareMenu((s) => !s);
    }
  };

  const shareToSocial = (platform: string) => {
    if (typeof window === 'undefined') return;

    const url = encodeURIComponent(window.location.href);
    const title = encodeURIComponent(article?.title || '');
    const text = encodeURIComponent(article?.excerpt || '');

    let shareUrl = '';

    switch (platform) {
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?url=${url}&text=${title}`;
        break;
      case 'linkedin':
        shareUrl = `https://www.linkedin.com/shareArticle?mini=true&url=${url}&title=${title}&summary=${text}`;
        break;
      case 'whatsapp':
        shareUrl = `https://wa.me/?text=${title}%20${url}`;
        break;
      case 'email':
        shareUrl = `mailto:?subject=${title}&body=${text}%0A%0A${url}`;
        break;
      case 'copy':
        navigator.clipboard.writeText(window.location.href);
        alert('Link copied to clipboard!');
        setShowShareMenu(false);
        return;
      default:
        break;
    }

    if (shareUrl) {
      window.open(shareUrl, '_blank', 'noopener,noreferrer');
      setShowShareMenu(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#e71c5e]"></div>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white rounded-xl shadow-sm p-8 text-center max-w-lg">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Article not found
          </h1>
          <p className="text-gray-600 mb-6">
            The article you’re looking for may have been moved or unpublished.
          </p>
          <a
            href="/articles/"
            className="inline-flex items-center justify-center bg-[#e71c5e] hover:bg-[#c91852] text-white px-6 py-3 rounded-lg font-semibold"
          >
            Back to Articles
          </a>
        </div>
      </div>
    );
  }

  // Canonical path should be trailing slash consistent to avoid 301s
  const canonicalPath = `/articles/${article.slug}/`;

  return (
    <div className="min-h-screen bg-gray-50">
      <SEO
        title={article.meta_title || article.title}
        description={article.meta_description || article.excerpt}
        keywords={article.tags?.length ? article.tags.join(', ') : undefined}
        canonicalUrl={canonicalPath}
        ogImage={article.featured_image || undefined}
        ogType="article"
      />

      {article.featured_image && (
        <div className="relative h-96 overflow-hidden">
          <img
            src={article.featured_image}
            alt={article.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <div className="absolute bottom-0 left-0 right-0 p-8">
            <div className="container mx-auto max-w-4xl">
              <span className="inline-block px-3 py-1 bg-[#e71c5e] text-white text-sm font-medium rounded-full mb-4">
                {article.category}
              </span>
              <h1 className="text-4xl md:text-5xl font-bold text-white">
                {article.title}
              </h1>
            </div>
          </div>
        </div>
      )}

      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <a
          href="/articles/"
          className="inline-flex items-center gap-2 text-[#e71c5e] hover:text-[#c91852] mb-6 font-medium"
        >
          <ArrowLeft size={20} />
          Back to Articles
        </a>

        {!article.featured_image && (
          <div className="mb-8">
            <span className="inline-block px-3 py-1 bg-[#e71c5e] text-white text-sm font-medium rounded-full mb-4">
              {article.category}
            </span>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              {article.title}
            </h1>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-6 text-gray-600 mb-8 pb-8 border-b">
          <span className="flex items-center gap-2">
            <Calendar size={18} />
            {formatDate(article.published_at)}
          </span>

          <span className="flex items-center gap-2">
            <Eye size={18} />
            {article.view_count} views
          </span>

          <div className="ml-auto relative">
            <button
              onClick={shareArticle}
              className="flex items-center gap-2 text-[#e71c5e] hover:text-[#c91852] font-medium"
              aria-label="Share article"
            >
              <Share2 size={18} />
              Share
            </button>

            {showShareMenu && (
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-xl border border-gray-200 z-50">
                <div className="p-4">
                  <p className="text-sm font-semibold text-gray-700 mb-3">
                    Share this article
                  </p>
                  <div className="space-y-2">
                    <button
                      onClick={() => shareToSocial('facebook')}
                      className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-blue-50 transition-colors text-left"
                    >
                      <Facebook size={20} className="text-blue-600" />
                      <span className="text-sm font-medium text-gray-700">
                        Facebook
                      </span>
                    </button>

                    <button
                      onClick={() => shareToSocial('twitter')}
                      className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-sky-50 transition-colors text-left"
                    >
                      <Twitter size={20} className="text-sky-500" />
                      <span className="text-sm font-medium text-gray-700">
                        Twitter
                      </span>
                    </button>

                    <button
                      onClick={() => shareToSocial('linkedin')}
                      className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-blue-50 transition-colors text-left"
                    >
                      <Linkedin size={20} className="text-blue-700" />
                      <span className="text-sm font-medium text-gray-700">
                        LinkedIn
                      </span>
                    </button>

                    <button
                      onClick={() => shareToSocial('whatsapp')}
                      className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-green-50 transition-colors text-left"
                    >
                      <MessageCircle size={20} className="text-green-600" />
                      <span className="text-sm font-medium text-gray-700">
                        WhatsApp
                      </span>
                    </button>

                    <button
                      onClick={() => shareToSocial('email')}
                      className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors text-left"
                    >
                      <Mail size={20} className="text-gray-600" />
                      <span className="text-sm font-medium text-gray-700">
                        Email
                      </span>
                    </button>

                    <button
                      onClick={() => shareToSocial('copy')}
                      className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors text-left"
                    >
                      <Copy size={20} className="text-gray-600" />
                      <span className="text-sm font-medium text-gray-700">
                        Copy Link
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {article.tags && article.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-8">
            {article.tags.map((tag, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm"
              >
                <Tag size={14} />
                {tag}
              </span>
            ))}
          </div>
        )}

        <div className="bg-white rounded-xl shadow-sm p-8 md:p-12">
          <AutoLinkedContent
            content={article.content}
            className="article-content prose prose-lg max-w-none"
            enableLinking={true}
          />
        </div>

        {relatedArticles.length > 0 && (
          <div className="mt-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              Related Articles
            </h2>
            <div className="grid md:grid-cols-3 gap-6">
              {relatedArticles.map((related) => (
                <a
                  key={related.id}
                  href={`/articles/${related.slug}/`}
                  className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-shadow overflow-hidden group"
                >
                  {related.featured_image && (
                    <div className="relative h-40 overflow-hidden">
                      <img
                        src={related.featured_image}
                        alt={related.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}
                  <div className="p-4">
                    <span className="text-xs text-[#e71c5e] font-medium">
                      {related.category}
                    </span>
                    <h3 className="text-lg font-bold text-gray-900 mt-2 mb-2 group-hover:text-[#e71c5e] transition-colors line-clamp-2">
                      {related.title}
                    </h3>
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {related.excerpt}
                    </p>
                  </div>
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
