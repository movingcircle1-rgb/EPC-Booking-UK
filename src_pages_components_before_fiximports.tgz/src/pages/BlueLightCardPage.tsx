import { Check, Shield, Users } from 'lucide-react';
import SEO from '../components/SEO';
import AutoLinkedContent from '../components/AutoLinkedContent';
import { useSEO } from '../hooks/useSEO';

export default function BlueLightCardPage() {
  // IMPORTANT: keep this WITHOUT trailing slash to match useSEO normalisation + DB page_path
  const { seoData } = useSEO('/blue-light-card');

  const fallbackTitle = 'Blue Light Card Discount - 10% Off | National Removals';
  const fallbackDescription =
    'Exclusive 10% discount for Blue Light Card holders. NHS staff, emergency services, and armed forces qualify. Special thank you for your service.';
  const fallbackKeywords =
    'blue light card discount, NHS discount, emergency services discount, police discount, fire service discount, ambulance discount';
  const fallbackCanonical =
    'https://nationalremovalsandstorage.co.uk/blue-light-card/';

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      <div className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/Blue Light Card.webp"
            alt="Blue Light Card Support"
            className="w-full h-full object-cover opacity-30"
            loading="eager"
          />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <AutoLinkedContent
              as="h1"
              content="Blue Light Card Discount"
              className="text-5xl font-bold mb-6"
              enableLinking={true}
            />
            <AutoLinkedContent
              content="Special discounts for our emergency services heroes and NHS workers"
              className="text-xl text-blue-100"
              enableLinking={true}
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="bg-blue-50 border-l-4 border-blue-600 p-6 rounded-lg mb-12">
            <h2 className="text-2xl font-bold text-blue-900 mb-2">
              10% OFF All Services
            </h2>
            <p className="text-blue-800">
              As a thank you for your service, we offer exclusive discounts to
              Blue Light Card holders.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <Shield className="text-blue-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Emergency Services
              </h3>
              <p className="text-gray-600">
                Police, Fire, Ambulance, and all emergency service personnel
                qualify for our special discount.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <Users className="text-blue-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">NHS Staff</h3>
              <p className="text-gray-600">
                All NHS workers including doctors, nurses, and support staff are
                eligible for this discount.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <Check className="text-blue-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Easy Verification
              </h3>
              <p className="text-gray-600">
                Simply show your valid Blue Light Card when booking or on moving
                day to claim your discount.
              </p>
            </div>
          </div>

          <div className="bg-gray-50 rounded-xl p-8 mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              How to Claim Your Discount
            </h2>

            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                  1
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 mb-1">Get a Quote</h3>
                  <p className="text-gray-600">
                    Contact us for a free, no-obligation quote for your move.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                  2
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 mb-1">Show Your Card</h3>
                  <p className="text-gray-600">
                    Present your valid Blue Light Card when booking your move.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                  3
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 mb-1">Save 10%</h3>
                  <p className="text-gray-600">
                    Your discount will be automatically applied to your final
                    invoice.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center">
            <p className="text-sm text-gray-500 mb-6">
              * Discount cannot be combined with other offers. Valid Blue Light
              Card must be presented at time of booking.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
