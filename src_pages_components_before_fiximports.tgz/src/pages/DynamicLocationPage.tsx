// src/pages/DynamicLocationPage.tsx
import { useParams } from 'react-router-dom';
import LocationPage from './LocationPage';

export default function DynamicLocationPage() {
  const params = useParams();

  const location =
    (params.location as string) ||
    (params.city as string) ||
    (params.slug as string) ||
    '';

  const service = (params.service as string) || undefined;

  return <LocationPage location={location} service={service} />;
}
