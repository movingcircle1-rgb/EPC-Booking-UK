import { Globe, Truck, FileText, Shield, MapPin, CheckCircle } from 'lucide-react';
import SEO from '../components/SEO';
import AutoLinkedContent from '../components/AutoLinkedContent';
import { useSEO } from '../hooks/useSEO';

export default function EuropeanMovesPage() {
  // IMPORTANT: NO trailing slash – must match Supabase page_path + useSEO normalisation
  const { seoData } = useSEO('/european-moves');

  const fallbackTitle = 'European Moves | National Removals and Storage';
  const fallbackDescription =
    'Professional European relocation services from the UK. Door-to-door moving to EU countries with customs assistance, international insurance, and multi-language support.';
  const fallbackKeywords =
    'European moves, EU relocation, moving to Europe, international removals Europe, UK to Europe moving';
  const fallbackCanonical =
    'https://nationalremovalsandstorage.co.uk/european-moves/';

  const countries = [
    'France',
    'Germany',
    'Spain',
    'Italy',
    'Netherlands',
    'Belgium',
    'Portugal',
    'Austria',
    'Sweden',
    'Denmark',
    'Poland',
    'Czech Republic',
    'Ireland',
    'Greece',
    'Switzerland',
  ];

  const services = [
    {
      icon: Truck,
      title: 'Door-to-Door Service',
      description:
        'Complete service from your UK home to your new European address',
    },
    {
      icon: FileText,
      title: 'Customs Assistance',
      description: 'Expert help with all customs documentation and procedures',
    },
    {
      icon: Shield,
      title: 'International Insurance',
      description: 'Comprehensive coverage for your European relocation',
    },
    {
      icon: Globe,
      title: 'Multi-Language Support',
      description: 'Multilingual team to assist throughout your move',
    },
  ];

  return (
    <div>
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <AutoLinkedContent
                as="h1"
                content="European Moves"
                className="text-5xl font-bold mb-6"
                enableLinking={true}
              />
              <AutoLinkedContent
                content="Seamless relocations from the UK to anywhere in Europe with comprehensive support and expert handling"
                className="text-xl text-gray-300 mb-8"
                enableLinking={true}
              />
              <a
                href="/contact/"
                className="inline-block bg-[#e71c5e] hover:bg-[#c91852] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg"
              >
                Get Your Free Quote
              </a>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="/European Removals.webp"
                alt="European moves service"
                className="w-full h-96 object-cover"
                loading="eager"
              />
            </div>
          </div>
        </div>
      </div>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose Us for European Moves
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We have extensive experience in European relocations and
              partnerships across the continent
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-xl p-6 text-center hover:shadow-lg transition-shadow"
              >
                <div className="w-16 h-16 bg-[#e71c5e] rounded-full flex items-center justify-center mx-auto mb-4">
                  <service.icon size={32} className="text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">
              Countries We Serve
            </h2>

            <div className="bg-white rounded-2xl p-10 shadow-lg mb-8">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
                {countries.map((country, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <MapPin
                      size={16}
                      className="text-[#e71c5e] flex-shrink-0"
                    />
                    <span className="text-gray-700">{country}</span>
                  </div>
                ))}
              </div>
            </div>

            <p className="text-center text-gray-600">
              Don&apos;t see your destination? We cover all European countries.
              Contact us to discuss your specific needs.
            </p>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">
              Our European Moving Process
            </h2>

            <div className="space-y-6">
              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-[#e71c5e] rounded-full flex items-center justify-center text-white font-bold text-xl">
                  1
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold mb-2">
                    Consultation &amp; Quote
                  </h3>
                  <p className="text-gray-700">
                    We assess your requirements and provide a detailed quote
                    including all costs and timelines for your European move.
                  </p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-[#e71c5e] rounded-full flex items-center justify-center text-white font-bold text-xl">
                  2
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold mb-2">
                    Documentation Support
                  </h3>
                  <p className="text-gray-700">
                    Our team assists with all necessary customs documentation,
                    ensuring compliance with both UK and destination country
                    requirements.
                  </p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-[#e71c5e] rounded-full flex items-center justify-center text-white font-bold text-xl">
                  3
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold mb-2">
                    Packing &amp; Collection
                  </h3>
                  <p className="text-gray-700">
                    Professional packing of your belongings using materials
                    suitable for long-distance European transport.
                  </p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-[#e71c5e] rounded-full flex items-center justify-center text-white font-bold text-xl">
                  4
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold mb-2">
                    Secure Transportation
                  </h3>
                  <p className="text-gray-700">
                    Your belongings are transported via our European partner
                    network with full tracking throughout the journey.
                  </p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-[#e71c5e] rounded-full flex items-center justify-center text-white font-bold text-xl">
                  5
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold mb-2">Customs Clearance</h3>
                  <p className="text-gray-700">
                    We handle all customs procedures at borders, ensuring smooth
                    passage through all checkpoints.
                  </p>
                </div>
              </div>

              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-[#e71c5e] rounded-full flex items-center justify-center text-white font-bold text-xl">
                  6
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold mb-2">
                    Delivery &amp; Unpacking
                  </h3>
                  <p className="text-gray-700">
                    Final delivery to your new European home with unpacking
                    services available if required.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">
              What&apos;s Included
            </h2>

            <div className="bg-white rounded-2xl p-10 shadow-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[
                  'Pre-move consultation and survey',
                  'Detailed moving plan and timeline',
                  'Full packing service available',
                  'All customs documentation assistance',
                  'Door-to-door transportation',
                  'GPS tracking throughout journey',
                  'Comprehensive international insurance',
                  'Multi-language customer support',
                  'Unpacking and placement service',
                  'Post-move support in destination country',
                  'Temporary storage if needed',
                  'Dedicated move coordinator',
                ].map((item, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle
                      size={24}
                      className="text-[#e71c5e] flex-shrink-0 mt-0.5"
                    />
                    <span className="text-gray-700">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="bg-gradient-to-br from-[#e71c5e]/10 to-[#c91852]/10 rounded-2xl p-10 border-2 border-[#e71c5e]/20">
              <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">
                Important Information
              </h2>

              <div className="space-y-4">
                <div>
                  <h3 className="font-bold text-lg mb-2 text-[#e71c5e]">
                    Brexit Considerations
                  </h3>
                  <p className="text-gray-700">
                    We&apos;re fully up-to-date with all post-Brexit regulations
                    and can guide you through any additional documentation
                    requirements for moving to EU countries.
                  </p>
                </div>

                <div>
                  <h3 className="font-bold text-lg mb-2 text-[#e71c5e]">
                    Transit Times
                  </h3>
                  <p className="text-gray-700">
                    Typical transit times range from 3-10 days depending on your
                    destination. We provide accurate timelines during the
                    quotation process.
                  </p>
                </div>

                <div>
                  <h3 className="font-bold text-lg mb-2 text-[#e71c5e]">
                    Insurance Coverage
                  </h3>
                  <p className="text-gray-700">
                    All European moves include comprehensive insurance covering
                    your belongings throughout the entire journey, including
                    customs clearance.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-br from-[#e71c5e] to-[#c91852] text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Move to Europe?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Get your free, comprehensive quote for your European relocation
            today
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/contact/"
              className="inline-block bg-white text-[#e71c5e] px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transition-all transform hover:scale-105 shadow-xl"
            >
              Request Free Quote
            </a>
            <a
              href="tel:08000472607"
              className="inline-block bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-white hover:text-[#e71c5e] transition-all"
            >
              Call 0800 047 2607
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
