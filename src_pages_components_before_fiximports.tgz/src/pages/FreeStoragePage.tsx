import { Package, Clock, Shield, CheckCircle } from 'lucide-react';
import SEO from '../components/SEO';
import AutoLinkedContent from '../components/AutoLinkedContent';
import { useSEO } from '../hooks/useSEO';

export default function FreeStoragePage() {
  // IMPORTANT: NO trailing slash – must match Supabase page_path + useSEO normalisation
  const { seoData } = useSEO('/free-storage');

  const fallbackTitle =
    'Free Storage Solutions - Up to 2 Weeks Free | National Removals';
  const fallbackDescription =
    "Get up to 2 weeks free storage with your removal service. Secure, climate-controlled facilities with 24/7 security. Perfect for delayed completion dates.";
  const fallbackKeywords =
    'free storage, complimentary storage, moving storage, temporary storage, removal storage included';
  const fallbackCanonical =
    'https://nationalremovalsandstorage.co.uk/free-storage/';

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      <div className="relative bg-gradient-to-r from-amber-600 to-amber-800 text-white py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/Free Storage.webp"
            alt="Free Storage Facilities"
            className="w-full h-full object-cover opacity-30"
            loading="eager"
          />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <AutoLinkedContent
              as="h1"
              content="Free Storage Solutions"
              className="text-5xl font-bold mb-6"
              enableLinking={true}
            />
            <AutoLinkedContent
              content="Complimentary storage when you need it most"
              className="text-xl text-amber-100"
              enableLinking={true}
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="bg-amber-50 border-l-4 border-amber-600 p-6 rounded-lg mb-12">
            <h2 className="text-2xl font-bold text-amber-900 mb-2">
              Up to 2 Weeks Free Storage
            </h2>
            <p className="text-amber-800">
              We understand that moving dates don&apos;t always align perfectly.
              That&apos;s why we offer free storage solutions for all our
              customers.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mb-4">
                <Package className="text-amber-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Secure Facilities
              </h3>
              <p className="text-gray-600">
                Your belongings are stored in our modern, climate-controlled
                warehouses with 24/7 security monitoring.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mb-4">
                <Clock className="text-amber-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Flexible Duration
              </h3>
              <p className="text-gray-600">
                Enjoy up to 2 weeks of complimentary storage, with affordable
                rates if you need longer-term solutions.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mb-4">
                <Shield className="text-amber-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Fully Insured
              </h3>
              <p className="text-gray-600">
                Comprehensive insurance coverage included for peace of mind
                while your items are in storage.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="text-amber-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Easy Access
              </h3>
              <p className="text-gray-600">
                Need something during storage? Contact us and we&apos;ll arrange
                access to your stored items.
              </p>
            </div>
          </div>

          <div className="bg-gray-50 rounded-xl p-8 mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Who Qualifies?
            </h2>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <CheckCircle
                  className="text-amber-600 flex-shrink-0 mt-1"
                  size={20}
                />
                <p className="text-gray-700">
                  All customers booking a full removal service qualify for free
                  storage
                </p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle
                  className="text-amber-600 flex-shrink-0 mt-1"
                  size={20}
                />
                <p className="text-gray-700">
                  Perfect for delayed completion dates or property chain issues
                </p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle
                  className="text-amber-600 flex-shrink-0 mt-1"
                  size={20}
                />
                <p className="text-gray-700">
                  Ideal when renovating your new property before moving in
                </p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle
                  className="text-amber-600 flex-shrink-0 mt-1"
                  size={20}
                />
                <p className="text-gray-700">
                  Great for overseas moves with flexible arrival dates
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-amber-50 to-amber-100 rounded-xl p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Extended Storage Options
            </h2>
            <p className="text-gray-700 mb-6">
              Need storage for longer than 2 weeks? We offer competitive rates
              for extended storage periods:
            </p>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <p className="text-3xl font-bold text-amber-600 mb-1">£15</p>
                <p className="text-sm text-gray-600">per week thereafter</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <p className="text-3xl font-bold text-amber-600 mb-1">£50</p>
                <p className="text-sm text-gray-600">per month (save 20%)</p>
              </div>
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <p className="text-3xl font-bold text-amber-600 mb-1">£500</p>
                <p className="text-sm text-gray-600">per year (save 30%)</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
