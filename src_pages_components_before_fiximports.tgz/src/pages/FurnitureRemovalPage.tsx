import { Heart, Truck, Users, Home } from 'lucide-react';
import SEO from '../components/SEO';
import AutoLinkedContent from '../components/AutoLinkedContent';
import { useSEO } from '../hooks/useSEO';

export default function FurnitureRemovalPage() {
  // Must match Supabase page_path (hook normalises trailing slash anyway)
  const { seoData } = useSEO('/furniture-removal');

  const fallbackTitle =
    'Charitable Furniture Removal - Free Collection Service | National Removals and Storage';

  const fallbackDescription =
    'Free furniture collection and donation service. We collect unwanted furniture during your move and donate it to local charities. Eco-friendly and helps those in need.';

  const fallbackKeywords =
    'furniture removal, furniture donation, charity furniture collection, free furniture collection, donate furniture';

  const fallbackCanonical =
    'https://nationalremovalsandstorage.co.uk/furniture-removal/';

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      <div className="relative bg-gradient-to-r from-rose-600 to-rose-800 text-white py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/Furniture Donation and Collection.webp"
            alt="Furniture Donation and Collection"
            className="w-full h-full object-cover opacity-30"
            loading="eager"
          />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <AutoLinkedContent
              as="h1"
              content="Charitable Furniture Removal"
              className="text-5xl font-bold mb-6"
              enableLinking={true}
            />
            <AutoLinkedContent
              content="Give your unwanted furniture a second life while helping those in need"
              className="text-xl text-rose-100"
              enableLinking={true}
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="bg-rose-50 border-l-4 border-rose-600 p-6 rounded-lg mb-12">
            <AutoLinkedContent
              as="h2"
              content="Free Furniture Collection Service"
              className="text-2xl font-bold text-rose-900 mb-2"
              enableLinking={true}
            />
            <p className="text-rose-800">
              Moving to a new home and have furniture you no longer need? We&apos;ll
              collect it for free and donate it to local charities.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-rose-100 rounded-full flex items-center justify-center mb-4">
                <Heart className="text-rose-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Help Those in Need
              </h3>
              <p className="text-gray-600">
                Your unwanted furniture goes directly to families and individuals
                who need it most.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-rose-100 rounded-full flex items-center justify-center mb-4">
                <Truck className="text-rose-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Free Collection
              </h3>
              <p className="text-gray-600">
                We&apos;ll collect your furniture at no cost when we handle your move.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-rose-100 rounded-full flex items-center justify-center mb-4">
                <Users className="text-rose-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Local Charities
              </h3>
              <p className="text-gray-600">
                We partner with trusted local charities and community
                organizations.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-rose-100 rounded-full flex items-center justify-center mb-4">
                <Home className="text-rose-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                Eco-Friendly
              </h3>
              <p className="text-gray-600">
                Keep furniture out of landfills by giving it a new home instead.
              </p>
            </div>
          </div>

          <div className="bg-gray-50 rounded-xl p-8 mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              What We Accept
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <span className="text-green-600 text-2xl">✓</span>
                  Items We Can Donate
                </h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• Sofas and armchairs in good condition</li>
                  <li>• Dining tables and chairs</li>
                  <li>• Beds and mattresses (clean, stain-free)</li>
                  <li>• Wardrobes and storage units</li>
                  <li>• Desks and office furniture</li>
                  <li>• Working appliances</li>
                  <li>• Books and home accessories</li>
                </ul>
              </div>
              <div>
                <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <span className="text-red-600 text-2xl">✗</span>
                  Items We Cannot Accept
                </h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• Damaged or broken furniture</li>
                  <li>• Stained or soiled upholstery</li>
                  <li>• Mattresses with stains or tears</li>
                  <li>• Mouldy or water-damaged items</li>
                  <li>• Items not meeting safety standards</li>
                  <li>• Broken appliances</li>
                  <li>• Hazardous materials</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-rose-50 to-rose-100 rounded-xl p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Our Impact
            </h2>
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div>
                <p className="text-4xl font-bold text-rose-600 mb-2">5,000+</p>
                <p className="text-gray-700">Items Donated</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-rose-600 mb-2">1,200+</p>
                <p className="text-gray-700">Families Helped</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-rose-600 mb-2">50 Tons</p>
                <p className="text-gray-700">Kept from Landfill</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
