import { useEffect, useState } from 'react';
import {
  Home,
  Building2,
  Warehouse,
  Package,
  Star,
  CheckCircle,
  TrendingUp,
} from 'lucide-react';
import Hero from '../components/Hero';
import ServiceCard from '../components/ServiceCard';
import SEO from '../components/SEO';
import TrustedLogos from '../components/TrustedLogos';
import { supabase } from '../lib/supabase';
import { brandConfig } from '../config/branding';
import { useSEO } from '../hooks/useSEO';

interface HomePageProps {
  onNavigate: (page: string) => void;
  onGetQuote: () => void;
}

interface Testimonial {
  id: string;
  name: string;
  rating: number;
  comment: string;
  location: string;
  image_url?: string;
}

export default function HomePage({ onNavigate, onGetQuote }: HomePageProps) {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const { seoData, loading: seoLoading } = useSEO('/');

  // -----------------------------
  // Load testimonials from Supabase
  // -----------------------------
  const loadTestimonials = async () => {
    const { data, error } = await supabase
      .from('testimonials')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(3);

    if (!error && data) {
      setTestimonials(data);
    }
  };

  // -----------------------------
  // Tell Prerender NOT ready yet
  // -----------------------------
  useEffect(() => {
    // @ts-ignore
    window.prerenderReady = false;
    loadTestimonials();
  }, []);

  // -----------------------------
  // Allow snapshot once data loaded
  // -----------------------------
  useEffect(() => {
    if (!seoLoading && testimonials.length > 0) {
      // @ts-ignore
      window.prerenderReady = true;
    }
  }, [seoLoading, testimonials]);

  // -----------------------------
  // Failsafe: never wait forever
  // -----------------------------
  useEffect(() => {
    const t = setTimeout(() => {
      // @ts-ignore
      window.prerenderReady = true;
    }, 10000);

    return () => clearTimeout(t);
  }, []);

  const services = [
    {
      icon: Home,
      title: 'House Removals',
      description: 'Professional house moving services',
      features: [
        'Full packing service',
        'Secure transportation',
        'Insurance included',
        'Furniture assembly',
      ],
      imageUrl:
        'https://images.pexels.com/photos/7018391/pexels-photo-7018391.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '/house-removals/',
    },
    {
      icon: Building2,
      title: 'Office Removals',
      description: 'Expert commercial moving solutions',
      features: [
        'Minimal downtime',
        'IT equipment handling',
        'Weekend moves available',
        'Secure document handling',
      ],
      imageUrl:
        'https://images.pexels.com/photos/7414012/pexels-photo-7414012.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '/office-removals/',
    },
    {
      icon: Warehouse,
      title: 'Storage Solutions',
      description: 'Safe and secure storage facilities',
      features: [
        '24/7 security',
        'Climate controlled',
        'Flexible terms',
        'Easy access',
      ],
      imageUrl:
        'https://images.pexels.com/photos/4246120/pexels-photo-4246120.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '/storage/',
    },
    {
      icon: Package,
      title: 'Packing Services',
      description: 'Professional packing and materials',
      features: [
        'Quality materials',
        'Expert packing',
        'Fragile item care',
        'Unpacking service',
      ],
      imageUrl:
        'https://images.pexels.com/photos/4246216/pexels-photo-4246216.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '/packing-services/',
    },
  ];

  return (
    <div>
      <SEO
        title={
          seoData?.meta_title ||
          'National Removals and Storage | Professional Moving Services UK'
        }
        description={
          seoData?.meta_description ||
          'Professional house removals, office removals, packing services, and secure storage across the UK. Based in Willenhall (WV13) and serving nationwide moves. Call 0800 047 2607 for a free quote.'
        }
        keywords={
          seoData?.meta_keywords ||
          'house removals, office removals, packing services, storage, removals UK, moving company, Willenhall removals, nationwide removals, professional movers'
        }
      />

      <Hero onGetQuote={onGetQuote} />

      {/* WHY US */}
      <section className="py-20 bg-gradient-to-br from-white to-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6">
              Why {brandConfig.companyName}?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Over a decade of excellence in removal and storage services. We
              don’t just move belongings — we move lives.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-10 bg-white rounded-2xl shadow-lg">
              <CheckCircle size={36} className="mx-auto mb-6 text-[#e71c5e]" />
              <h3 className="text-2xl font-bold mb-4">Fully Insured</h3>
              <p className="text-gray-600">
                Comprehensive insurance coverage for complete peace of mind.
              </p>
            </div>

            <div className="text-center p-10 bg-white rounded-2xl shadow-lg">
              <Star size={36} className="mx-auto mb-6 text-[#e71c5e]" />
              <h3 className="text-2xl font-bold mb-4">Expert Team</h3>
              <p className="text-gray-600">
                Highly trained professionals with years of experience.
              </p>
            </div>

            <div className="text-center p-10 bg-white rounded-2xl shadow-lg">
              <TrendingUp size={36} className="mx-auto mb-6 text-[#e71c5e]" />
              <h3 className="text-2xl font-bold mb-4">Competitive Pricing</h3>
              <p className="text-gray-600">
                Transparent pricing with no hidden surprises.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6">Our Premium Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Tailored moving and storage solutions for every situation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <ServiceCard key={index} {...service} />
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6">What Our Customers Say</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Real feedback from real customers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((t) => (
              <div key={t.id} className="p-8 bg-gray-50 rounded-2xl shadow-lg">
                <div className="flex gap-1 mb-4">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star
                      key={i}
                      size={20}
                      className="text-yellow-400 fill-yellow-400"
                    />
                  ))}
                </div>
                <p className="italic mb-6">"{t.comment}"</p>
                <p className="font-bold">{t.name}</p>
                <p className="text-sm text-[#e71c5e]">{t.location}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <TrustedLogos />

      {/* FINAL CTA */}
      <section className="py-24 bg-[#e71c5e] text-white text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold mb-6">
            Ready to Experience Stress-Free Moving?
          </h2>
          <p className="text-xl mb-10 max-w-3xl mx-auto">
            Get your personalised quote in minutes. No obligation — just honest
            pricing and professional service.
          </p>
          <button
            onClick={onGetQuote}
            className="bg-white text-[#e71c5e] px-12 py-5 rounded-xl font-bold text-xl hover:bg-gray-100 transition-all"
          >
            Get Your Free Quote
          </button>
        </div>
      </section>
    </div>
  );
}
