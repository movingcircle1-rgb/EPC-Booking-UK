import { Home, Package, Truck, Shield, Clock, CheckCircle } from 'lucide-react';
import SEO from '../components/SEO';
import AutoLinkedContent from '../components/AutoLinkedContent';
import { useSEO } from '../hooks/useSEO';

export default function HouseRemovalsPage() {
  // IMPORTANT: NO trailing slash – must match Supabase page_path + useSEO normalisation
  const { seoData } = useSEO('/house-removals');

  const fallbackTitle =
    'House Removals | Professional Home Moving Services | National Removals and Storage';
  const fallbackDescription =
    'Professional house removal services for all home sizes. Full packing, secure transport, furniture assembly included. Fully insured with 25+ years experience. Call 0800 047 2607 for a free quote.';
  const fallbackKeywords =
    'house removals, residential removals, home moving, house movers UK, domestic removals, moving house service';
  const fallbackCanonical =
    'https://nationalremovalsandstorage.co.uk/house-removals/';

  const features = [
    {
      icon: Package,
      title: 'Full Packing Service',
      description:
        'Professional packing of all your belongings using high-quality materials',
    },
    {
      icon: Truck,
      title: 'Safe Transportation',
      description: 'Secure transport in our modern, GPS-tracked vehicles',
    },
    {
      icon: Shield,
      title: 'Fully Insured',
      description: 'Comprehensive insurance coverage for complete peace of mind',
    },
    {
      icon: Clock,
      title: 'Flexible Timing',
      description: 'Weekend and evening moves available to suit your schedule',
    },
  ];

  const process = [
    {
      step: '1',
      title: 'Free Survey',
      description:
        'We visit your home to assess your requirements and provide an accurate quote',
    },
    {
      step: '2',
      title: 'Planning',
      description:
        'Our team creates a detailed moving plan tailored to your specific needs',
    },
    {
      step: '3',
      title: 'Packing',
      description:
        'We carefully pack all your belongings using appropriate materials and techniques',
    },
    {
      step: '4',
      title: 'Moving Day',
      description:
        'Our experienced team handles your move efficiently and professionally',
    },
    {
      step: '5',
      title: 'Delivery',
      description:
        'We deliver and place everything in your new home according to your instructions',
    },
  ];

  return (
    <div>
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      {/* HERO */}
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-bold mb-6">House Removals</h1>
              <p className="text-xl text-gray-300 mb-8">
                Professional residential moving services designed to make your
                house move stress-free and straightforward
              </p>
              <a
                href="/contact/"
                className="inline-block bg-[#e71c5e] hover:bg-[#c91852] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg"
              >
                Get Your Free Quote
              </a>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="/House Removals.webp"
                alt="Professional house removals service"
                className="w-full h-96 object-cover"
                loading="eager"
              />
            </div>
          </div>
        </div>
      </div>

      {/* SERVICES */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Our House Moving Services
            </h2>
            <AutoLinkedContent
              content="From studio apartments to large family homes, we handle every size of residential move with the same care and professionalism"
              className="text-xl text-gray-600 max-w-3xl mx-auto"
              enableLinking={true}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-xl p-6 text-center hover:shadow-lg transition-shadow"
              >
                <div className="w-16 h-16 bg-[#e71c5e] rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon size={32} className="text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <AutoLinkedContent
                  content={feature.description}
                  className="text-gray-600"
                  enableLinking={true}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESS */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">
              Our Moving Process
            </h2>

            <div className="space-y-8">
              {process.map((item, index) => (
                <div key={index} className="flex gap-6 items-start">
                  <div className="flex-shrink-0 w-16 h-16 bg-[#e71c5e] rounded-full flex items-center justify-center text-white font-bold text-2xl">
                    {item.step}
                  </div>
                  <div className="flex-1 bg-white rounded-xl p-6 shadow-lg">
                    <h3 className="text-2xl font-bold mb-2">{item.title}</h3>
                    <AutoLinkedContent
                      content={item.description}
                      className="text-gray-700"
                      enableLinking={true}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* INCLUDED */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">
              What&apos;s Included
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                'Pre-move home survey',
                'High-quality packing materials',
                'Professional packing service',
                'Furniture disassembly and reassembly',
                'Careful loading and unloading',
                'Secure transportation',
                'Unpacking service available',
                'Disposal of packing materials',
                'Comprehensive insurance coverage',
                'GPS tracking of your belongings',
                'Dedicated move coordinator',
                'Post-move support',
              ].map((item, index) => (
                <div key={index} className="flex items-center gap-3">
                  <CheckCircle
                    size={24}
                    className="text-[#e71c5e] flex-shrink-0"
                  />
                  <span className="text-gray-700">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Ready to Move Home?
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Get your free, no-obligation quote today and let us take the
              stress out of your house move
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/contact/"
                className="bg-[#e71c5e] hover:bg-[#c91852] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg"
              >
                Request Free Quote
              </a>

              <a
                href="tel:08000472607"
                className="bg-white hover:bg-gray-100 text-[#e71c5e] border-2 border-[#e71c5e] px-8 py-4 rounded-lg font-semibold text-lg transition-all"
              >
                Call 0800 047 2607
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
