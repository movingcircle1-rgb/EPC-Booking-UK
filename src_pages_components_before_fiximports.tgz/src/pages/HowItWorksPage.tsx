import {
  Phone,
  ClipboardList,
  Calendar,
  Package,
  Truck,
  CheckCircle,
} from 'lucide-react';
import { brandConfig } from '../config/branding';
import SEO from '../components/SEO';
import { useSEO } from '../hooks/useSEO';

export default function HowItWorksPage() {
  // IMPORTANT: NO trailing slash – must match Supabase page_path + useSEO normalisation
  const { seoData } = useSEO('/how-it-works');

  const fallbackTitle =
    'How It Works | Simple 5-Step Moving Process | National Removals';
  const fallbackDescription =
    "Our simple moving process: Get quote, free survey, book your move, professional packing, and stress-free relocation. Fully insured. Call 0800 047 2607.";
  const fallbackKeywords =
    'moving process, how removals work, moving steps, relocation process, professional moving service, easy moving';
  const fallbackCanonical =
    'https://nationalremovalsandstorage.co.uk/how-it-works/';

  const steps = [
    {
      icon: Phone,
      title: 'Get in Touch',
      description:
        "Contact us via phone, email, or our online quote form. We'll discuss your requirements and provide an initial estimate.",
    },
    {
      icon: ClipboardList,
      title: 'Free Survey',
      description:
        'We arrange a free, no-obligation home visit to assess your needs and provide an accurate quote.',
    },
    {
      icon: Calendar,
      title: 'Book Your Move',
      description:
        'Choose a date that suits you. We offer flexible scheduling including evenings and weekends.',
    },
    {
      icon: Package,
      title: 'Packing',
      description:
        'Our team arrives to carefully pack your belongings using high-quality materials, or you can pack yourself.',
    },
    {
      icon: Truck,
      title: 'Moving Day',
      description:
        'Our professional team loads everything safely onto our modern vehicles and transports to your new location.',
    },
    {
      icon: CheckCircle,
      title: 'Settle In',
      description:
        'We unload and place items where you want them. Optional unpacking service available to help you settle in quickly.',
    },
  ];

  return (
    <div>
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold mb-6">How It Works</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Our simple, stress-free moving process from start to finish
          </p>
        </div>
      </div>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {steps.map((step, index) => (
              <div key={index} className="mb-12 flex gap-6 items-start">
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 bg-[#e71c5e] rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg">
                    {index + 1}
                  </div>
                </div>

                <div className="flex-grow">
                  <div className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-shadow">
                    <div className="flex items-center gap-3 mb-3">
                      <step.icon size={24} className="text-[#e71c5e]" />
                      <h3 className="text-2xl font-bold text-gray-900">
                        {step.title}
                      </h3>
                    </div>
                    <p className="text-gray-700 leading-relaxed">
                      {step.description}
                    </p>
                  </div>

                  {index < steps.length - 1 && (
                    <div className="ml-8 mt-4 mb-4 border-l-2 border-dashed border-gray-300 h-8" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">
              What to Expect
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl p-6 shadow-lg">
                <h3 className="text-xl font-bold mb-3 text-[#e71c5e]">
                  Before Moving Day
                </h3>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Receive detailed moving plan and timeline</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Get packing tips and materials if needed</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Confirm all details and special requirements</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Receive reminder call day before</span>
                  </li>
                </ul>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg">
                <h3 className="text-xl font-bold mb-3 text-[#e71c5e]">
                  On Moving Day
                </h3>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Team arrives on time with all equipment</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Careful loading with protective materials</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Regular updates during transport</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Careful unloading and placement</span>
                  </li>
                </ul>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg">
                <h3 className="text-xl font-bold mb-3 text-[#e71c5e]">
                  Our Commitment
                </h3>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Professional, uniformed staff</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Clean, modern vehicles</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Respect for your property</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Clear communication throughout</span>
                  </li>
                </ul>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg">
                <h3 className="text-xl font-bold mb-3 text-[#e71c5e]">
                  After Your Move
                </h3>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Follow-up call to ensure satisfaction</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Quick response to any concerns</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Support with unpacking if requested</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#e71c5e] mt-1">•</span>
                    <span>Ongoing storage solutions available</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-gradient-to-br from-[#e71c5e] to-[#c91852] rounded-2xl p-8 md:p-12 text-white text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Ready to Start Your Move?
            </h2>
            <p className="text-xl mb-8 text-white/90">
              Contact us today for a free quote and personalized moving plan
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href={brandConfig.contact.phoneHref}
                className="bg-white text-[#e71c5e] px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-all transform hover:scale-105"
              >
                Call {brandConfig.contact.phone}
              </a>

              <a
                href="/contact/"
                className="bg-white/20 backdrop-blur-sm text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-white/30 transition-all border border-white/40"
              >
                Request Quote Online
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
