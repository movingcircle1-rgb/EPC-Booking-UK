import {
  Globe,
  Ship,
  Plane,
  FileText,
  Shield,
  MapPin,
  CheckCircle,
} from 'lucide-react';
import SEO from '../components/SEO';
import AutoLinkedContent from '../components/AutoLinkedContent';
import { useSEO } from '../hooks/useSEO';

export default function InternationalMovesPage() {
  const { seoData } = useSEO('/international-moves');

  const fallbackTitle =
    'International Moves | National Removals and Storage';

  const fallbackDescription =
    'Worldwide international removal services from the UK. Professional moving to USA, Canada, Australia, Asia, and beyond. Sea and air freight options with full customs support.';

  const fallbackKeywords =
    'international moves, worldwide removals, overseas moving, international relocation, UK to USA moves, UK to Australia moves';

  const fallbackCanonical =
    'https://nationalremovalsandstorage.co.uk/international-moves/';

  const services = [
    {
      icon: Ship,
      title: 'Sea Freight',
      description: 'Cost-effective shipping for larger moves via container',
    },
    {
      icon: Plane,
      title: 'Air Freight',
      description: 'Fast delivery for urgent or smaller shipments',
    },
    {
      icon: FileText,
      title: 'Customs Clearance',
      description: 'Complete assistance with international customs',
    },
    {
      icon: Shield,
      title: 'Global Insurance',
      description: 'Worldwide coverage for your belongings',
    },
  ];

  const regions = [
    { name: 'North America', countries: ['USA', 'Canada', 'Mexico'] },
    { name: 'Asia Pacific', countries: ['Australia', 'New Zealand', 'Singapore', 'Japan', 'Hong Kong'] },
    { name: 'Middle East', countries: ['UAE', 'Saudi Arabia', 'Qatar', 'Kuwait'] },
    { name: 'Africa', countries: ['South Africa', 'Kenya', 'Nigeria', 'Egypt'] },
  ];

  return (
    <div>
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      {/* HERO */}
      <section className="bg-gradient-to-br from-gray-900 to-gray-800 text-white py-20">
        <div className="container mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <AutoLinkedContent
              as="h1"
              content="International Moves"
              className="text-5xl font-bold mb-6"
              enableLinking
            />
            <AutoLinkedContent
              content="Professional worldwide relocation services to any destination across the globe with comprehensive support every step of the way."
              className="text-xl text-gray-300 mb-8"
              enableLinking
            />

            <a
              href="/contact/"
              className="inline-block bg-[#e71c5e] hover:bg-[#c91852] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg"
            >
              Get Your Free Quote
            </a>
          </div>

          <div className="rounded-2xl overflow-hidden shadow-2xl">
            <img
              src="/Interantional Removals.webp"
              alt="International moves service"
              className="w-full h-96 object-cover"
              loading="eager"
            />
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Our International Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive shipping solutions tailored to your international relocation needs.
          </p>
        </div>

        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-gray-50 rounded-xl p-6 text-center hover:shadow-lg transition-shadow"
            >
              <div className="w-16 h-16 bg-[#e71c5e] rounded-full flex items-center justify-center mx-auto mb-4">
                <service.icon size={32} className="text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* DESTINATIONS */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 max-w-5xl">
          <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">
            Destinations We Serve
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {regions.map((region, index) => (
              <div key={index} className="bg-white rounded-xl p-8 shadow-lg">
                <div className="flex items-center gap-3 mb-4">
                  <Globe size={32} className="text-[#e71c5e]" />
                  <h3 className="text-2xl font-bold">{region.name}</h3>
                </div>

                <div className="space-y-2">
                  {region.countries.map((country, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <MapPin size={16} className="text-[#e71c5e]" />
                      <span className="text-gray-700">{country}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <p className="text-center text-gray-600 mt-8">
            We provide international moving services to virtually every country worldwide.
          </p>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-br from-[#e71c5e] to-[#c91852] text-white text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-6">
            Ready for Your International Move?
          </h2>

          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Get your free, comprehensive quote for your worldwide relocation today.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/contact/"
              className="inline-block bg-white text-[#e71c5e] px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transition-all transform hover:scale-105 shadow-xl"
            >
              Request Free Quote
            </a>

            <a
              href="tel:08000472607"
              className="inline-block border-2 border-white text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-white hover:text-[#e71c5e] transition-all"
            >
              Call 0800 047 2607
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
