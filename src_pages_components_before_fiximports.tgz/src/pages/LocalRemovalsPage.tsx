import { MapPin, Truck, Clock, Shield, CheckCircle } from 'lucide-react';
import SEO from '../components/SEO';
import AutoLinkedContent from '../components/AutoLinkedContent';
import { useSEO } from '../hooks/useSEO';

export default function LocalRemovalsPage() {
  const { seoData } = useSEO('/local');

  const fallbackTitle =
    'Local Removals | Fast & Reliable Moves | National Removals and Storage';
  const fallbackDescription =
    'Local removals with flexible scheduling, right-sized vehicles, and fully insured transport. Get a free quote for your local house or office move today.';
  const fallbackKeywords =
    'local removals, local movers, removals near me, local moving service, house move local, office move local';
  const fallbackCanonical = 'https://nationalremovalsandstorage.co.uk/local/';

  const features = [
    {
      icon: Clock,
      title: 'Same-Day Availability',
      description:
        'Short-notice local moves where possible, with flexible time slots.',
    },
    {
      icon: Truck,
      title: 'Right-Sized Vehicles',
      description:
        'Vans and lorries matched to your move size to keep costs down.',
    },
    {
      icon: Shield,
      title: 'Fully Insured',
      description: 'Comprehensive cover for peace of mind from start to finish.',
    },
    {
      icon: MapPin,
      title: 'Local Knowledge',
      description:
        'Experienced drivers who know the area, routes, and access challenges.',
    },
  ];

  const included = [
    'Pre-move consultation',
    'Protective blankets and straps',
    'Careful loading and unloading',
    'Basic furniture protection',
    'Flexible collection & delivery slots',
    'Optional packing service',
    'Optional storage if required',
    'Dedicated coordinator on the day',
  ];

  return (
    <div>
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      {/* HERO */}
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <AutoLinkedContent
                as="h1"
                content="Local Removals"
                className="text-5xl font-bold mb-6"
                enableLinking
              />
              <AutoLinkedContent
                content="Quick, careful and cost-effective local moves with a friendly team and flexible scheduling."
                className="text-xl text-gray-300 mb-8"
                enableLinking
              />

              {/* ✅ SSR-safe link */}
              <a
                href="/contact/"
                className="inline-block bg-[#e71c5e] hover:bg-[#c91852] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg"
              >
                Get Your Free Quote
              </a>
            </div>

            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="/Local Removals.webp"
                alt="Local removals service"
                className="w-full h-96 object-cover"
                loading="eager"
              />
            </div>
          </div>
        </div>
      </div>

      {/* FEATURES */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose Our Local Removals
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Local moves should be simple. We focus on speed, care, and clear
              pricing.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((f, idx) => (
              <div
                key={idx}
                className="bg-gray-50 rounded-xl p-6 text-center hover:shadow-lg transition-shadow"
              >
                <div className="w-16 h-16 bg-[#e71c5e] rounded-full flex items-center justify-center mx-auto mb-4">
                  <f.icon size={32} className="text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">{f.title}</h3>
                <p className="text-gray-600">{f.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* INCLUDED */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">
              What&apos;s Included
            </h2>

            <div className="bg-white rounded-2xl p-10 shadow-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {included.map((item, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <CheckCircle
                      size={24}
                      className="text-[#e71c5e] flex-shrink-0 mt-0.5"
                    />
                    <span className="text-gray-700">{item}</span>
                  </div>
                ))}
              </div>

              <p className="text-gray-600 mt-8 text-center">
                Need help with packing, furniture assembly, or storage? We’ll
                tailor the quote to match your move.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-br from-[#e71c5e] to-[#c91852] text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Move Locally?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Request your free, no-obligation quote today.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {/* ✅ SSR-safe link */}
            <a
              href="/contact/"
              className="inline-block bg-white text-[#e71c5e] px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transition-all transform hover:scale-105 shadow-xl"
            >
              Request Free Quote
            </a>

            <a
              href="tel:08000472607"
              className="inline-block bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-white hover:text-[#e71c5e] transition-all"
            >
              Call 0800 047 2607
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
