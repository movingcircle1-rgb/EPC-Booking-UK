// src/pages/LocationPage.tsx
import React, { useEffect, useMemo, useState } from 'react'
import { MapPin, Home, Building2, Package, Truck, Phone } from 'lucide-react'
import SEO from '../components/SEO'
import AutoLinkedContent from '../components/AutoLinkedContent'
import { supabase } from '../lib/supabase'
import { replaceTemplateVariables } from '../lib/auto-linking'
import { brandConfig } from '../config/branding'

interface LocationData {
  id: string
  name: string
  slug: string
  description: string | null
  meta_title: string | null
  meta_description: string | null
  areas_covered?: string[] | null
  region?: string | null
  local_info?: string | null
  map_embed_url?: string | null
}

interface ServiceTemplate {
  id: string
  template_name: string
  service_type: string
  hero_title_template: string | null
  hero_subtitle_template: string | null
  description_template: string | null
  meta_title_template: string | null
  meta_description_template: string | null
  sections: any[] | null
  is_active?: boolean
}

interface CityContentBlock {
  id: string
  city_id: string
  service_type: string
  block_position: number
  heading: string
  content: string
  image_url: string | null
  image_alt: string | null
}

type Props = {
  // Vike provides these from routeParams
  location?: string
  service?: string

  // SSR-provided data (from Vike +data.ts)
  locationData?: LocationData | null
  template?: ServiceTemplate | null
  contentBlocks?: CityContentBlock[]
}

const serviceTypeMap: Record<string, string> = {
  house: 'house-removals',
  office: 'office-removals',
  packing: 'packing-services',
  storage: 'storage-solutions',
  'house-removals': 'house-removals',
  'office-removals': 'office-removals',
  'packing-services': 'packing-services',
  'storage-solutions': 'storage-solutions',
}

function toTitleFromSlug(slug: string) {
  return slug.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
}

export default function LocationPage({
  location,
  service,
  locationData: initialLocationData = null,
  template: initialTemplate = null,
  contentBlocks: initialBlocks = [],
}: Props) {
  const [locationData, setLocationData] = useState<LocationData | null>(initialLocationData)
  const [template, setTemplate] = useState<ServiceTemplate | null>(initialTemplate)
  const [contentBlocks, setContentBlocks] = useState<CityContentBlock[]>(initialBlocks)
  const [loading, setLoading] = useState(!initialLocationData)

  const citySlug = location?.trim() || ''
  const serviceSlug = service ? serviceTypeMap[service] || service : 'house-removals'

  useEffect(() => {
    let cancelled = false

    async function load() {
      // SSR already provided data for this location; avoid loader flash
      if (initialLocationData && initialLocationData.slug === citySlug) {
        setLoading(false)
        return
      }

      setLoading(true)

      if (!citySlug) {
        if (!cancelled) {
          setLocationData(null)
          setTemplate(null)
          setContentBlocks([])
          setLoading(false)
        }
        return
      }

      // 1) city
      const { data: cityData, error: cityError } = await supabase
        .from('cities')
        .select('*')
        .eq('slug', citySlug)
        .maybeSingle()

      if (cancelled) return

      if (cityError || !cityData) {
        setLocationData(null)
        setTemplate(null)
        setContentBlocks([])
        setLoading(false)
        return
      }

      setLocationData(cityData)

      // 2) blocks
      const { data: blocks, error: blocksError } = await supabase
        .from('city_content_blocks')
        .select('*')
        .eq('city_id', cityData.id)
        .eq('service_type', serviceSlug)
        .order('block_position')

      if (!cancelled) {
        setContentBlocks(!blocksError && blocks ? blocks : [])
      }

      // 3) template
      const { data: templateData, error: templateError } = await supabase
        .from('location_content_templates')
        .select('*')
        .eq('service_type', serviceSlug)
        .eq('is_active', true)
        .maybeSingle()

      if (!cancelled) {
        setTemplate(!templateError && templateData ? templateData : null)
        setLoading(false)
      }
    }

    load()
    return () => {
      cancelled = true
    }
  }, [citySlug, serviceSlug])

  const cityName = useMemo(() => {
    if (locationData?.name) return locationData.name
    if (citySlug) return toTitleFromSlug(citySlug)
    return ''
  }, [locationData?.name, citySlug])

  const serviceTitle =
    serviceSlug === 'house-removals'
      ? 'House Removals'
      : serviceSlug === 'office-removals'
        ? 'Office Removals'
        : serviceSlug === 'packing-services'
          ? 'Packing Services'
          : serviceSlug === 'storage-solutions'
            ? 'Storage Solutions'
            : 'Removals'

  const variables = { location: cityName, service: serviceTitle }

  const title = template?.hero_title_template
    ? replaceTemplateVariables(template.hero_title_template, variables)
    : `${serviceTitle} in ${cityName}`

  const heroSubtitle = template?.hero_subtitle_template
    ? replaceTemplateVariables(template.hero_subtitle_template, variables)
    : `Your trusted local removal company serving ${cityName} and surrounding areas`

  const metaTitle =
    locationData?.meta_title ||
    (template?.meta_title_template
      ? replaceTemplateVariables(template.meta_title_template, variables)
      : null) ||
    title

  const metaDescription =
    locationData?.meta_description ||
    (template?.meta_description_template
      ? replaceTemplateVariables(template.meta_description_template, variables)
      : null) ||
    `Professional ${serviceTitle.toLowerCase()} services in ${cityName}. Get your free quote today.`

  const services = [
    { icon: Home, name: 'House Removals', slug: 'house-removals' },
    { icon: Building2, name: 'Office Removals', slug: 'office-removals' },
    { icon: Package, name: 'Packing Services', slug: 'packing-services' },
    { icon: Truck, name: 'Storage Solutions', slug: 'storage-solutions' },
  ]

  if (loading) {
    return (
      <div className="py-16">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#e71c5e] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

if (!citySlug || !locationData) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="max-w-2xl w-full bg-gray-50 rounded-2xl p-8 border">
          <h1 className="text-2xl font-bold mb-2">Location Not Found</h1>
          <p className="text-gray-700 mb-6">
            We couldn&apos;t find a location page for <b>{citySlug ? `"${citySlug}"` : '""'}</b>.
          </p>

          <div className="bg-white border rounded-xl p-4 font-mono text-sm text-gray-700">
            <div>
              <b>Debug</b>
            </div>
            <div>location param: {String(location)}</div>
            <div>service param: {String(service)}</div>
            <div>citySlug: {String(citySlug || 'undefined')}</div>
            <div>serviceSlug: {String(serviceSlug)}</div>
            <div>path: {typeof window !== 'undefined' ? window.location.pathname : '(ssr)'}</div>
          </div>

          <div className="mt-6 flex gap-3">
            {/* ✅ SSR-safe */}
            <a href="/" className="px-5 py-3 rounded-lg bg-black text-white">
              Return Home
            </a>
            <a href="/contact/" className="px-5 py-3 rounded-lg bg-white border">
              Contact Us
            </a>
          </div>
        </div>
      </div>
    )
  }

  // ✅ Always canonicalise to the real route slug, not the incoming param alias
  const canonicalServiceSlug = service ? serviceSlug : ''
  const canonicalUrl = `https://nationalremovalsandstorage.co.uk/locations/${citySlug}${
    canonicalServiceSlug ? `/${canonicalServiceSlug}` : ''
  }/`

  return (
    <div>
      <SEO
        title={metaTitle}
        description={metaDescription}
        keywords={`${serviceTitle} ${cityName}, removals ${cityName}, moving company ${cityName}, ${cityName} movers`}
        canonicalUrl={canonicalUrl}
      />

      <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex items-center justify-center gap-3 mb-6">
              <MapPin size={40} className="text-[#e71c5e]" />
              <h1 className="text-5xl font-bold">{title}</h1>
            </div>

            <AutoLinkedContent
              content={`<p class="text-xl text-gray-300 mb-8">${heroSubtitle}</p>`}
              enableLinking
            />

            {/* ✅ SSR-safe (no react-router in prerender/SSR) */}
            <a
              href="/contact/"
              className="inline-block bg-[#e71c5e] hover:bg-[#c91852] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg"
            >
              Get Your Free Quote
            </a>
          </div>
        </div>
      </div>

      {/* Custom SEO Content Blocks */}
      {contentBlocks.length > 0 &&
        contentBlocks.map((block, index) => (
          <section key={block.id} className={`py-16 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
            <div className="container mx-auto px-4">
              <div className="max-w-6xl mx-auto">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                  <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                    <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">{block.heading}</h2>
                    <AutoLinkedContent
                      content={block.content}
                      className="text-lg text-gray-700 leading-relaxed whitespace-pre-line"
                      enableLinking
                    />
                  </div>

                  {block.image_url ? (
                    <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                      <div className="relative rounded-xl overflow-hidden shadow-xl">
                        <img
                          src={block.image_url}
                          alt={block.image_alt || block.heading}
                          className="w-full h-auto object-cover"
                          loading="lazy"
                          onError={(e) => {
                            e.currentTarget.style.display = 'none'
                          }}
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="hidden lg:block" />
                  )}
                </div>
              </div>
            </div>
          </section>
        ))}

      {!service && (
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">Our Services in {cityName}</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {services.map((svc, index) => (
                  <a
                    key={index}
                    href={`/locations/${citySlug}/${svc.slug}/`}
                    className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-all border-2 border-transparent hover:border-[#e71c5e] group block"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-[#e71c5e] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <svc.icon size={24} className="text-white" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900">{svc.name}</h3>
                    </div>
                    <p className="text-gray-600 mt-4">
                      Professional {svc.name.toLowerCase()} services in {cityName}
                    </p>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto bg-gray-50 rounded-2xl p-10 text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Ready to Move in {cityName}?</h2>
            <p className="text-xl text-gray-600 mb-8">Get your free, no-obligation quote today</p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {/* ✅ SSR-safe */}
              <a
                href="/contact/"
                className="bg-[#e71c5e] hover:bg-[#c91852] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg"
              >
                Request Free Quote
              </a>

              <a
                href={brandConfig.contact.phoneHref}
                className="bg-white hover:bg-gray-100 text-[#e71c5e] border-2 border-[#e71c5e] px-8 py-4 rounded-lg font-semibold text-lg transition-all"
              >
                <Phone size={20} className="inline mr-2" />
                {brandConfig.contact.phone}
              </a>
            </div>
          </div>
        </div>
      </section>

      {locationData?.map_embed_url && (
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">Find Us in {cityName}</h2>
              <div className="aspect-video rounded-xl overflow-hidden border border-gray-300 shadow-lg">
                <iframe
                  src={locationData.map_embed_url}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title={`Map of ${cityName}`}
                />
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  )
}
