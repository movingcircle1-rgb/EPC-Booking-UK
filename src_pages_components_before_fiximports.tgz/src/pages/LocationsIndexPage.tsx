import { useEffect, useMemo, useState } from 'react'
import { MapPin, Search } from 'lucide-react'
import { supabase } from '../lib/supabase'
import SEO from '../components/SEO'
import { useSEO } from '../hooks/useSEO'

interface City {
  id: string
  name: string
  slug: string
  region: string
  is_featured: boolean
}

export default function LocationsIndexPage() {
  // IMPORTANT: NO trailing slash – must match Supabase page_path + useSEO normalisation
  const { seoData } = useSEO('/locations')

  const [cities, setCities] = useState<City[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')

  useEffect(() => {
    loadCities()
  }, [])

  const loadCities = async () => {
    setLoading(true)

    const { data, error } = await supabase
      .from('cities')
      .select('id, name, slug, region, is_featured')
      .order('name')

    if (!error && data) setCities(data)
    setLoading(false)
  }

  const filteredCities = useMemo(() => {
    const q = searchTerm.trim().toLowerCase()
    if (!q) return cities

    return cities.filter((city) => {
      const nameMatch = city.name.toLowerCase().includes(q)
      const regionMatch = (city.region || '').toLowerCase().includes(q)
      return nameMatch || regionMatch
    })
  }, [cities, searchTerm])

  const citiesByRegion = useMemo(() => {
    return filteredCities.reduce((acc, city) => {
      const region = city.region || 'Other'
      if (!acc[region]) acc[region] = []
      acc[region].push(city)
      return acc
    }, {} as Record<string, City[]>)
  }, [filteredCities])

  const featured = useMemo(() => cities.filter((c) => c.is_featured), [cities])

  // ✅ Make these dynamic like other pages (prevents hard-coded SEO + supports Supabase overrides)
  const fallbackTitle =
    'Our Locations | UK-Wide Removal Services | National Removals and Storage'
  const fallbackDescription =
    'Find professional removal and storage services in your area. We serve locations across the UK including London, Birmingham, Manchester, and more. Call 0800 047 2607.'
  const fallbackKeywords =
    'removals near me, local removal company, UK removals, nationwide movers, removal services locations'
  const fallbackCanonical = 'https://nationalremovalsandstorage.co.uk/locations/'

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Our Service Locations
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Professional removal and storage services across the UK. Select your
            location to learn more about our services in your area.
          </p>
        </div>

        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative max-w-md mx-auto">
            <Search
              className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
              size={20}
            />
            <input
              type="text"
              placeholder="Search for your city..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#e71c5e] focus:border-transparent"
            />
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#e71c5e]"></div>
          </div>
        ) : (
          <>
            {/* Featured Locations */}
            {featured.length > 0 && (
              <div className="mb-12">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">
                  Featured Locations
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {featured.map((city) => (
                    // ✅ SSR-safe: use <a> not <Link>
                    <a
                      key={city.id}
                      href={`/locations/${city.slug}/`}
                      className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:border-[#e71c5e] hover:bg-pink-50 transition-all group"
                    >
                      <MapPin className="w-5 h-5 text-[#e71c5e] group-hover:scale-110 transition-transform" />
                      <div>
                        <div className="font-semibold text-gray-900 group-hover:text-[#e71c5e]">
                          {city.name}
                        </div>
                        {city.region && (
                          <div className="text-sm text-gray-500">
                            {city.region}
                          </div>
                        )}
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* All Locations by Region */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                All Locations
              </h2>

              {Object.keys(citiesByRegion).length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  No locations found matching your search.
                </div>
              ) : (
                <div className="space-y-8">
                  {Object.keys(citiesByRegion)
                    .sort()
                    .map((region) => (
                      <div key={region}>
                        <h3 className="text-xl font-semibold text-gray-900 mb-4">
                          {region}
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                          {citiesByRegion[region].map((city) => (
                            // ✅ SSR-safe: use <a> not <Link>
                            <a
                              key={city.id}
                              href={`/locations/${city.slug}/`}
                              className="flex items-center gap-2 p-3 border border-gray-200 rounded-lg hover:border-[#e71c5e] hover:bg-pink-50 transition-all group"
                            >
                              <MapPin className="w-4 h-4 text-[#e71c5e] flex-shrink-0" />
                              <span className="font-medium text-gray-900 group-hover:text-[#e71c5e]">
                                {city.name}
                              </span>
                            </a>
                          ))}
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>

            {/* Services Available */}
            <div className="mt-12 bg-gray-50 rounded-xl p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Services Available in All Locations
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">
                    Removal Services
                  </h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• House Removals</li>
                    <li>• Office Removals</li>
                    <li>• Furniture Removal</li>
                    <li>• Student Removals</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">
                    Additional Services
                  </h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Packing Services</li>
                    <li>• Storage Solutions</li>
                    <li>• European Moves</li>
                    <li>• International Moves</li>
                  </ul>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
