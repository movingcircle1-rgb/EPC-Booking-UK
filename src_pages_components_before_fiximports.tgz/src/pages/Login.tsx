
import React from 'react'
import { useNavigate } from 'react-router-dom'
import SEO from '../components/SEO'

export default function Login() {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <SEO
        title="Login"
        description="Login to your account"
        canonicalUrl="https://nationalremovalsandstorage.co.uk/login"
        noindex={true}
      />

      <div className="w-full max-w-md bg-white rounded-xl shadow-lg p-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Login</h1>
        <p className="text-gray-600 mb-6">
          Login page placeholder. Wire this up to your auth UI when ready.
        </p>

        <div className="flex gap-3">
          <button
            onClick={() => navigate('/')}
            className="flex-1 bg-gray-900 text-white py-3 rounded-lg font-semibold hover:bg-gray-800 transition"
          >
            Back Home
          </button>

          <button
            onClick={() => navigate('/client-portal')}
            className="flex-1 bg-[#e71c5e] text-white py-3 rounded-lg font-semibold hover:opacity-90 transition"
          >
            Client Portal
          </button>
        </div>
      </div>
    </div>
  )
}
