import { Truck, MapPin, Shield, Calendar, CheckCircle } from 'lucide-react'
import SafeLink from '../components/SafeLink'import SEO from '../components/SEO'
import AutoLinkedContent from '../components/AutoLinkedContent'
import { useSEO } from '../hooks/useSEO'

export default function NationalRemovalsPage() {
  // IMPORTANT: NO trailing slash – must match Supabase page_path + useSEO normalisation
  const { seoData } = useSEO('/national')

  const fallbackTitle =
    'National Removals | UK-Wide Moving Services | National Removals and Storage'
  const fallbackDescription =
    'National removals across the UK with GPS-tracked vehicles, flexible delivery dates, and fully insured transport. Get a free quote for your long-distance move.'
  const fallbackKeywords =
    'national removals, UK removals, long distance removals, nationwide movers, national moving service, UK house move'
  const fallbackCanonical =
    'https://nationalremovalsandstorage.co.uk/national/'

  const features = [
    {
      icon: Truck,
      title: 'UK-Wide Coverage',
      description:
        'Reliable long-distance moves across England, Scotland, Wales and Northern Ireland.',
    },
    {
      icon: MapPin,
      title: 'Tracked Vehicles',
      description:
        'GPS-tracked fleet with planned routes and clear delivery coordination.',
    },
    {
      icon: Calendar,
      title: 'Flexible Delivery Dates',
      description:
        'Choose a date that suits you — ideal for chains and staggered completions.',
    },
    {
      icon: Shield,
      title: 'Fully Insured',
      description:
        'Comprehensive protection for your belongings throughout the journey.',
    },
  ]

  const included = [
    'Free pre-move consultation',
    'Loading/unloading with protective equipment',
    'Furniture protection (blankets, straps, wraps)',
    'Optional full packing service',
    'Optional storage (short/long term)',
    'Dedicated move coordinator',
    'Clear ETA and delivery planning',
    'Insurance options available',
  ]

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      {/* HERO */}
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <AutoLinkedContent
                as="h1"
                content="National Removals"
                className="text-5xl font-bold mb-6"
                enableLinking={true}
              />
              <AutoLinkedContent
                content="UK-wide moving services with careful handling, clear timelines, and a dedicated coordinator."
                className="text-xl text-gray-300 mb-8"
                enableLinking={true}
              />
              <SafeLink
                to="/contact/"
                className="inline-block bg-[#e71c5e] hover:bg-[#c91852] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg"
              >
                Get Your Free Quote
              </SafeLink>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="/National Removals.webp"
                alt="National removals service"
                className="w-full h-96 object-cover"
                loading="eager"
              />
            </div>
          </div>
        </div>
      </div>

      {/* FEATURES */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose Our National Removals
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Long-distance moves require precision planning. We deliver a smooth experience from collection to delivery.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((f, idx) => (
              <div
                key={idx}
                className="bg-gray-50 rounded-xl p-6 text-center hover:shadow-lg transition-shadow"
              >
                <div className="w-16 h-16 bg-[#e71c5e] rounded-full flex items-center justify-center mx-auto mb-4">
                  <f.icon size={32} className="text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">{f.title}</h3>
                <p className="text-gray-600">{f.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* INCLUDED */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">
              What’s Included
            </h2>

            <div className="bg-white rounded-2xl p-10 shadow-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {included.map((item, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <CheckCircle
                      size={24}
                      className="text-[#e71c5e] flex-shrink-0 mt-0.5"
                    />
                    <span className="text-gray-700">{item}</span>
                  </div>
                ))}
              </div>

              <p className="text-gray-600 mt-8 text-center">
                Need split collections, temporary storage, or packing? We tailor every national move to your timeline.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-br from-[#e71c5e] to-[#c91852] text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">
            Planning a UK-Wide Move?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Get a free, comprehensive quote today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <SafeLink
              to="/contact/"
              className="inline-block bg-white text-[#e71c5e] px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transition-all transform hover:scale-105 shadow-xl"
            >
              Request Free Quote
            </SafeLink>
            <a
              href="tel:08000472607"
              className="inline-block bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-white hover:text-[#e71c5e] transition-all"
            >
              Call 0800 047 2607
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
