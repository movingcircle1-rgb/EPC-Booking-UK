import { Building2, Clock, Shield, Users, Laptop, FileText } from 'lucide-react'
import SafeLink from '../components/SafeLink'import SEO from '../components/SEO'
import AutoLinkedContent from '../components/AutoLinkedContent'
import { useSEO } from '../hooks/useSEO'

export default function OfficeRemovalsPage() {
  // IMPORTANT: NO trailing slash – must match Supabase page_path + useSEO normalisation
  const { seoData } = useSEO('/office-removals')

  const fallbackTitle =
    'Office Removals | Commercial Relocation Services | National Removals and Storage'
  const fallbackDescription =
    'Professional office relocation services with minimal business disruption. IT equipment handling, out-of-hours moves, secure document transport. Fully insured. Call 0800 047 2607 for a free quote.'
  const fallbackKeywords =
    'office removals, commercial removals, business relocation, office movers UK, company relocation, corporate moving'
  const fallbackCanonical =
    'https://nationalremovalsandstorage.co.uk/office-removals/'

  const features = [
    {
      icon: Clock,
      title: 'Minimal Downtime',
      description:
        'Out-of-hours and weekend moves to keep your business running.',
    },
    {
      icon: Laptop,
      title: 'IT Equipment Handling',
      description:
        'Specialist care for computers, servers, and sensitive technology.',
    },
    {
      icon: FileText,
      title: 'Document Security',
      description:
        'Secure handling and transport of confidential documents and archives.',
    },
    {
      icon: Users,
      title: 'Dedicated Project Manager',
      description:
        'A single point of contact throughout your office relocation.',
    },
  ]

  const services = [
    'Complete office packing service',
    'IT and server room relocation',
    'Office furniture disassembly and assembly',
    'Secure document and archive moving',
    'Equipment installation and setup',
    'Storage solutions during transition',
    'Workspace planning and layout support',
    'Post-move cleaning services',
  ]

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      {/* HERO */}
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <AutoLinkedContent
                as="h1"
                content="Office Removals"
                className="text-5xl font-bold mb-6"
                enableLinking={true}
              />
              <AutoLinkedContent
                content="Professional commercial relocation services designed to minimise disruption and keep your business moving forward."
                className="text-xl text-gray-300 mb-8"
                enableLinking={true}
              />
              <SafeLink
                to="/contact/"
                className="inline-block bg-[#e71c5e] hover:bg-[#c91852] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg"
              >
                Get Your Free Quote
              </SafeLink>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="/Office Removals.webp"
                alt="Office removals service"
                className="w-full h-96 object-cover"
                loading="eager"
              />
            </div>
          </div>
        </div>
      </div>

      {/* FEATURES */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose Our Office Moving Service
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Office moves require careful coordination. We focus on maintaining
              business continuity while delivering a smooth transition.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-xl p-6 text-center hover:shadow-lg transition-shadow"
              >
                <div className="w-16 h-16 bg-[#e71c5e] rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon size={32} className="text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESS */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">
              Our Office Relocation Process
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  phase: 'Phase 1',
                  title: 'Planning',
                  items: [
                    'Initial site survey',
                    'Detailed moving plan',
                    'Timeline development',
                    'Budget proposal',
                    'Risk assessment',
                  ],
                },
                {
                  phase: 'Phase 2',
                  title: 'Preparation',
                  items: [
                    'Equipment labelling',
                    'IT disconnection coordination',
                    'Packing organisation',
                    'Team briefing',
                    'Schedule confirmation',
                  ],
                },
                {
                  phase: 'Phase 3',
                  title: 'Execution',
                  items: [
                    'Secure transportation',
                    'Equipment installation',
                    'IT reconnection support',
                    'Layout setup',
                    'Final verification',
                  ],
                },
              ].map((phase, index) => (
                <div key={index} className="bg-white rounded-xl p-8 shadow-lg">
                  <div className="text-[#e71c5e] text-3xl font-bold mb-4">
                    {phase.phase}
                  </div>
                  <h3 className="text-2xl font-bold mb-4">
                    {phase.title}
                  </h3>
                  <ul className="space-y-2 text-gray-700">
                    {phase.items.map((item, i) => (
                      <li key={i}>• {item}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">
              Our Commercial Moving Services
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {services.map((service, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 bg-gray-50 rounded-lg p-4"
                >
                  <Shield
                    size={24}
                    className="text-[#e71c5e] flex-shrink-0"
                  />
                  <span className="text-gray-700">
                    {service}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-br from-[#e71c5e] to-[#c91852] text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">
            Ready to Move Your Office?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Contact us today for a free consultation and detailed commercial moving quote.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <SafeLink
              to="/contact/"
              className="inline-block bg-white text-[#e71c5e] px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transition-all transform hover:scale-105 shadow-xl"
            >
              Request Free Quote
            </SafeLink>
            <a
              href="tel:08000472607"
              className="inline-block bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-white hover:text-[#e71c5e] transition-all"
            >
              Call 0800 047 2607
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
