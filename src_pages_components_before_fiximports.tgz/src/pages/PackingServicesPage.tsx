import { Package, Shield, CheckCircle, Box } from 'lucide-react'
import SafeLink from '../components/SafeLink'import SEO from '../components/SEO'
import AutoLinkedContent from '../components/AutoLinkedContent'
import { useSEO } from '../hooks/useSEO'

export default function PackingServicesPage() {
  // IMPORTANT: NO trailing slash – must match Supabase page_path + useSEO normalisation
  const { seoData } = useSEO('/packing-services')

  const fallbackTitle =
    'Packing Services | Professional Packers & Materials | National Removals and Storage'
  const fallbackDescription =
    'Professional packing services with premium quality materials. Full packing, partial packing, or materials only. Expert care for fragile items and comprehensive protection for all belongings.'
  const fallbackKeywords =
    'packing services, house packing, moving packing, packing materials, professional packers, fragile item packing'
  const fallbackCanonical =
    'https://nationalremovalsandstorage.co.uk/packing-services/'

  const packingOptions = [
    {
      title: 'Full Packing Service',
      description: 'We pack everything for you from start to finish.',
      features: [
        'Complete household packing',
        'All materials provided',
        'Professional packing team',
        'Labelling and room organisation',
        'Fragile item protection',
      ],
      popular: true,
    },
    {
      title: 'Partial Packing',
      description: 'We pack specific rooms, delicate items, or high-value areas.',
      features: [
        'Flexible room selection',
        'Focus on fragile items',
        'High-value item protection',
        'Customised approach',
        'Materials included',
      ],
      popular: false,
    },
    {
      title: 'Packing Materials Only',
      description: 'Quality packing materials delivered to your door.',
      features: [
        'Boxes in various sizes',
        'Bubble wrap and paper',
        'Packing tape',
        'Markers and labels',
        'Delivery included',
      ],
      popular: false,
    },
  ]

  const materials = [
    { name: 'Moving Boxes', description: 'Various sizes from small to extra-large.' },
    { name: 'Wardrobe Boxes', description: 'Keep clothes on hangers during transport.' },
    { name: 'Bubble Wrap', description: 'For protecting fragile and delicate items.' },
    { name: 'Packing Paper', description: 'Clean newsprint for wrapping.' },
    { name: 'Tape and Dispensers', description: 'Heavy-duty packing tape.' },
    { name: 'Labels and Markers', description: 'For easy identification and organisation.' },
  ]

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      {/* HERO */}
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <AutoLinkedContent
                as="h1"
                content="Professional Packing Services"
                className="text-5xl font-bold mb-6"
                enableLinking={true}
              />
              <AutoLinkedContent
                content="Expert packing using premium materials to help your belongings arrive safely and make moving day simpler."
                className="text-xl text-gray-300 mb-8"
                enableLinking={true}
              />
              <SafeLink
                to="/contact/"
                className="inline-block bg-[#e71c5e] hover:bg-[#c91852] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg"
              >
                Get Your Free Quote
              </SafeLink>
            </div>

            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="/Packing Services.webp"
                alt="Professional packing services"
                className="w-full h-96 object-cover"
                loading="eager"
              />
            </div>
          </div>
        </div>
      </div>

      {/* PACKING OPTIONS */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <AutoLinkedContent
              as="h2"
              content="Our Packing Options"
              className="text-4xl font-bold text-gray-900 mb-4"
              enableLinking={true}
            />
            <AutoLinkedContent
              content="Choose the level of service that fits your move, timeline, and budget."
              className="text-xl text-gray-600 max-w-3xl mx-auto"
              enableLinking={true}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {packingOptions.map((option, index) => (
              <div
                key={index}
                className={`rounded-xl p-8 shadow-lg ${
                  option.popular
                    ? 'bg-gradient-to-br from-[#e71c5e] to-[#c91852] text-white transform scale-105'
                    : 'bg-white border-2 border-gray-200'
                }`}
              >
                {option.popular && (
                  <div className="text-center mb-4">
                    <span className="inline-block bg-white text-[#e71c5e] px-4 py-1 rounded-full text-sm font-bold">
                      Most Popular
                    </span>
                  </div>
                )}

                <h3
                  className={`text-2xl font-bold mb-3 ${
                    option.popular ? 'text-white' : 'text-gray-900'
                  }`}
                >
                  {option.title}
                </h3>

                <p className={`mb-6 ${option.popular ? 'text-white/90' : 'text-gray-600'}`}>
                  {option.description}
                </p>

                <ul className="space-y-3">
                  {option.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle
                        size={20}
                        className={`flex-shrink-0 mt-0.5 ${
                          option.popular ? 'text-white' : 'text-[#e71c5e]'
                        }`}
                      />
                      <span className={option.popular ? 'text-white' : 'text-gray-700'}>
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MATERIALS */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <AutoLinkedContent
              as="h2"
              content="Quality Packing Materials"
              className="text-4xl font-bold text-gray-900 mb-12 text-center"
              enableLinking={true}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {materials.map((material, index) => (
                <div key={index} className="bg-white rounded-xl p-6 shadow-lg flex gap-4">
                  <div className="flex-shrink-0">
                    <Box size={40} className="text-[#e71c5e]" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">{material.name}</h3>
                    <p className="text-gray-600">{material.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* WHY PRO PACKING */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <AutoLinkedContent
              as="h2"
              content="Why Professional Packing Matters"
              className="text-4xl font-bold text-gray-900 mb-8 text-center"
              enableLinking={true}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-gray-50 rounded-xl p-6">
                <div className="w-12 h-12 bg-[#e71c5e] rounded-full flex items-center justify-center mb-4">
                  <Shield size={24} className="text-white" />
                </div>
                <h3 className="text-xl font-bold mb-3">Protection</h3>
                <p className="text-gray-700">
                  Professional packing reduces the risk of damage during transport.
                  We use the right materials and methods for each item type.
                </p>
              </div>

              <div className="bg-gray-50 rounded-xl p-6">
                <div className="w-12 h-12 bg-[#e71c5e] rounded-full flex items-center justify-center mb-4">
                  <Package size={24} className="text-white" />
                </div>
                <h3 className="text-xl font-bold mb-3">Efficiency</h3>
                <p className="text-gray-700">
                  Save time and stress by letting our team handle packing.
                  What can take days DIY, we can often complete in hours.
                </p>
              </div>

              <div className="bg-gray-50 rounded-xl p-6">
                <div className="w-12 h-12 bg-[#e71c5e] rounded-full flex items-center justify-center mb-4">
                  <CheckCircle size={24} className="text-white" />
                </div>
                <h3 className="text-xl font-bold mb-3">Organisation</h3>
                <p className="text-gray-700">
                  Clear labelling and room-by-room packing helps you unpack faster,
                  and keeps essentials easy to locate on arrival.
                </p>
              </div>

              <div className="bg-gray-50 rounded-xl p-6">
                <div className="w-12 h-12 bg-[#e71c5e] rounded-full flex items-center justify-center mb-4">
                  <Shield size={24} className="text-white" />
                </div>
                <h3 className="text-xl font-bold mb-3">Peace of Mind</h3>
                <p className="text-gray-700">
                  Having everything packed properly helps avoid last-minute chaos
                  and supports a smoother, faster moving day.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SPECIAL ITEMS */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto bg-white rounded-2xl p-10 shadow-xl">
            <AutoLinkedContent
              as="h2"
              content="Special Item Packing"
              className="text-3xl font-bold text-gray-900 mb-6 text-center"
              enableLinking={true}
            />
            <p className="text-gray-600 mb-8 text-center">
              We use specialised techniques for delicate and valuable items, including:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                'Artwork and paintings',
                'Antique furniture',
                'Fine china and glassware',
                'Electronics and TVs',
                'Musical instruments',
                'Mirrors and glass',
                'Lamps and lighting',
                'Collectibles and valuables',
              ].map((item, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-[#e71c5e] rounded-full" />
                  <span className="text-gray-700">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-br from-[#e71c5e] to-[#c91852] text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Tell us what you need packed and when — we’ll build the right packing solution into your quote.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <SafeLink
              to="/contact/"
              className="inline-block bg-white text-[#e71c5e] px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transition-all transform hover:scale-105 shadow-xl"
            >
              Request Free Quote
            </SafeLink>
            <a
              href="tel:08000472607"
              className="inline-block bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-white hover:text-[#e71c5e] transition-all"
            >
              Call 0800 047 2607
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
