import { Home, Building2, Truck, Package, MapPin, Globe } from 'lucide-react'
import SafeLink from '../components/SafeLink'
import SEO from '../components/SEO'
import ServiceCard from '../components/ServiceCard'
import AutoLinkedContent from '../components/AutoLinkedContent'
import { useSEO } from '../hooks/useSEO'

export default function RemovalsPage() {
  // IMPORTANT: NO trailing slash – must match Supabase page_path + useSEO normalisation
  const { seoData } = useSEO('/removals')

  const removalServices = [
    {
      icon: Home,
      title: 'House Removals',
      description: 'Comprehensive residential moving services for all home sizes',
      features: [
        'Full packing and unpacking',
        'Furniture disassembly and assembly',
        'Secure transportation',
        'Fragile item handling',
      ],
      imageUrl:
        'https://images.pexels.com/photos/7018391/pexels-photo-7018391.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '/house-removals/',
    },
    {
      icon: Building2,
      title: 'Office Removals',
      description: 'Professional commercial relocation with minimal disruption',
      features: [
        'Out-of-hours moving',
        'IT equipment handling',
        'Secure document transport',
        'Project management',
      ],
      imageUrl:
        'https://images.pexels.com/photos/7414012/pexels-photo-7414012.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '/office-removals/',
    },
    {
      icon: Truck,
      title: 'Local Removals',
      description: 'Quick and efficient moves within your local area',
      features: [
        'Same-day service available',
        'Local area expertise',
        'Flexible scheduling',
        'Competitive pricing',
      ],
      imageUrl:
        'https://images.pexels.com/photos/4246209/pexels-photo-4246209.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '/local/',
    },
    {
      icon: MapPin,
      title: 'National Removals',
      description: 'Reliable long-distance moves across the UK',
      features: [
        'Nationwide coverage',
        'GPS tracking',
        'Flexible delivery dates',
        'Comprehensive insurance',
      ],
      imageUrl:
        'https://images.pexels.com/photos/4246148/pexels-photo-4246148.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '/national/',
    },
    {
      icon: Globe,
      title: 'European Moves',
      description: 'Seamless relocations to European destinations',
      features: [
        'EU-wide network',
        'Customs assistance',
        'Door-to-door service',
        'Multi-language support',
      ],
      imageUrl:
        'https://images.pexels.com/photos/4246197/pexels-photo-4246197.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '/european-moves/',
    },
    {
      icon: Package,
      title: 'International Moves',
      description: 'Worldwide moving services with full support',
      features: [
        'Global shipping network',
        'Customs clearance',
        'Container shipping',
        'International insurance',
      ],
      imageUrl:
        'https://images.pexels.com/photos/4246166/pexels-photo-4246166.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '/international-moves/',
    },
  ]

  const fallbackTitle =
    'Removals Services | House & Office Moves | National Removals and Storage'
  const fallbackDescription =
    'Professional removal services for house moves, office relocations, local, national, European and international moves. Fully insured, experienced team. Based in Willenhall, serving UK-wide. Call 0800 047 2607.'
  const fallbackKeywords =
    'removals, house removals, office removals, local removals, national removals, European moves, international removals, UK moving company, Willenhall removals'
  const fallbackCanonical = 'https://nationalremovalsandstorage.co.uk/removals/'

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      {/* HERO */}
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <AutoLinkedContent
            as="h1"
            content="Professional Removals Services"
            className="text-5xl font-bold mb-6"
            enableLinking={true}
          />
          <AutoLinkedContent
            content="From local house moves to international relocations, we provide comprehensive removal services tailored to your needs."
            className="text-xl text-gray-300 max-w-3xl mx-auto"
            enableLinking={true}
          />

          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <SafeLink
              to="/contact/"
              className="inline-block bg-[#e71c5e] hover:bg-[#c91852] text-white px-10 py-4 rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-xl"
            >
              Request Your Free Quote
            </SafeLink>
            <a
              href="tel:08000472607"
              className="inline-block bg-transparent border-2 border-white text-white px-10 py-4 rounded-lg font-bold text-lg hover:bg-white hover:text-[#e71c5e] transition-all"
            >
              Call 0800 047 2607
            </a>
          </div>
        </div>
      </div>

      {/* SERVICES GRID */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <AutoLinkedContent
              as="h2"
              content="Our Removal Services"
              className="text-4xl font-bold text-gray-900 mb-4"
              enableLinking={true}
            />
            <AutoLinkedContent
              content="Whatever your moving needs, we have the expertise and resources to make your relocation smooth and stress-free."
              className="text-xl text-gray-600 max-w-3xl mx-auto"
              enableLinking={true}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {removalServices.map((service, index) => (
              <SafeLink key={index} to={service.link} className="group">
                <ServiceCard
                  icon={service.icon}
                  title={service.title}
                  description={service.description}
                  features={service.features}
                  imageUrl={service.imageUrl}
                  onLearnMore={() => {}}
                />
              </SafeLink>
            ))}
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">
              Why Choose Us for Your Move?
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl p-6 shadow-lg">
                <h3 className="text-xl font-bold mb-3 text-[#e71c5e]">
                  Experienced Team
                </h3>
                <p className="text-gray-700">
                  Our fully trained professionals have years of experience
                  handling all types of moves, from single items to complete
                  households and offices.
                </p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg">
                <h3 className="text-xl font-bold mb-3 text-[#e71c5e]">
                  Comprehensive Insurance
                </h3>
                <p className="text-gray-700">
                  All our services include comprehensive insurance coverage,
                  giving you complete peace of mind throughout your move.
                </p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg">
                <h3 className="text-xl font-bold mb-3 text-[#e71c5e]">
                  Modern Fleet
                </h3>
                <p className="text-gray-700">
                  Our well-maintained fleet is equipped with GPS tracking and
                  fitted with protective equipment to ensure safe transport.
                </p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg">
                <h3 className="text-xl font-bold mb-3 text-[#e71c5e]">
                  Transparent Pricing
                </h3>
                <p className="text-gray-700">
                  No hidden fees or surprises. We provide detailed quotes
                  upfront so you know exactly what to expect.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-br from-[#e71c5e] to-[#c91852] text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Get a free, no-obligation quote for your upcoming move.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <SafeLink
              to="/contact/"
              className="inline-block bg-white text-[#e71c5e] px-10 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transition-all transform hover:scale-105 shadow-xl"
            >
              Request Your Free Quote
            </SafeLink>
            <a
              href="tel:08000472607"
              className="inline-block bg-transparent border-2 border-white text-white px-10 py-4 rounded-lg font-bold text-lg hover:bg-white hover:text-[#e71c5e] transition-all"
            >
              Call 0800 047 2607
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
