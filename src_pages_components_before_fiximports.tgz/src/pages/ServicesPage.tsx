import { Home, Building2, Warehouse, Package, Truck, Shield } from 'lucide-react'
import ServiceCard from '../components/ServiceCard'
import SEO from '../components/SEO'
import AutoLinkedContent from '../components/AutoLinkedContent'
import { useSEO } from '../hooks/useSEO'

interface ServicesPageProps {
  onNavigate: (page: string) => void
}

export default function ServicesPage({ onNavigate }: ServicesPageProps) {
  // IMPORTANT: NO trailing slash – must match Supabase page_path + useSEO normalisation
  const { seoData } = useSEO('/services')

  const fallbackTitle = 'Our Services | National Removals and Storage'
  const fallbackDescription =
    'House removals, office relocations, storage solutions, and packing services across the UK. Professional, insured moving services with 25+ years experience.'
  const fallbackKeywords =
    'house removals, office removals, storage solutions, packing services, international moves, specialist removals, UK moving company'
  const fallbackCanonical = 'https://nationalremovalsandstorage.co.uk/services/'

  const services = [
    {
      icon: Home,
      title: 'House Removals',
      description: 'Complete residential moving solutions for homes of all sizes',
      features: [
        'Full packing and unpacking service',
        'Secure transportation with GPS tracking',
        'Comprehensive insurance coverage',
        'Furniture disassembly and reassembly',
        'Flexible scheduling including weekends',
        'Specialist handling for fragile items',
      ],
    },
    {
      icon: Building2,
      title: 'Office Removals',
      description: 'Professional commercial relocation with minimal business disruption',
      features: [
        'Out-of-hours and weekend moves',
        'IT equipment handling and setup',
        'Secure document transportation',
        'Office furniture installation',
        'Minimal business downtime',
        'Dedicated project manager',
      ],
    },
    {
      icon: Warehouse,
      title: 'Storage Solutions',
      description: 'Safe, secure, and flexible storage for short or long term',
      features: [
        '24/7 CCTV security monitoring',
        'Climate-controlled facilities',
        'Flexible rental terms',
        'Easy access 7 days a week',
        'Insurance options available',
        'Various unit sizes',
      ],
    },
    {
      icon: Package,
      title: 'Packing Services',
      description: 'Expert packing using premium quality materials',
      features: [
        'High-quality packing materials',
        'Professional packing team',
        'Specialist fragile item care',
        'Unpacking service available',
        'Labeling and inventory',
        'Eco-friendly options',
      ],
    },
    {
      icon: Truck,
      title: 'International Moves',
      description: 'Seamless overseas relocations with customs support',
      features: [
        'Worldwide shipping network',
        'Customs clearance assistance',
        'Door-to-door service',
        'International insurance',
        'Packing for long distance',
        'Multi-language support',
      ],
    },
    {
      icon: Shield,
      title: 'Specialist Services',
      description: 'Expert handling for valuable and delicate items',
      features: [
        'Piano and instrument moving',
        'Antique and art transportation',
        'Fine art handling',
        'Vehicle transportation',
        'Pet relocation services',
        'Plant moving service',
      ],
    },
  ]

  const serviceAreas = [
    'London',
    'Birmingham',
    'Manchester',
    'Leeds',
    'Liverpool',
    'Bristol',
    'Edinburgh',
    'Glasgow',
    'Newcastle',
    'Cardiff',
    'Southampton',
    'Sheffield',
  ]

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      {/* HERO */}
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <AutoLinkedContent
            as="h1"
            content="Our Services"
            className="text-5xl font-bold mb-6"
            enableLinking={true}
          />
          <AutoLinkedContent
            content="Comprehensive moving and storage solutions designed to meet all your needs."
            className="text-xl text-gray-300 max-w-3xl mx-auto"
            enableLinking={true}
          />

          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onNavigate('quote')}
              className="bg-[#e71c5e] hover:bg-[#c91852] text-white px-10 py-4 rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-xl"
            >
              Request a Quote
            </button>
            <button
              onClick={() => onNavigate('contact')}
              className="bg-white/10 hover:bg-white/20 text-white px-10 py-4 rounded-lg font-bold text-lg transition-all border border-white/30"
            >
              Contact Us
            </button>
          </div>
        </div>
      </div>

      {/* SERVICES GRID */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard
                key={index}
                icon={service.icon}
                title={service.title}
                description={service.description}
                features={service.features}
                onLearnMore={() => onNavigate('contact')}
              />
            ))}
          </div>
        </div>
      </section>

      {/* SERVICE AREAS */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <AutoLinkedContent
              as="h2"
              content="Service Areas"
              className="text-4xl font-bold text-gray-900 mb-8 text-center"
              enableLinking={true}
            />
            <AutoLinkedContent
              content="We provide our services across the entire United Kingdom, including:"
              className="text-lg text-gray-700 mb-8 text-center"
              enableLinking={true}
            />

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {serviceAreas.map((city) => (
                <div
                  key={city}
                  className="bg-white rounded-lg p-4 text-center shadow hover:shadow-lg transition-shadow"
                >
                  <p className="font-semibold text-gray-800">{city}</p>
                </div>
              ))}
            </div>

            <p className="text-center text-gray-600 mt-8">
              Don&apos;t see your location? Contact us to discuss your requirements.
            </p>
          </div>
        </div>
      </section>

      {/* LONG-FORM CONTENT */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <AutoLinkedContent
              as="h2"
              content="Why Choose Our Removal Services?"
              className="text-4xl font-bold text-gray-900 mb-8 text-center"
              enableLinking={true}
            />

            <div className="prose prose-lg max-w-none text-gray-700 space-y-6 mb-12">
              <p>
                At National Removals and Storage, we understand that moving home or relocating your business is more
                than just transporting belongings from one place to another. It&apos;s about ensuring your valued
                possessions arrive safely, your schedule is respected, and your move is completed with minimal stress
                and disruption.
              </p>

              <p>
                With over 25 years of experience in the removals industry, we&apos;ve perfected the art of professional
                moving. Our comprehensive range of services covers every aspect of relocation, from careful packing and
                secure transportation to flexible storage solutions and specialist item handling. Whether you&apos;re
                moving across the street or across the country, our dedicated team is here to make your move as smooth
                and efficient as possible.
              </p>

              <h3 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Our Commitment to Excellence</h3>

              <p>
                Every member of our team is fully trained, experienced, and committed to providing the highest standards
                of service. We use modern, well-maintained vehicles equipped with GPS tracking, professional packing
                materials designed to protect your belongings, and comprehensive insurance coverage for your complete
                peace of mind.
              </p>

              <p>
                We pride ourselves on our attention to detail, transparent pricing with no hidden costs, and our
                dedication to customer satisfaction. From your initial enquiry through to the final box being unpacked,
                we&apos;re with you every step of the way, ensuring your move is completed to the highest professional
                standards.
              </p>

              <h3 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Tailored Solutions for Every Move</h3>

              <p>
                We recognize that every move is unique. That&apos;s why we offer flexible, customizable services that
                can be tailored to your specific requirements and budget. Whether you need a full-service move with
                packing, transportation, and unpacking, or just help with the heavy lifting, we can create a solution
                that&apos;s perfect for you.
              </p>

              <p>
                Our services extend throughout the United Kingdom and beyond, with specialist teams for local, national,
                and international relocations. We handle residential moves of all sizes, from studio apartments to
                large family homes, as well as commercial relocations ranging from small offices to entire corporate
                headquarters.
              </p>
            </div>

            {/* CTA */}
            <div className="text-center">
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Ready to Move?</h2>
              <p className="text-xl text-gray-600 mb-8">Get in touch today for a free, no-obligation quote.</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => onNavigate('quote')}
                  className="bg-[#e71c5e] hover:bg-[#c91852] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg"
                >
                  Request a Quote
                </button>
                <button
                  onClick={() => onNavigate('contact')}
                  className="bg-white text-[#e71c5e] border-2 border-[#e71c5e] px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-50 transition-all"
                >
                  Contact Us
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
