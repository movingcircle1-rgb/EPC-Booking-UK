import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, FileText, Users, Bell, User, ClipboardCheck, Clock, Briefcase, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useNotifications, useStaffSchedule, useStaffProfile } from '../hooks/usePortalData';
import { useEnsurePortalRecord } from '../hooks/useEnsurePortalRecord';
import SEO from '../components/SEO';
import PortalHeader from '../components/PortalHeader';
import DashboardCard from '../components/portal/DashboardCard';
import EmptyState from '../components/portal/EmptyState';
import LoadingSpinner from '../components/portal/LoadingSpinner';

export default function StaffPortalPage() {
  const { user, userRole, loading: authLoading } = useAuth();
  const { isVerifying, hasRecord, error: portalError } = useEnsurePortalRecord();
  const { notifications, loading: notificationsLoading } = useNotifications();
  const { schedule, loading: scheduleLoading } = useStaffSchedule();
  const { profile, loading: profileLoading } = useStaffProfile();
  const navigate = useNavigate();

  useEffect(() => {
    console.log('[StaffPortalPage] Auth state:', { authLoading, user: !!user, userRole: userRole?.role });

    if (!authLoading && !user) {
      console.log('[StaffPortalPage] No user, redirecting to login');
      navigate('/login');
      return;
    }

    if (!authLoading && user && userRole) {
      console.log('[StaffPortalPage] User role verified:', userRole.role);
      if (userRole.role !== 'staff' && userRole.role !== 'admin') {
        console.log('[StaffPortalPage] Not a staff user, redirecting to correct portal');
        const correctPath = userRole.role === 'client' ? '/client-portal' :
                          userRole.role === 'partner' ? '/partner-portal' :
                          userRole.role === 'trade' ? '/trade-portal' : '/';
        navigate(correctPath, { replace: true });
      }
    }
  }, [user, userRole, authLoading, navigate]);

  if (authLoading || !user || isVerifying) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (portalError || !hasRecord) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-yellow-100 rounded-full mb-4">
            <AlertCircle size={32} className="text-yellow-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Setting Up Your Portal</h2>
          <p className="text-gray-600 mb-6">
            {portalError || 'Your staff profile is being configured. Please refresh the page in a moment.'}
          </p>
          <button
            onClick={() => window.location.reload()}
            className="bg-[#e71c5e] hover:bg-[#c91852] text-white px-6 py-3 rounded-lg font-semibold transition-all"
          >
            Refresh Page
          </button>
        </div>
      </div>
    );
  }

  const unreadNotifications = notifications.filter(n => !n.is_read).length;
  const todaysTasks = schedule.filter(s => s.date === new Date().toISOString().split('T')[0] && s.is_available);
  const upcomingShifts = schedule.filter(s => s.is_available && s.shift_type !== 'off').length;
  const thisWeekHours = schedule
    .filter(s => {
      const scheduleDate = new Date(s.date);
      const today = new Date();
      const weekStart = new Date(today.setDate(today.getDate() - today.getDay()));
      const weekEnd = new Date(today.setDate(today.getDate() - today.getDay() + 6));
      return scheduleDate >= weekStart && scheduleDate <= weekEnd && s.is_available && s.shift_type !== 'off';
    })
    .reduce((total, s) => {
      if (s.shift_type === 'full_day') return total + 8;
      if (s.shift_type === 'morning' || s.shift_type === 'afternoon') return total + 4;
      return total;
    }, 0);
  const timeOffBalance = 20;

  return (
    <div className="min-h-screen bg-gray-50">
      <PortalHeader title="Staff Portal" />
      <SEO
        title="Staff Portal - My Dashboard"
        description="Access your schedule, tasks, and staff resources"
        canonicalUrl="https://nationalremovalsandstorage.co.uk/staff-portal"
      />

      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold mb-2">Welcome back, {userRole?.full_name || 'Team Member'}</h1>
              <p className="text-gray-100">Manage your schedule and access resources</p>
            </div>
            <div className="flex items-center gap-4">
              <button className="relative p-3 bg-white bg-opacity-20 rounded-full hover:bg-opacity-30 transition-all">
                <Bell size={24} />
                {unreadNotifications > 0 && (
                  <span className="absolute -top-1 -right-1 bg-[#e71c5e] text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                    {unreadNotifications}
                  </span>
                )}
              </button>
              <button
                onClick={() => navigate('/profile')}
                className="flex items-center gap-2 p-3 bg-white bg-opacity-20 rounded-full hover:bg-opacity-30 transition-all"
              >
                <User size={24} />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-[#e71c5e]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-semibold">Today's Tasks</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{todaysTasks.length}</p>
              </div>
              <div className="w-12 h-12 bg-[#e71c5e] bg-opacity-10 rounded-full flex items-center justify-center">
                <ClipboardCheck size={24} className="text-[#e71c5e]" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-semibold">Upcoming Shifts</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{upcomingShifts}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Calendar size={24} className="text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-semibold">Hours This Week</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{thisWeekHours}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Clock size={24} className="text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-yellow-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm font-semibold">Time Off Balance</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{timeOffBalance}</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                <Briefcase size={24} className="text-yellow-600" />
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          <DashboardCard
            title="My Schedule"
            icon={Calendar}
            action={{ label: 'View Calendar', onClick: () => {} }}
          >
            {scheduleLoading ? (
              <LoadingSpinner />
            ) : schedule.length === 0 ? (
              <EmptyState
                icon={Calendar}
                title="No Shifts Scheduled"
                description="Your upcoming shifts will appear here. Contact your manager if you need to update your schedule."
              />
            ) : (
              <div className="space-y-3">
                {schedule.slice(0, 7).map((shift) => (
                  <div key={shift.id} className="border border-gray-200 rounded-lg p-3 hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-bold text-gray-900">{new Date(shift.date).toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</p>
                        <p className="text-sm text-gray-600 capitalize">{shift.shift_type?.replace('_', ' ')}</p>
                      </div>
                      <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
                        shift.shift_type === 'off' ? 'bg-gray-100 text-gray-800' :
                        shift.shift_type === 'full_day' ? 'bg-green-100 text-green-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {shift.shift_type === 'off' ? 'Day Off' :
                         shift.shift_type === 'full_day' ? '8 hours' :
                         '4 hours'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </DashboardCard>

          <DashboardCard
            title="Today's Tasks"
            icon={ClipboardCheck}
            action={{ label: 'View All', onClick: () => {} }}
          >
            <EmptyState
              icon={ClipboardCheck}
              title="No Tasks Assigned"
              description="You don't have any tasks assigned for today. Check back later or contact your supervisor."
            />
          </DashboardCard>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          <DashboardCard title="Quick Actions" icon={Briefcase}>
            <div className="grid grid-cols-2 gap-4">
              <button className="p-4 border-2 border-gray-200 rounded-lg hover:border-[#e71c5e] hover:shadow-md transition-all text-left">
                <div className="w-10 h-10 bg-[#e71c5e] bg-opacity-10 rounded-full flex items-center justify-center mb-3">
                  <Calendar size={20} className="text-[#e71c5e]" />
                </div>
                <h3 className="font-bold text-gray-900 text-sm">Request Time Off</h3>
                <p className="text-xs text-gray-600 mt-1">Submit vacation request</p>
              </button>

              <button className="p-4 border-2 border-gray-200 rounded-lg hover:border-[#e71c5e] hover:shadow-md transition-all text-left">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mb-3">
                  <Clock size={20} className="text-blue-600" />
                </div>
                <h3 className="font-bold text-gray-900 text-sm">Update Availability</h3>
                <p className="text-xs text-gray-600 mt-1">Set your work availability</p>
              </button>

              <button className="p-4 border-2 border-gray-200 rounded-lg hover:border-[#e71c5e] hover:shadow-md transition-all text-left">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mb-3">
                  <FileText size={20} className="text-green-600" />
                </div>
                <h3 className="font-bold text-gray-900 text-sm">View Payslips</h3>
                <p className="text-xs text-gray-600 mt-1">Access your pay history</p>
              </button>

              <button className="p-4 border-2 border-gray-200 rounded-lg hover:border-[#e71c5e] hover:shadow-md transition-all text-left">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mb-3">
                  <Users size={20} className="text-purple-600" />
                </div>
                <h3 className="font-bold text-gray-900 text-sm">Team Directory</h3>
                <p className="text-xs text-gray-600 mt-1">View team contacts</p>
              </button>
            </div>
          </DashboardCard>

          <DashboardCard title="Recent Notifications" icon={Bell}>
            {notificationsLoading ? (
              <LoadingSpinner />
            ) : notifications.length === 0 ? (
              <EmptyState
                icon={Bell}
                title="No Notifications"
                description="You're all caught up! You'll see important updates here."
              />
            ) : (
              <div className="space-y-3">
                {notifications.slice(0, 5).map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-3 rounded-lg border ${
                      notification.is_read ? 'bg-white border-gray-200' : 'bg-blue-50 border-blue-200'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900 text-sm">{notification.title}</h4>
                        <p className="text-sm text-gray-600 mt-1">{notification.message}</p>
                        <p className="text-xs text-gray-500 mt-2">
                          {new Date(notification.created_at).toLocaleString()}
                        </p>
                      </div>
                      {!notification.is_read && (
                        <span className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0 mt-2"></span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </DashboardCard>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <DashboardCard title="Company Documents" icon={FileText}>
            <div className="space-y-3">
              <button className="w-full p-4 border-2 border-gray-200 rounded-lg hover:border-[#e71c5e] hover:shadow-md transition-all text-left flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-gray-900 text-sm">Employee Handbook</h4>
                  <p className="text-xs text-gray-600 mt-1">Company policies and procedures</p>
                </div>
                <FileText size={20} className="text-gray-400" />
              </button>

              <button className="w-full p-4 border-2 border-gray-200 rounded-lg hover:border-[#e71c5e] hover:shadow-md transition-all text-left flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-gray-900 text-sm">Safety Guidelines</h4>
                  <p className="text-xs text-gray-600 mt-1">Health and safety procedures</p>
                </div>
                <FileText size={20} className="text-gray-400" />
              </button>

              <button className="w-full p-4 border-2 border-gray-200 rounded-lg hover:border-[#e71c5e] hover:shadow-md transition-all text-left flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-gray-900 text-sm">Training Materials</h4>
                  <p className="text-xs text-gray-600 mt-1">Access training resources</p>
                </div>
                <FileText size={20} className="text-gray-400" />
              </button>

              <button className="w-full p-4 border-2 border-gray-200 rounded-lg hover:border-[#e71c5e] hover:shadow-md transition-all text-left flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-gray-900 text-sm">Benefits Information</h4>
                  <p className="text-xs text-gray-600 mt-1">Employee benefits overview</p>
                </div>
                <FileText size={20} className="text-gray-400" />
              </button>
            </div>
          </DashboardCard>

          <DashboardCard title="My Profile" icon={User}>
            <div className="space-y-4">
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 bg-[#e71c5e] rounded-full flex items-center justify-center">
                    <User size={32} className="text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">{userRole?.full_name || 'Staff Member'}</h3>
                    <p className="text-sm text-gray-600">{user?.email}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">Department</p>
                    <p className="font-semibold text-gray-900">{profile?.department || 'Operations'}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Employee ID</p>
                    <p className="font-semibold text-gray-900">{profile?.employee_number || '-'}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Start Date</p>
                    <p className="font-semibold text-gray-900">{profile?.hire_date ? new Date(profile.hire_date).toLocaleDateString() : '-'}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Role</p>
                    <p className="font-semibold text-gray-900">{profile?.job_role || 'Staff'}</p>
                  </div>
                </div>
              </div>

              <button className="w-full bg-[#e71c5e] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#c91852] transition-colors">
                Edit Profile
              </button>
            </div>
          </DashboardCard>
        </div>
      </div>
    </div>
  );
}
