import { Shield, Clock, Thermometer, Key, Camera, FileText } from 'lucide-react'
import SEO from '../components/SEO'
import AutoLinkedContent from '../components/AutoLinkedContent'
import { useSEO } from '../hooks/useSEO'

// ✅ NEW: use global quote opener
import { useQuote } from '../contexts/QuoteContext'

export default function StoragePage() {
  // ✅ GLOBAL quote opener (replaces onGetQuote prop)
  const { openQuote } = useQuote()

  // IMPORTANT: NO trailing slash – must match Supabase page_path + useSEO normalisation
  const { seoData } = useSEO('/storage')

  const fallbackTitle = 'Storage Solutions | National Removals and Storage'
  const fallbackDescription =
    'Secure, climate-controlled storage facilities across the UK. 24/7 security, flexible terms, and easy access. Units from £15/week. Get a free quote today.'
  const fallbackKeywords =
    'secure storage UK, climate controlled storage, self storage, personal storage, business storage, storage units'
  const fallbackCanonical = 'https://nationalremovalsandstorage.co.uk/storage/'

  const features = [
    {
      icon: Shield,
      title: '24/7 Security',
      description: 'Round-the-clock CCTV monitoring and security personnel',
    },
    {
      icon: Thermometer,
      title: 'Climate Controlled',
      description: 'Temperature and humidity controlled environment',
    },
    {
      icon: Key,
      title: 'Easy Access',
      description: 'Access your belongings 7 days a week with advance notice',
    },
    {
      icon: Clock,
      title: 'Flexible Terms',
      description: 'Short-term and long-term storage solutions available',
    },
    {
      icon: Camera,
      title: 'Secure Facility',
      description: 'Modern, purpose-built storage with advanced security',
    },
    {
      icon: FileText,
      title: 'Insurance Options',
      description: 'Comprehensive insurance coverage available',
    },
  ]

  const storageTypes = [
    {
      size: 'Small',
      dimensions: '5ft x 5ft',
      capacity: 'Perfect for a few boxes, small furniture, or seasonal items',
      price: 'From £15/week',
    },
    {
      size: 'Medium',
      dimensions: '10ft x 10ft',
      capacity: '1-2 bedroom apartment contents, including furniture',
      price: 'From £30/week',
    },
    {
      size: 'Large',
      dimensions: '10ft x 20ft',
      capacity: '3-4 bedroom house contents with multiple rooms of furniture',
      price: 'From £50/week',
    },
    {
      size: 'Extra Large',
      dimensions: '20ft x 20ft',
      capacity: 'Large house or commercial inventory storage',
      price: 'From £80/week',
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      {/* HERO */}
      <div className="relative bg-gradient-to-br from-gray-900 to-gray-800 text-white py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/Storage.webp"
            alt="Secure Storage Solutions"
            className="w-full h-full object-cover opacity-20"
            loading="eager"
          />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <AutoLinkedContent
            as="h1"
            content="Secure Storage Solutions"
            className="text-5xl font-bold mb-6"
            enableLinking={true}
          />
          <AutoLinkedContent
            content="Safe, secure, and flexible storage facilities for all your needs"
            className="text-xl text-gray-300 max-w-3xl"
            enableLinking={true}
          />

          <div className="mt-8">
            <button
              type="button"
              onClick={openQuote}
              className="bg-[#e71c5e] hover:bg-[#c91852] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg"
            >
              Get a Free Quote
            </button>
          </div>
        </div>
      </div>

      {/* FEATURES */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <AutoLinkedContent
              as="h2"
              content="Why Choose Our Storage?"
              className="text-4xl font-bold text-gray-900 mb-4"
              enableLinking={true}
            />
            <AutoLinkedContent
              content="State-of-the-art facilities designed to keep your belongings safe"
              className="text-xl text-gray-600 max-w-2xl mx-auto"
              enableLinking={true}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-shadow"
              >
                <div className="w-14 h-14 bg-[#e71c5e] rounded-full flex items-center justify-center mb-4">
                  <feature.icon size={28} className="text-white" />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* STORAGE TYPES */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <AutoLinkedContent
              as="h2"
              content="Storage Unit Sizes"
              className="text-4xl font-bold text-gray-900 mb-4"
              enableLinking={true}
            />
            <AutoLinkedContent
              content="Choose the perfect size for your storage needs"
              className="text-xl text-gray-600 max-w-2xl mx-auto"
              enableLinking={true}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {storageTypes.map((type, index) => (
              <div
                key={index}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow"
              >
                <div className="bg-gradient-to-br from-[#e71c5e] to-[#c91852] p-6 text-white text-center">
                  <h3 className="text-2xl font-bold mb-2">{type.size}</h3>
                  <p className="text-white/90">{type.dimensions}</p>
                </div>
                <div className="p-6">
                  <p className="text-gray-700 mb-4 min-h-[60px]">{type.capacity}</p>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-[#e71c5e] mb-4">{type.price}</p>
                    <button
                      type="button"
                      onClick={openQuote}
                      className="w-full bg-gray-100 hover:bg-[#e71c5e] hover:text-white text-gray-700 px-6 py-3 rounded-lg font-semibold transition-all"
                    >
                      Get Quote
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <p className="text-center text-gray-600 mt-8">
            Not sure which size you need? Contact us for a free consultation.
          </p>
        </div>
      </section>

      {/* PERFECT FOR */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <AutoLinkedContent
              as="h2"
              content="Perfect For"
              className="text-4xl font-bold text-gray-900 mb-8 text-center"
              enableLinking={true}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="text-xl font-bold mb-4 text-[#e71c5e]">
                  Personal Storage
                </h3>
                <ul className="space-y-2 text-gray-700">
                  {[
                    'House moves and renovations',
                    'Downsizing or decluttering',
                    'Seasonal items storage',
                    'Student storage during holidays',
                    'Temporary living arrangements',
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-2">
                      <span className="text-[#e71c5e] mt-1">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="text-xl font-bold mb-4 text-[#e71c5e]">
                  Business Storage
                </h3>
                <ul className="space-y-2 text-gray-700">
                  {[
                    'Archive and document storage',
                    'Excess inventory management',
                    'Office furniture and equipment',
                    'Seasonal business stock',
                    'Office relocation support',
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-2">
                      <span className="text-[#e71c5e] mt-1">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <AutoLinkedContent
              as="h2"
              content="How It Works"
              className="text-4xl font-bold text-gray-900 mb-8 text-center"
              enableLinking={true}
            />

            <div className="space-y-6">
              {[
                {
                  title: 'Choose Your Unit',
                  text: 'Contact us to discuss your requirements and select the perfect storage size.',
                },
                {
                  title: 'Deliver Your Items',
                  text: 'Drop off your belongings yourself or use our collection service.',
                },
                {
                  title: 'Store with Confidence',
                  text: 'Your items are secured in our modern, monitored facility.',
                },
                {
                  title: 'Access When Needed',
                  text: 'Access your storage unit easily with advance notice, 7 days a week.',
                },
              ].map((step, idx) => (
                <div key={step.title} className="flex gap-4 items-start">
                  <div className="w-10 h-10 rounded-full bg-[#e71c5e] text-white flex items-center justify-center font-bold flex-shrink-0">
                    {idx + 1}
                  </div>
                  <div className="flex-grow bg-white rounded-lg p-6 shadow">
                    <h3 className="text-xl font-bold mb-2">{step.title}</h3>
                    <p className="text-gray-600">{step.text}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-10 text-center">
              <button
                type="button"
                onClick={openQuote}
                className="bg-[#e71c5e] hover:bg-[#c91852] text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 shadow-lg"
              >
                Get a Free Storage Quote
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-gradient-to-br from-[#e71c5e] to-[#c91852] rounded-2xl p-8 md:p-12 text-white text-center">
            <AutoLinkedContent
              as="h2"
              content="Need Storage?"
              className="text-3xl md:text-4xl font-bold mb-4"
              enableLinking={true}
            />
            <p className="text-xl mb-8 text-white/90">
              Get a free quote today and secure your storage space.
            </p>
            <button
              type="button"
              onClick={openQuote}
              className="bg-white text-[#e71c5e] px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-100 transition-all transform hover:scale-105"
            >
              Get Free Quote
            </button>
          </div>
        </div>
      </section>
    </div>
  )
}
