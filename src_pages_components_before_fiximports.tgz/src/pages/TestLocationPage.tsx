import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import Navbar from '../components/Navbar'

export default function TestLocationPage() {
  const navigate = useNavigate()
  const [citySlug, setCitySlug] = useState('aberdeen')
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [logs, setLogs] = useState<string[]>([])

  const handleNavigate = (page: string) => {
    navigate(`/${page}`)
  }

  const addLog = (message: string) => {
    // eslint-disable-next-line no-console
    console.log(message)
    setLogs((prev) => [...prev, `${new Date().toLocaleTimeString()}: ${message}`])
  }

  const testFetch = async () => {
    setLoading(true)
    setError(null)
    setData(null)
    setLogs([])

    addLog(`Testing fetch for city_slug: ${citySlug}`)

    try {
      addLog('Calling Supabase...')

      const { data: result, error: fetchError } = await supabase
        .from('locations')
        .select('*')
        .eq('city_slug', citySlug)
        .maybeSingle()

      if (fetchError) {
        addLog(`ERROR: ${fetchError.message}`)
        setError(fetchError.message)
        return
      }

      if (!result) {
        addLog('WARNING: No data found')
        setError('Location not found')
        return
      }

      addLog(`SUCCESS: Found ${result.city}`)
      setData(result)
    } catch (err: any) {
      addLog(`EXCEPTION: ${err?.message || String(err)}`)
      setError(err?.message || String(err))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    testFetch()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar onNavigate={handleNavigate} />

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h1 className="text-2xl font-bold mb-4">🔬 Location Fetch Test</h1>

          <div className="flex gap-2 mb-4">
            <input
              type="text"
              value={citySlug}
              onChange={(e) => setCitySlug(e.target.value)}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg"
              placeholder="Enter city slug"
            />
            <button
              type="button"
              onClick={testFetch}
              disabled={loading}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {loading ? 'Testing...' : 'Test Fetch'}
            </button>
          </div>

          <div className="mb-4">
            <h3 className="font-semibold mb-2">Environment Check:</h3>
            <div className="bg-gray-100 p-3 rounded text-sm font-mono">
              <div>
                VITE_SUPABASE_URL:{' '}
                {import.meta.env.VITE_SUPABASE_URL ? '✅ Set' : '❌ Missing'}
              </div>
              <div>
                VITE_SUPABASE_ANON_KEY:{' '}
                {import.meta.env.VITE_SUPABASE_ANON_KEY ? '✅ Set' : '❌ Missing'}
              </div>
            </div>
          </div>

          {logs.length > 0 && (
            <div className="mb-4">
              <h3 className="font-semibold mb-2">Console Logs:</h3>
              <div className="bg-gray-900 text-green-400 p-3 rounded text-sm font-mono max-h-40 overflow-y-auto">
                {logs.map((log, i) => (
                  <div key={i}>{log}</div>
                ))}
              </div>
            </div>
          )}

          {error && (
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
              <h3 className="font-semibold text-red-800 mb-2">❌ Error:</h3>
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {data && (
            <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg">
              <h3 className="font-semibold text-green-800 mb-2">
                ✅ Success! Data Retrieved:
              </h3>
              <pre className="text-xs bg-white p-3 rounded overflow-x-auto">
                {JSON.stringify(data, null, 2)}
              </pre>
            </div>
          )}

          <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <h3 className="font-semibold text-blue-800 mb-2">Quick Test Links:</h3>
            <div className="space-y-2">
              <a
                href="/removals-aberdeen"
                target="_blank"
                rel="noreferrer"
                className="block text-blue-600 hover:underline"
              >
                /removals-aberdeen
              </a>
              <a
                href="/removals-birmingham"
                target="_blank"
                rel="noreferrer"
                className="block text-blue-600 hover:underline"
              >
                /removals-birmingham
              </a>
              <a
                href="/removals-london"
                target="_blank"
                rel="noreferrer"
                className="block text-blue-600 hover:underline"
              >
                /removals-london
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
