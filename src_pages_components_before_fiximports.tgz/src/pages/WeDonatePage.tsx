import { Heart, Award, Users, TrendingUp } from 'lucide-react'
import SEO from '../components/SEO'
import AutoLinkedContent from '../components/AutoLinkedContent'
import { useSEO } from '../hooks/useSEO'

export default function WeDonatePage() {
  const { seoData } = useSEO('/we-donate')

  const fallbackTitle = 'We Donate | Charitable Giving | National Removals and Storage'
  const fallbackDescription =
    'We donate 2% of revenue to UK charities including British Heart Foundation, Shelter UK, and local food banks. £65,000+ donated annually. Choose a removal company that gives back.'
  const fallbackKeywords =
    'charitable removals company, removals company charity work, giving back, community support, UK charity donations'
  const fallbackCanonical = 'https://nationalremovalsandstorage.co.uk/we-donate'

  const charities = [
    { name: 'British Heart Foundation', focus: 'Cardiovascular Research', contribution: '£15,000 annually' },
    { name: 'Local Food Banks', focus: 'Food Security', contribution: 'Weekly donations' },
    { name: 'Shelter UK', focus: 'Homelessness', contribution: '£10,000 annually' },
    { name: 'Age UK', focus: 'Elderly Support', contribution: 'Furniture donations' },
    { name: 'Crisis', focus: 'Homelessness Support', contribution: '£8,000 annually' },
    { name: 'Save the Children', focus: 'Child Welfare', contribution: '£12,000 annually' }
  ]

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      <div className="relative bg-gradient-to-r from-red-600 to-red-800 text-white py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/We donate.webp"
            alt="We Donate - Community Support"
            className="w-full h-full object-cover opacity-30"
            loading="eager"
          />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <AutoLinkedContent as="h1" content="We Donate" className="text-5xl font-bold mb-6" enableLinking />
            <AutoLinkedContent
              content="Giving back to the communities we serve"
              className="text-xl text-red-100"
              enableLinking
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <AutoLinkedContent
              as="h2"
              content="Our Commitment to Charity"
              className="text-3xl font-bold text-gray-900 mb-4"
              enableLinking
            />
            <AutoLinkedContent
              content="At National Removals, we believe in giving back. A portion of every move goes directly to supporting charitable causes across the UK."
              className="text-lg text-gray-600 max-w-2xl mx-auto"
              enableLinking
            />
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {charities.map((charity, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-xl shadow-lg border border-gray-200 hover:shadow-xl transition-shadow"
              >
                <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
                  <Heart className="text-red-600" size={24} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{charity.name}</h3>
                <p className="text-sm text-gray-600 mb-3">{charity.focus}</p>
                <p className="text-red-600 font-semibold">{charity.contribution}</p>
              </div>
            ))}
          </div>

          <div className="bg-gray-50 rounded-xl p-8 mb-12">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="text-red-600" size={32} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">2% of Revenue</h3>
                <p className="text-gray-600">We donate 2% of all our revenue to registered charities every year.</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="text-red-600" size={32} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Employee Volunteering</h3>
                <p className="text-gray-600">Our team volunteers 200+ hours annually with local community projects.</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="text-red-600" size={32} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Growing Impact</h3>
                <p className="text-gray-600">Our charitable contributions have increased 150% over the past 5 years.</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-red-50 to-red-100 rounded-xl p-8 mb-12">
            <AutoLinkedContent as="h2" content="Our Annual Impact" className="text-2xl font-bold text-gray-900 mb-6" enableLinking />
            <div className="grid md:grid-cols-4 gap-6 text-center">
              <div>
                <p className="text-4xl font-bold text-red-600 mb-2">£65,000</p>
                <p className="text-gray-700 font-semibold">Total Donations</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-red-600 mb-2">12</p>
                <p className="text-gray-700 font-semibold">Partner Charities</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-red-600 mb-2">3,500+</p>
                <p className="text-gray-700 font-semibold">Lives Impacted</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-red-600 mb-2">200+</p>
                <p className="text-gray-700 font-semibold">Volunteer Hours</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-8 border border-gray-200">
            <AutoLinkedContent
              as="h2"
              content="How Your Move Helps"
              className="text-2xl font-bold text-gray-900 mb-4"
              enableLinking
            />
            <AutoLinkedContent
              content="Every time you choose National Removals, you're not just getting excellent service — you're also contributing to positive change in our communities. Here's how:"
              className="text-gray-700 mb-6"
              enableLinking
            />

            <div className="space-y-4">
              {[
                'A portion of your moving fee goes directly to our charity partners',
                'Your donated furniture helps families in need furnish their homes',
                'Our eco-friendly practices support environmental charities',
                'Your recommendations help us increase our charitable impact'
              ].map((text, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <Heart className="text-red-600 flex-shrink-0 mt-1" size={20} />
                  <AutoLinkedContent content={text} className="text-gray-700" enableLinking />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
