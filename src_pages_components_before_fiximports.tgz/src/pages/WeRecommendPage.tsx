import { Star, CheckCircle, Award } from 'lucide-react'
import SEO from '../components/SEO'
import AutoLinkedContent from '../components/AutoLinkedContent'
import { useSEO } from '../hooks/useSEO'

export default function WeRecommendPage() {
  const { seoData } = useSEO('/we-recommend')

  const fallbackTitle = 'Trusted Partners We Recommend | National Removals and Storage'
  const fallbackDescription =
    'Exclusive discounts with our trusted partner services including cleaning, utilities, packing supplies, decorators, and security. Make your move complete with our recommended partners.'
  const fallbackKeywords =
    'moving partner services, removal service partners, moving discounts, relocation services, moving recommendations'
  const fallbackCanonical = 'https://nationalremovalsandstorage.co.uk/we-recommend'

  const partners = [
    {
      name: 'Premium Cleaning Services',
      category: 'Cleaning',
      discount: '15% off',
      description: 'Professional end-of-tenancy and deep cleaning services.',
    },
    {
      name: 'SecureBox Storage',
      category: 'Storage',
      discount: 'First month free',
      description: 'Climate-controlled storage units in multiple locations.',
    },
    {
      name: 'HomeConnect Utilities',
      category: 'Utilities',
      discount: '£50 credit',
      description: 'Quick and easy utility connection for your new home.',
    },
    {
      name: 'PackPro Supplies',
      category: 'Packing',
      discount: '20% off',
      description: 'Quality packing materials and moving boxes delivered to your door.',
    },
    {
      name: 'FreshStart Decorators',
      category: 'Home Improvement',
      discount: '10% off',
      description: 'Professional painting and decorating services.',
    },
    {
      name: 'LockSmith Pro',
      category: 'Security',
      discount: 'Free consultation',
      description: 'Lock changes and home security upgrades.',
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      <div className="relative bg-gradient-to-r from-[#e71c5e] to-[#c91852] text-white py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/We Recommend.webp"
            alt="Trusted Partner Services"
            className="w-full h-full object-cover opacity-30"
            loading="eager"
          />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <AutoLinkedContent
              as="h1"
              content="Trusted Partners We Recommend"
              className="text-5xl font-bold mb-6"
              enableLinking
            />
            <AutoLinkedContent
              content="Exclusive discounts with our carefully selected partner services"
              className="text-xl text-pink-100"
              enableLinking
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <AutoLinkedContent
              as="h2"
              content="Making Your Move Complete"
              className="text-3xl font-bold text-gray-900 mb-4"
              enableLinking
            />
            <AutoLinkedContent
              content="We've partnered with the best service providers to make your moving experience seamless. All our customers receive exclusive discounts with these trusted companies."
              className="text-lg text-gray-600 max-w-2xl mx-auto"
              enableLinking
            />
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {partners.map((partner, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-xl shadow-lg border border-gray-200 hover:shadow-xl transition-shadow"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-[#e71c5e]/10 rounded-full flex items-center justify-center">
                    <Award className="text-[#e71c5e]" size={24} />
                  </div>
                  <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">
                    {partner.discount}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-gray-900 mb-2">{partner.name}</h3>
                <p className="text-sm text-[#e71c5e] font-semibold mb-3">{partner.category}</p>
                <p className="text-gray-600">{partner.description}</p>
              </div>
            ))}
          </div>

          <div className="bg-gray-50 rounded-xl p-8">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-[#e71c5e]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="text-[#e71c5e]" size={32} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Vetted Partners</h3>
                <p className="text-gray-600">
                  All partners are carefully selected and regularly reviewed to maintain high standards.
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-[#e71c5e]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="text-[#e71c5e]" size={32} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Exclusive Discounts</h3>
                <p className="text-gray-600">Special rates available only to National Removals customers.</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-[#e71c5e]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="text-[#e71c5e]" size={32} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Quality Assured</h3>
                <p className="text-gray-600">We only recommend services we trust and would use ourselves.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
