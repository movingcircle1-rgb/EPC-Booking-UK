import { Recycle, Leaf, Package, BarChart3 } from 'lucide-react'
import SEO from '../components/SEO'
import AutoLinkedContent from '../components/AutoLinkedContent'
import { useSEO } from '../hooks/useSEO'

export default function WeRecyclePage() {
  // IMPORTANT: NO trailing slash – must match Supabase page_path + useSEO normalisation
  const { seoData } = useSEO('/we-recycle')

  const fallbackTitle = 'We Recycle - Sustainable Moving Practices | National Removals'
  const fallbackDescription =
    '92% recycling rate with zero waste to landfill goal. We recycle packing materials, furniture, electronics, and more. 150 tons recycled annually.'
  const fallbackKeywords =
    'eco-friendly removals, sustainable moving, recycling removals, green moving company, zero waste removals'
  const fallbackCanonical = 'https://nationalremovalsandstorage.co.uk/we-recycle/'

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={seoData?.meta_title || fallbackTitle}
        description={seoData?.meta_description || fallbackDescription}
        keywords={seoData?.meta_keywords || fallbackKeywords}
        canonicalUrl={seoData?.canonical_url || fallbackCanonical}
      />

      <div className="relative bg-gradient-to-r from-emerald-600 to-emerald-800 text-white py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/We Recycle.webp"
            alt="We Recycle - Sustainable Moving"
            className="w-full h-full object-cover opacity-30"
            loading="eager"
          />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <AutoLinkedContent
              as="h1"
              content="We Recycle"
              className="text-5xl font-bold mb-6"
              enableLinking
            />
            <AutoLinkedContent
              content="Committed to sustainable moving practices and waste reduction"
              className="text-xl text-emerald-100"
              enableLinking
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="bg-emerald-50 border-l-4 border-emerald-600 p-6 rounded-lg mb-12">
            <AutoLinkedContent
              as="h2"
              content="Zero Waste to Landfill Goal"
              className="text-2xl font-bold text-emerald-900 mb-2"
              enableLinking
            />
            <AutoLinkedContent
              content="We’re committed to recycling and repurposing materials from every move, keeping waste out of landfills."
              className="text-emerald-800"
              enableLinking
            />
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                <Package className="text-emerald-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Packing Materials</h3>
              <p className="text-gray-600">
                All our boxes, bubble wrap, and packing materials are recyclable or biodegradable.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                <Recycle className="text-emerald-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Furniture Recycling</h3>
              <p className="text-gray-600">
                Unwanted furniture is donated, repurposed, or properly recycled — never sent to landfill.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                <Leaf className="text-emerald-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Eco-Friendly Products</h3>
              <p className="text-gray-600">
                We use environmentally friendly cleaning products and sustainable materials wherever possible.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
              <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                <BarChart3 className="text-emerald-600" size={24} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Tracking Our Impact</h3>
              <p className="text-gray-600">
                We monitor and report our recycling rates, continuously improving our environmental performance.
              </p>
            </div>
          </div>

          <div className="bg-gray-50 rounded-xl p-8 mb-12">
            <AutoLinkedContent
              as="h2"
              content="What We Recycle"
              className="text-2xl font-bold text-gray-900 mb-6"
              enableLinking
            />

            <div className="space-y-4">
              <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                <h3 className="font-bold text-gray-900 mb-2">Cardboard &amp; Paper</h3>
                <p className="text-gray-600">
                  All cardboard boxes and paper materials are sorted and sent to recycling facilities.
                </p>
              </div>

              <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                <h3 className="font-bold text-gray-900 mb-2">Plastics</h3>
                <p className="text-gray-600">
                  Bubble wrap, stretch film, and plastic wrapping are collected and recycled properly.
                </p>
              </div>

              <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                <h3 className="font-bold text-gray-900 mb-2">Wood &amp; Furniture</h3>
                <p className="text-gray-600">
                  Wooden pallets and furniture are repaired, donated, or sent to wood recycling centers.
                </p>
              </div>

              <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                <h3 className="font-bold text-gray-900 mb-2">Metal</h3>
                <p className="text-gray-600">
                  All metal items including appliances are sent to scrap metal recyclers.
                </p>
              </div>

              <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                <h3 className="font-bold text-gray-900 mb-2">Electronics</h3>
                <p className="text-gray-600">
                  WEEE certified disposal of all electronic items to recover valuable materials.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-emerald-50 to-emerald-100 rounded-xl p-8">
            <AutoLinkedContent
              as="h2"
              content="Our Recycling Achievement"
              className="text-2xl font-bold text-gray-900 mb-6"
              enableLinking
            />

            <div className="grid md:grid-cols-3 gap-6 text-center mb-6">
              <div>
                <p className="text-4xl font-bold text-emerald-600 mb-2">92%</p>
                <p className="text-gray-700 font-semibold">Recycling Rate</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-emerald-600 mb-2">150 Tons</p>
                <p className="text-gray-700 font-semibold">Recycled Annually</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-emerald-600 mb-2">95%</p>
                <p className="text-gray-700 font-semibold">Diverted from Landfill</p>
              </div>
            </div>

            <p className="text-center text-gray-600">
              We’re proud of our achievements and committed to reaching 100% waste diversion by 2026.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
